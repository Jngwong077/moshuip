package com.readboy.simpleLauncher.rewords.download;

import android.arch.persistence.room.Room;
import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.readboy.rc4.RC4;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AllWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AllWordsDao;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AppDatabase;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWordsDao;
import com.readboy.simpleLauncher.rewords.fragment.Fragment_Learning_Word;
import com.readboy.simpleLauncher.rewords.fragment.Fragment_Rewords;
import com.readboy.simpleLauncher.rewords.selectBookAndUnit.SelectBookActivity;
import com.readboy.simpleLauncher.rewords.setting.SettingActivity;
import com.readboy.simpleLauncher.rewords.tool.Config;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Created by hjy on 2022/5/24 15:11
 */
public class HttpDownloader {
    public static final String READBOY_PATH = Environment.getExternalStorageDirectory().getPath() + "/Recite/";     //存储路径

    public static String download(String docUrl, long uid, long bookId) throws Exception{                           /***加载正文***/
        //获取存储卡路径、构成保存文件的目标路径
//        FileUtils fileUtils = new FileUtils();
        String dirName = READBOY_PATH + uid + "/" + bookId + "/";

        File f = new File(dirName);
        /*  判断文件夹是否存在，如果不存在、则删除文件夹  */
        if (f.exists())
            deleteDirWihtFile(f);


        /*  创建多级目录  */
        if (!f.exists()){
            createFileDirectorys(dirName);
        } else
            return  null;



        Log.w("TAG", "download:判断文件夹是否存在，   " + f.exists() );
        Log.e("TAG", "download: " + dirName + "  " + docUrl);


        /*  准备拼接新的文件名   */
        String[] list = docUrl.split("/");
        String fileName = list[list.length-1];
        fileName = dirName + fileName;
        File file = new File(fileName);
        /*  如果目标文件已经存在，则删除旧文件   */
        if(file.exists())
            file.delete();
        Log.w("TAG", "download: " + file.exists() );

        byte[] bs = new byte[1024];
        //读取到的数据长度
        int len;
        try{
            //通过文件地址构建url对象
            URL url = new URL(docUrl);
            //获取链接
            //URLConnection conn = url.openConnection();
            //创建输入流
            InputStream is = url.openStream();
            //获取文件的长度
            //int contextLength = conn.getContentLength();
            //输出的文件流
            OutputStream os = new FileOutputStream(file);
            //开始读取
            while((len = is.read(bs)) != -1){
                os.write(bs,0,len);
            }
            //完毕关闭所有连接
            os.close();
            is.close();
        }catch(MalformedURLException e){
            fileName = null;
            System.out.println("创建URL对象失败");
            throw e;
        }catch(FileNotFoundException e){
            fileName = null;
            System.out.println("无法加载文件");
            throw e;
        }catch(IOException e){
            fileName = null;
            System.out.println("获取连接失败");
            throw e;
        }

        return fileName;
    }

    public static void deleteDirWihtFile(File dir) {
        if (dir == null || !dir.exists() || !dir.isDirectory())
            return;
        for (File file : dir.listFiles()) {
            if (file.isFile())
                file.delete(); // 删除所有文件
            else if (file.isDirectory())
                deleteDirWihtFile(file); // 递规的方式删除文件夹
        }
        dir.delete();// 删除目录本身
    }



    /**
     * 读取文件
     *
     * @return 返回读取到的文件内容
     */
    public static String readFileData(String fileName) {
        File file = new File(fileName);
        Log.d("TAG", "fileString  " + fileName  + "\n" + "readFileData: " + file.getName());
        StringBuilder text = new StringBuilder();

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
        } catch (IOException e) {
            //You'll need to add proper error handling here
        }

        return text.toString();
    }

    /**
     * 将Byte数组转换成zip文件
     * @param bytes    byte数组
    //* @param filePath 文件路径  如 D://test/ 最后“/”结尾
     */
    public static void bytesToFile(Context context, byte[] bytes, long uid, long bid, boolean isEnd) throws IOException {
        //文件名
        FileUtils fileUtils = new FileUtils();
//        String name = fileUtils.getSDPATH() + "Recite/" + bid + ".zip";
        String dirName = READBOY_PATH + uid + "/" + bid + "/";
        String name = dirName + bid + ".zip";
        BufferedOutputStream bos = null;
        FileOutputStream fos = null;
        File file = null;
        try {

            file = new File(name);
            if (!file.getParentFile().exists()) {
                //文件夹不存在 生成
                file.getParentFile().mkdirs();
            }
            fos = new FileOutputStream(file);
            bos = new BufferedOutputStream(fos);
            bos.write(bytes);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (bos != null) {
                try {
                    bos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
//        unzipFile(name, fileUtils.getSDPATH() + "Recite/rewords", context);
        /**
         *  byte数组转成zip文件后，直接进行解压
         */
        unzipFile(name, dirName, uid, bid, isEnd, context);

    }


    public static void unzipFile(String zipPtath, String outputDirectory, long uid, long bookId, boolean isEnd , Context context)throws IOException {
        /**
         * 解压指定的zip压缩文件到指定目录
         * @param zipPtath压缩文件名
         * @param outputDirectory输出目录
         * @param context上下文对象
         * @throws IOException
         */

        Log.i("TAG","开始解压的文件： "  + zipPtath + "\n" + "解压的目标路径：" + outputDirectory );
        // 创建解压目标目录
        File file = new File(outputDirectory);

        // 如果目标目录不存在，则创建
        if (!file.exists()) {
            file.mkdirs();
        }
        // 打开压缩文件
        InputStream inputStream = new FileInputStream(zipPtath); ;
        ZipInputStream zipInputStream = new ZipInputStream(inputStream);

        // 读取一个进入点
        ZipEntry zipEntry = zipInputStream.getNextEntry();
        // 使用1Mbuffer
        byte[] buffer = new byte[1024 * 1024];
        // 解压时字节计数
        int count = 0;
        // 如果进入点为空说明已经遍历完所有压缩包中文件和目录
        while (zipEntry != null) {
//            Log.i("TAG","解压文件 入口 1： " +zipEntry );
            if (!zipEntry.isDirectory()) {  //如果是一个文件
                // 如果是文件
                String fileName =outputDirectory + zipEntry.getName();
//                Log.i("TAG","解压文件 原来 文件的位置： " + fileName);
//                String fn = null;
//                if (fileName.contains("uk_word_sound")){
//                    fn = "/uk_word_sound/";
//                } else if (fileName.contains("us_word_sound"))
//                    fn = "/us_word_sound/";
//                file = new File(outputDirectory + fn);
//                if (!file.exists()) {
//                    file.mkdirs();
//                }
//
//                fileName =fileName.substring(fileName.lastIndexOf("/") + 1);  //截取文件的名字 去掉原文件夹名字
//                fileName =fileName.substring(fileName.lastIndexOf("/") + 1);
//                fileName = fileName.toLowerCase();
//                Log.i("TAG","解压文件 的名字： " + fileName);
//
//
//                if (fn == null){
//                    file = new File(outputDirectory + File.separator + fileName);   //放到新的解压的文件路径
//                } else
//                    file = new File(outputDirectory + fn + File.separator + fileName);
//                Log.i("TAG","新的解压文件路径： " + file);
//                Log.i("TAG","放到新的解压的文件路径的名字： " + fileName );
                if (fileName.contains("/")){
                    String fn = fileName.substring(0, fileName.lastIndexOf("/"));
                    File fnFile = new File(fn);
                    if (!fnFile.exists())
                        createFileDirectorys(fn);
                }


                File files = new File(fileName);
                if (!files.exists())
                    files.createNewFile();

                FileOutputStream fileOutputStream = new FileOutputStream(files);
                while ((count = zipInputStream.read(buffer)) > 0) {
                    fileOutputStream.write(buffer, 0, count);
                }
                fileOutputStream.close();
            }
            // 定位到下一个文件入口
            zipEntry = zipInputStream.getNextEntry();
//            Log.i("TAG","解压文件 入口 2： " + zipEntry );
        }
        zipInputStream.close();
        Log.i("TAG","解压完成  ");

        File zipFile = new File(zipPtath);
        if (zipFile.exists())
            zipFile.delete();

        String str = context.toString();
        Log.d("TAG", "unzipFile: " + str);

        if(str.contains("SelectBookActivity")){
            SelectBookActivity.getInstance().hideDownloading();
        } else if (str.contains("SettingActivity")){
            SettingActivity.getInstance().hideDownloading(isEnd);
//            if (db == null){
//                db = Room.databaseBuilder(context, AppDatabase.class, "newRewords.db" )
//                        .fallbackToDestructiveMigration()
//                        .allowMainThreadQueries()
//                        .build();
//            }
//
//            if (dao == null)
//                dao = db.allWordsDao();
//
//            String fileString =  HttpDownloader.readFileData(Config.rewordsPath + uid + "/" + bookId +"/" + "words.json");
//            Log.w("bbbbbbb", "saveWordData: bookId: " + bookId );
//            Gson gson = new Gson();
//            List<AllWords> words= gson.fromJson(fileString, new TypeToken<List<AllWords>>() {}.getType());
//
//            new Thread(() -> {
//                for (AllWords a : words)
//                    dao.insert(a);
//            }).start();
//
//            Log.w("bbbbbbb", "onFinish words.size():  " + words.size());
////            dao.insertAll(words);
//            Log.w("bbbbbbb", "onFinish dao.getAl.size():  " + dao.getAll().size());
//            Fragment_Learning_Word.getInstance().requestWordRecords();
        } else
            Fragment_Learning_Word.getInstance().hideDownloading(isEnd);


    }
    static AppDatabase db;
    static AllWordsDao dao;

    /**
     *  RC4解密，RC4包自带key
     *  解密出来的byte[]数组，需转成zip文件格式
     * @param fileIn
     * @param rc4file
     * @return
     */

    public static byte[] bookReadBuffer(FileInputStream fileIn, boolean rc4file) {
        byte[] buffer = null;
        if (fileIn != null) {
            try {
                int fileLen = fileIn.available();
                buffer = new byte[fileLen];
                fileIn.read(buffer, 0, fileLen);
                if (rc4file) {
                    buffer = RC4.crypt(buffer);
                }
                return buffer;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }


    /**
     * 创建多级文件目录
     * @param fileDir
     * @return
     */
    public static void createFileDirectorys(String fileDir) {
        String[] fileDirs=fileDir.split("\\/");
        String topPath="";
        for (int i = 0; i < fileDirs.length; i++) {
            topPath+="/"+fileDirs[i];
            File file = new File(topPath);
            if (file.exists()) {
                continue;
            }else {
                file.mkdir();
            }
        }
    }
}

