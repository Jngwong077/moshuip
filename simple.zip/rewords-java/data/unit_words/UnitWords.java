package com.readboy.simpleLauncher.rewords.data.unit_words;

import org.litepal.crud.LitePalSupport;

/**
 * Created by hjy on 2022/3/31 14:59
 */
public class UnitWords extends LitePalSupport {

    private String word;
    private int isNewWord;
    private int unitId;

    public int getUnitId() {
        return unitId;
    }

    public void setUnitId(int unitId) {
        this.unitId = unitId;
    }

    public String getWords() {
        return word;
    }

    public int getIsNewWord() {
        return isNewWord;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public void setIsNewWord(int isNewWord) {
        this.isNewWord = isNewWord;
    }


}
