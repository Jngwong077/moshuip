package com.readboy.simpleLauncher.rewords.data.unit_words;

/**
 * Created by hjy on 2022/3/30 9:34
 */
public class UnitWordsData {
    private String msg;
    private int ok;
    private UnitData data;

    public UnitWordsData(String msg, int ok, UnitData data) {
        this.msg = msg;
        this.ok = ok;
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public int getOk() {
        return ok;
    }

    public UnitData getData() {
        return data;
    }

}

