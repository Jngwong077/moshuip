package com.readboy.simpleLauncher.rewords.data.unit_words;

import org.litepal.crud.LitePalSupport;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by hjy on 2022/3/31 14:56
 */
public class UnitData extends LitePalSupport {
    private int knownWordCount;   //认识数
    private int total;     //总数
    private int newWordCount;     //生词数
    private int studyAgainWordCount;    //重新学习数
    private List<UnitWords> words;
    private int unitId;

    public int getUnitId() {
        return unitId;
    }

    public void setUnitId(int unitId) {
        this.unitId = unitId;
    }

    public void setKnownWordCount(int knownWordCount) {
        this.knownWordCount = knownWordCount;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public void setNewWordCount(int newWordCount) {
        this.newWordCount = newWordCount;
    }

    public void setStudyAgainWordCount(int studyAgainWordCount) {
        this.studyAgainWordCount = studyAgainWordCount;
    }

    public void setWords(ArrayList<UnitWords> words) {
        this.words = words;
    }

    public int getKnownWordCount() {
        return knownWordCount;
    }

    public int getTotal() {
        return total;
    }

    public int getNewWordCount() {
        return newWordCount;
    }

    public int getStudyAgainWordCount() {
        return studyAgainWordCount;
    }

    public List<UnitWords> getWords() {
        return words;
    }


}