package com.readboy.simpleLauncher.rewords.data;

import android.arch.persistence.room.Room;
import android.arch.persistence.room.TypeConverter;
import android.content.Context;

import com.google.gson.reflect.TypeToken;
import com.readboy.simpleLauncher.rewords.data.book.Children;
import com.readboy.simpleLauncher.rewords.data.book.UnitData;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AllWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AppDatabase;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;

import java.lang.reflect.Type;
import java.util.ArrayList;

import kotlin.Unit;

/**
 * Created by hjy on 2022/5/26 11:42
 */
public class ObjectChangeString {

    @TypeConverter
    public static <T> String listObjectToString(T list) {
        return GsonInstance.getInstance().getGson().toJson(list);
    }


    @TypeConverter
    public static <T> String objectToString(T t) {
        return GsonInstance.getInstance().getGson().toJson(t);
    }


    @TypeConverter
    public static UnitData stringToUnitData(String json) {
        Type listType = new TypeToken<UnitData>(){}.getType();
        return GsonInstance.getInstance().getGson().fromJson(json, listType);
    }


    @TypeConverter
    public static DetailWords stringToWords(String json) {
        Type listType = new TypeToken<DetailWords>(){}.getType();
        return GsonInstance.getInstance().getGson().fromJson(json, listType);
    }

    @TypeConverter
    public static ArrayList<Children> stringToObject(String json) {
        Type listType = new TypeToken<ArrayList<Children>>(){}.getType();
        return GsonInstance.getInstance().getGson().fromJson(json, listType);
    }


    @TypeConverter
    public static ArrayList<DetailWords> stringToDetailWords(String json) {
        Type listType = new TypeToken<ArrayList<DetailWords>>(){}.getType();
        return GsonInstance.getInstance().getGson().fromJson(json, listType);
    }

    @TypeConverter
    public static ArrayList<AllWords> stringToAllWords(String json) {
        Type listType = new TypeToken<ArrayList<AllWords>>(){}.getType();
        return GsonInstance.getInstance().getGson().fromJson(json, listType);
    }





}
