package com.readboy.simpleLauncher.rewords.data.netRecords;

import java.util.List;

/**
 * Created by jng wong
 * on 2022/9/30 15:52
 */
public class BookReacordsData {
    Data data;
    int status;

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public class Data{
        int userId;
        List<Integer> bookIds;

        public int getUserId() {
            return userId;
        }

        public void setUserId(int userId) {
            this.userId = userId;
        }

        public List<Integer> getBookIds() {
            return bookIds;
        }

        public void setBookIds(List<Integer> bookIds) {
            this.bookIds = bookIds;
        }
    }

}
