package com.readboy.simpleLauncher.rewords.data.netRecords;

import com.readboy.simpleLauncher.rewords.data.book.BookDetails;

import java.util.List;

/**
 * Created by jng wong
 * on 2022/9/27 14:03
 */
public class CheckBookData {
    List<BookInfoData> data;

    public List<BookInfoData> getData() {
        return data;
    }

    public void setData(List<BookInfoData> data) {
        this.data = data;
    }

    public class BookInfoData{
        int id;
        BookDetails.WordPackage wordPackage;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public BookDetails.WordPackage getWordPackage() {
            return wordPackage;
        }

        public void setWordPackage(BookDetails.WordPackage wordPackage) {
            this.wordPackage = wordPackage;
        }
    }
}

