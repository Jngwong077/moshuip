package com.readboy.simpleLauncher.rewords.data.detail_word;

import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;

import java.util.ArrayList;

/**
 * Created by hjy on 2022/3/31 8:39
 */
public class DataWords {
    private ArrayList<DetailWords> data;

    public ArrayList<DetailWords> getData() {
        return data;
    }
}
