package com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

/**
 * Created by jng wong
 * on 2022/8/8 17:08
 */
@Database(entities = {DetailWords.class, NewWords.class, AllWords.class},version = 5,exportSchema=false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract DetailWordsDao detailWordsDao();
    public abstract NewWordsDao newWordsDao();
    public abstract AllWordsDao allWordsDao();
}
