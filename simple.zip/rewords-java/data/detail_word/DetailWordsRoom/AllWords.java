package com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;
import android.arch.persistence.room.TypeConverters;

import com.readboy.simpleLauncher.rewords.data.detail_word.WordPhrase;

import java.util.List;

/**
 * Created by jng wong
 * on 2022/9/29 9:21
 */
@Entity(tableName = "totalWords", indices = {@Index(value = "word", unique = true)})

public class AllWords {
    @PrimaryKey(autoGenerate = true)
    private int aid;
//    @ColumnInfo(name = "id")
//    private long wordId;
    private String word;                                //单词
    private String sync_explain;                        //简明释义
    private String explain;                             //全部释义
    private String uk_bs;                               //英式音标
    private String uk_word_sound;
    private String us_word_sound;
    private String us_bs;
    private String sentence;                            //例句
    private String sentence_explain;                    //例句释义

    @TypeConverters(WordPhraseTypeConverter.class)
    private List<WordPhrase> common_phrases;       //短语list


    public int getAid() {
        return aid;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }

//    public long getWordId() {
//        return wordId;
//    }
//
//    public void setWordId(long wordId) {
//        this.wordId = wordId;
//    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getSync_explain() {
        return sync_explain;
    }

    public void setSync_explain(String sync_explain) {
        this.sync_explain = sync_explain;
    }

    public String getExplain() {
        return explain;
    }

    public void setExplain(String explain) {
        this.explain = explain;
    }

    public String getUk_bs() {
        return uk_bs;
    }

    public void setUk_bs(String uk_bs) {
        this.uk_bs = uk_bs;
    }

    public String getUk_word_sound() {
        return uk_word_sound;
    }

    public void setUk_word_sound(String uk_word_sound) {
        this.uk_word_sound = uk_word_sound;
    }

    public String getUs_word_sound() {
        return us_word_sound;
    }

    public void setUs_word_sound(String us_word_sound) {
        this.us_word_sound = us_word_sound;
    }

    public String getUs_bs() {
        return us_bs;
    }

    public void setUs_bs(String us_bs) {
        this.us_bs = us_bs;
    }

    public String getSentence() {
        return sentence;
    }

    public void setSentence(String sentence) {
        this.sentence = sentence;
    }

    public String getSentence_explain() {
        return sentence_explain;
    }

    public void setSentence_explain(String sentence_explain) {
        this.sentence_explain = sentence_explain;
    }

    public List<WordPhrase> getCommon_phrases() {
        return common_phrases;
    }

    public void setCommon_phrases(List<WordPhrase> common_phrases) {
        this.common_phrases = common_phrases;
    }

}
