package com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom;

import android.arch.persistence.room.TypeConverter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.readboy.simpleLauncher.rewords.data.detail_word.WordPhrase;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;

/**
 * Created by jng wong
 * on 2022/8/9 9:16
 */
public class WordPhraseTypeConverter {
    Gson gson = new Gson();

    @TypeConverter
    public List<WordPhrase> stringToSomeObjectList(String data) {
        if (data == null) {
            return Collections.emptyList();
        }

        Type listType = new TypeToken<List<WordPhrase>>() {}.getType();

        return gson.fromJson(data, listType);
    }

    @TypeConverter
    public String someObjectListToString(List<WordPhrase> someObjects) {
        return gson.toJson(someObjects);
    }

}
