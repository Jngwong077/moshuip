package com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

/**
 * Created by jng wong
 * on 2022/8/8 17:09
 */
@Dao
public interface DetailWordsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(DetailWords detailWords);

    @Insert
    void insertAll(List<DetailWords> detailWordsList);

    /**
     *  查询数据库中是否包含该单词
     * @param word
     * @return
     */
    @Query("SELECT * FROM newRewords where word = :word")
    DetailWords getOne(String word);


    /**
     *  查询数据库中是否包含该单词
     * @param word
     * @return
     */
    @Query("SELECT * FROM newRewords where word = :word and uid = :uid")
    DetailWords getUserOne(String word, long uid);

    /**
     *  删除数据库中的单词
     * @param word
     */
    @Query("DELETe from newRewords WHERE word = :word")
    void delect(String word);

    /**
     *  删除复习库中所有的用户单词
     */
    @Query("DELETe from newRewords WHERE uid = :uid")
    void delectALL(long uid);


    /**
     *  获取数据库的所有数据
     * @return
     */
    @Query("SELECT * FROM newRewords WHERE uid = :uid")
    List<DetailWords> getAll(long uid);



    /**
     *  今日首次学习复习单词的获取
     * @return
     */
    @Query("SELECT * FROM newRewords where uid = :uid and appear <= 0  order by learnTime desc LIMIT 0, 30")
    List<DetailWords> getTodayFirstLearn(long uid);

    /**
     *  非今日首次学习复习单词的获取
     * @return
     */
    @Query("SELECT * FROM newRewords where uid = :uid and appear <= 0 order by learnTime LIMIT 0, 30")
    List<DetailWords> getUnFirstLearn(long uid);

    /**
     * 获取与用户有关联的章节单词
     * @param sectionId     章节ID
     * @param uid           用户ID
     * @return
     */
    @Query("SELECT * FROM newRewords where sectionId = :sectionId and isNewWord = 1 and uid = :uid")
    List<DetailWords> getSectionWord(int sectionId, int uid);

    @Query("SELECT * FROM newRewords where sectionId = :sectionId and uid = :uid")
    List<DetailWords> getSection(int sectionId, int uid);

    /**
     *  复习库中用户已学单词的获取
     * @return
     */
    @Query("SELECT * FROM newRewords where uid = :uid and  bookId = :bookid")
    List<DetailWords> getHaveLearnWord(int uid, int bookid);



    /**
     *  将数据库中的出现频率全部自减1
     */
    @Query("UPDATE newRewords SET appear = appear - 1 where learnTime < 8 and uid = :uid")
    void updateAll(long uid);

    /**
     *  修改为非新词和保存音频到本地
     * @param path          文件存储目录
     * @param word          单词
     */
    @Query("UPDATE newrewords Set isNewWord = 0, pathSound = :path where word = :word")
    void updateIsNewWord(String path, String word);


    /**
     *  单词非新词时的掌握更新数据库
     * @param appear        是否该出现   <0 即出现
     * @param learn         掌握次数/学习次数
     * @param word          单词
     */
    @Query("UPDATE newRewords SET appear = :appear, learnTime = :learn where word = :word")
    void updatecontrol(int appear, int learn,  String word);

    /**
     *  单词未掌握更新数据库
     * @param appear
     * @param learn
     * @param word
     */
    @Query("UPDATE newRewords SET appear = :appear, learnTime = :learn where word = :word")
    void updateUnControl(int appear, int learn, String word);


    /**
     *  单词为新词时的掌握更新数据库
     * @param appear
     * @param word
     */
    @Query("UPDATE newRewords SET appear = :appear, learnTime= 7, wrongClick = 1 where word = :word")
    void updateNewControl(int appear, String word);


    /**
     *   单词为新词时，误点了掌握处理
     * @param word
     */
    @Query("UPDATE newRewords SET wrongClick = 0 where word = :word")
    void updateWrongClick(String word);


    @Query("UPDATE newRewords SET sync_explain = :sync_explain, `explain` = :explain, uk_bs = :uk_bs, uk_word_sound = :uk_word_sound, " +
            "us_bs = :us_bs, us_word_sound = :us_word_sound, sentence = :sentence, sentence_explain = :sentence_explain, word_parse = :word_parse," +
            " word_parse_explain = :word_parse_explain, word_parse2 = :word_parse2, word_parse_explain2 = :word_parse_explain2 where word = :word")
    void updateCheckWord(String word, String sync_explain, String explain, String uk_bs, String uk_word_sound,
                        String us_bs, String us_word_sound, String sentence, String sentence_explain, String word_parse,
                         String word_parse_explain, String word_parse2, String word_parse_explain2);

    @Update
    void updateData(DetailWords detailWords);



}
