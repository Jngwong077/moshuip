package com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import java.util.List;

import retrofit2.http.DELETE;

/**
 * Created by jng wong
 * on 2022/9/29 9:26
 */
@Dao
public interface AllWordsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<AllWords> words);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(AllWords words);

    @Query("DELETE from totalWords ")
    void deleteAll();


    @Query("SELECT * FROM totalWords")
    List<AllWords> getAll();

    @Query("select * from totalWords where word = :word")
    AllWords getData(String word);

}
