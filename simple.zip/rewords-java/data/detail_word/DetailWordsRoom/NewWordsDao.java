package com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import retrofit2.http.DELETE;

/**
 * Created by jng wong
 * on 2022/8/17 9:09
 */
@Dao
public interface NewWordsDao {



    @Insert
    void insert(NewWords newWords);

    @Query("select * from newWords")
    List<DetailWords> getAll();

    @Query("DELETe from newWords WHERE word = :word")
    void delete(String word);

    @Query("DELETe from newWords ")
    void deleteAll();

    @Query("select * from newWords where word = :word")
    NewWords getIsExit(String word);


}
