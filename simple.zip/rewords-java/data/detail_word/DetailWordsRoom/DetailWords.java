package com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;
import android.arch.persistence.room.TypeConverters;
import android.support.v4.view.ViewCompat;

import com.readboy.simpleLauncher.rewords.data.detail_word.WordPhrase;

import java.util.List;

/**
 * Created by hjy on 2022/3/31 15:05
 */
//, indices = {@Index(value = "word", unique = true)}
@Entity(tableName = "newRewords")
public class DetailWords {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private long sectionId;      //章节id
    private long uid;            //用户id

    private int bookId;         //课本id
    private int isFromNet;      //是否来自服务器

    private int isNewWord;      //单元生词
    private int isControl;      //掌握了
    private int learnTime;    //掌握次数
    private String pathSound;   //音频位置
    private int appear;         //小于等于0时即出现
    private int wrongClick;          //是否错误点击

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookId() {

        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getIsFromNet() {
        return isFromNet;
    }

    public void setIsFromNet(int isFromNet) {
        this.isFromNet = isFromNet;
    }

    public int getAppear() {
        return appear;
    }

    public void setAppear(int appear) {
        this.appear = appear;
    }

    public int getWrongClick() {
        return wrongClick;
    }

    public void setWrongClick(int wrongClick) {
        this.wrongClick = wrongClick;
    }

    public int getIsNewWord() {
        return isNewWord;
    }

    public void setIsNewWord(int isNewWord) {
        this.isNewWord = isNewWord;
    }

    public int getIsControl() {
        return isControl;
    }

    public void setIsControl(int isControl) {
        this.isControl = isControl;
    }

    public String getPathSound() {
        return pathSound;
    }

    public void setPathSound(String pathSound) {
        this.pathSound = pathSound;
    }

    public int getLearnTime() {
        return learnTime;
    }

    public void setLearnTime(int learnTime) {
        this.learnTime = learnTime;
    }

    private String word;                                //单词
    private String sync_explain;                        //简明释义
    private String explain;                             //全部释义
    private String uk_bs;                               //英式音标
    private String uk_word_sound;
    private String us_word_sound;
    private String us_bs;
    private String sentence;                            //例句
    private String sentence_explain;                    //例句释义

    @TypeConverters(WordPhraseTypeConverter.class)
    private List<WordPhrase> common_phrases;       //短语list
    private String word_parse;                          //短语1
    private String word_parse_explain;
    private String word_parse2;                         //短语2
    private String word_parse_explain2;

    public long getSectionId() {
        return sectionId;
    }

    public void setSectionId(long sectionId) {
        this.sectionId = sectionId;
    }

    public long getUid() {
        return uid;
    }

    public void setUid(long uid) {
        this.uid = uid;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getExplain() {
        return explain;
    }

    public void setExplain(String explain) {
        this.explain = explain;
    }

    public String getSync_explain() {
        return sync_explain;
    }

    public void setSync_explain(String sync_explain) {
        this.sync_explain = sync_explain;
    }

    public String getUk_bs() {
        return uk_bs;
    }

    public void setUk_bs(String uk_bs) {
        this.uk_bs = uk_bs;
    }

    public String getUk_word_sound() {
        return uk_word_sound;
    }

    public void setUk_word_sound(String uk_word_sound) {
        this.uk_word_sound = uk_word_sound;
    }

    public String getUs_word_sound() {
        return us_word_sound;
    }

    public void setUs_word_sound(String us_word_sound) {
        this.us_word_sound = us_word_sound;
    }

    public String getUs_bs() {
        return us_bs;
    }

    public void setUs_bs(String us_bs) {
        this.us_bs = us_bs;
    }


    public String getSentence() {
        return sentence;
    }

    public void setSentence(String sentence) {
        this.sentence = sentence;
    }

    public String getSentence_explain() {
        return sentence_explain;
    }

    public void setSentence_explain(String sentence_explain) {
        this.sentence_explain = sentence_explain;
    }

    public List<WordPhrase> getCommon_phrases() {
        return common_phrases;
    }

    public void setCommon_phrases(List<WordPhrase> common_phrases) {
        this.common_phrases = common_phrases;
    }

    public String getWord_parse() {
        return word_parse;
    }

    public void setWord_parse(String word_parse) {
        this.word_parse = word_parse;
    }

    public String getWord_parse_explain() {
        return word_parse_explain;
    }

    public void setWord_parse_explain(String word_parse_explain) {
        this.word_parse_explain = word_parse_explain;
    }

    public String getWord_parse2() {
        return word_parse2;
    }

    public void setWord_parse2(String word_parse2) {
        this.word_parse2 = word_parse2;
    }

    public String getWord_parse_explain2() {
        return word_parse_explain2;
    }

    public void setWord_parse_explain2(String word_parse_explain2) {
        this.word_parse_explain2 = word_parse_explain2;
    }



}
