package com.readboy.simpleLauncher.rewords.data.detail_word;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by hjy on 2022/4/7 11:21
 */
public class WordPhrase implements Serializable {
    ArrayList<Content> content;

    public WordPhrase(ArrayList<Content> content) {
        this.content = content;
    }

    public ArrayList<Content> getContent() {
        return content;
    }

    public class Content implements Serializable {
        String text;
        String paraphrase;

        public String getText() {
            return text;
        }

        public String getParaphrase() {
            return paraphrase;
        }
    }

}