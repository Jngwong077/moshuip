package com.readboy.simpleLauncher.rewords.data.detail_word;

import android.arch.persistence.room.Room;
import android.content.Context;

import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AppDatabase;

/**
 * Created by jng wong
 * on 2022/10/8 10:32
 */
public class DBInstance {
    public static AppDatabase initDb(Context context){
        AppDatabase db;
        db = Room.databaseBuilder(context, AppDatabase.class, "newRewords.db" )
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();
        return db;
    }
}
