package com.readboy.simpleLauncher.rewords.data.user_words;

/**
 * Created by hjy on 2022/3/31 15:03
 */
public  class UserWords{
    private String word;

    public UserWords(String word) {
        this.word = word;
    }
    public String getWords() {
        return word;
    }
}