package com.readboy.simpleLauncher.rewords.data.user_words;



import java.util.ArrayList;

/**
 * Created by hjy on 2022/3/30 14:33
 */
public class DataUserWords {
    private String msg;
    private int ok;
    private UserWordsData data;


    public DataUserWords(String msg, int ok, UserWordsData data) {
        this.msg = msg;
        this.ok = ok;
        this.data = data;
    }
    public String getMsg() {
        return msg;
    }

    public int getOk() {
        return ok;
    }

    public UserWordsData getData() {
        return data;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setOk(int ok) {
        this.ok = ok;
    }

    public void setData(UserWordsData data) {
        this.data = data;
    }
}
