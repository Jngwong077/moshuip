package com.readboy.simpleLauncher.rewords.data.user_words;

import java.util.ArrayList;

/**
 * Created by hjy on 2022/3/31 15:02
 */
public   class DailyWords{
    private int hardWordCount;
    private int studyAgainWordCount;
    private ArrayList<UserWords> words;

    public DailyWords(int hardWordCount, int studyAgainWordCount, ArrayList<UserWords> words) {
        this.hardWordCount = hardWordCount;
        this.studyAgainWordCount = studyAgainWordCount;
        this.words = words;
    }

    public int getStudyAgainWordCount() {
        return studyAgainWordCount;
    }

    public int getHardWordCount() {
        return hardWordCount;
    }

    public ArrayList<UserWords> getWords() {
        return words;
    }



}
