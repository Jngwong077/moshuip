package com.readboy.simpleLauncher.rewords.data.user_words;

import java.util.ArrayList;

/**
 * Created by hjy on 2022/3/31 15:01
 */
public  class UserWordsData {
    private int total;
    private DailyWords dailyWord;

    public UserWordsData(int total, DailyWords dailyWord) {
        this.total = total;
        this.dailyWord = dailyWord;
    }

    public int getTotal() {
        return total;
    }

    public DailyWords getDailyWords() {
        return dailyWord;
    }


}