package com.readboy.simpleLauncher.rewords.data.book;

import java.util.ArrayList;

/**
 * Created by hjy on 2022/4/14 14:53
 */
public class PageData {
    ArrayList<Pages> data;

    public ArrayList<Pages> getData() {
        return data;
    }

    public class Pages{
        String pagenum;
        int sid;

        public String getPagenum() {
            return pagenum;
        }

        public int getSid() {
            return sid;
        }
    }
}
