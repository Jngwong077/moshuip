package com.readboy.simpleLauncher.rewords.data.book;

import java.util.ArrayList;

/**
 * Created by hjy on 2022/4/8 11:05
 */
public class CatalogueData {
    String msg;
    Catalogue data;
    int ok;

    public CatalogueData(String msg, Catalogue data, int ok) {
        this.msg = msg;
        this.data = data;
        this.ok = ok;
    }

    public Catalogue getData() {
        return data;
    }

    public class Catalogue{
        BookDetail books;

        public Catalogue(BookDetail books) {
            this.books = books;
        }

        public BookDetail getBooks() {
            return books;
        }

        public class BookDetail{
            ArrayList<Children> children;

            public BookDetail(ArrayList<Children> children) {
                this.children = children;
            }

            public ArrayList<Children> getChildren() {
                return children;
            }
        }
    }


}
