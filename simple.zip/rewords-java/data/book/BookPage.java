package com.readboy.simpleLauncher.rewords.data.book;

/**
 * Created by hjy on 2022/4/14 14:49
 */
public class BookPage {
    String msg;
    BookPageData data;
    int ok;

    public BookPageData getData() {
        return data;
    }

    public class BookPageData{
        Books book;

        public Books getBook() {
            return book;
        }

        public class Books{
            PageData page;

            public PageData getPage() {
                return page;
            }
        }

    }
}
