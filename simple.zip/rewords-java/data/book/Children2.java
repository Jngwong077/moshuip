package com.readboy.simpleLauncher.rewords.data.book;


import java.util.ArrayList;

/**
 * Created by hjy on 2022/4/11 19:23
 */
public class Children2 {
    ArrayList<String> word;
    String name;
    int id;

    public Children2(ArrayList<String> word, String name, int id) {
        this.word = word;
        this.name = name;
        this.id = id;
    }

    public ArrayList<String> getWord() {
        return word;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public void setWord(ArrayList<String> word) {
        this.word = word;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }
}
