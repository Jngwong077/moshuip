package com.readboy.simpleLauncher.rewords.data.book;

public class BookData {
    private BookListInfo data;
    private String msg;
    private int ok;

    public BookListInfo getData() {
        return data;
    }

    public void setData(BookListInfo data) {
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getOk() {
        return ok;
    }

    public void setOk(int ok) {
        this.ok = ok;
    }
}
