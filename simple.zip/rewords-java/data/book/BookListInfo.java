package com.readboy.simpleLauncher.rewords.data.book;

import java.util.List;

/**
 * 搜索教材时的书本列表
 */
public class BookListInfo {
    private boolean is_end;
    private List<BookDetails> books;

    public boolean isIs_end() {
        return is_end;
    }

    public void setIs_end(boolean is_end) {
        this.is_end = is_end;
    }

    public List<BookDetails> getBooks() {
        return books;
    }

    public void setBooks(List<BookDetails> books) {
        this.books = books;
    }
}
