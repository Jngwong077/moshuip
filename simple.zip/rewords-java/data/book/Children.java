package com.readboy.simpleLauncher.rewords.data.book;

import java.util.ArrayList;

/**
 * Created by hjy on 2022/4/8 14:05
 */
public class Children {
    ArrayList<String> word;
    String name;
    int id;
    ArrayList<Children2> children;

    public Children(ArrayList<String> word, String name, int id, ArrayList<Children2> children) {
        this.word = word;
        this.name = name;
        this.id = id;
        this.children = children;
    }

    public ArrayList<Children2> getChildren() {
        return children;
    }

    public void setChildren(ArrayList<Children2> children) {
        this.children = children;
    }



    public ArrayList<String> getWord() {
        return word;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public void setWord(ArrayList<String> word) {
        this.word = word;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

}
