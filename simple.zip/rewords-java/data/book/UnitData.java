package com.readboy.simpleLauncher.rewords.data.book;

import android.arch.persistence.room.Ignore;

import com.google.gson.annotations.SerializedName;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by hjy on 2022/5/26 10:41
 */
public class UnitData extends LitePalSupport implements Serializable {
    @SerializedName("id")
    int bid;
    String name;
    Editions edition;
    @Ignore
    ArrayList<Children> children;
    String data;



    public class Editions{
        String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int id) {
        this.bid = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Editions getEdition() {
        return edition;
    }

    public void setEdition(Editions edition) {
        this.edition = edition;
    }

    public ArrayList<Children> getChildren() {
        return children;
    }

    public void setChildren(ArrayList<Children> children) {
        this.children = children;
    }
}
