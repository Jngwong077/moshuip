package com.readboy.simpleLauncher.rewords.data.book;


import com.google.gson.annotations.SerializedName;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;

/**
 * Created by hjy on 2022/4/9 9:31
 */
public class BookDetails  extends LitePalSupport implements Serializable {
    String name;
    String cover;
    String gradeName;
    //字段id与接口相同时，使用  SerializedName
    @SerializedName("id")
    int bid;
    int grade;
    Edition edition;
    String packageUri;
    WordPackage wordPackage;
    String wordPackageUri;
    long updateTime;

    public String getWordPackageUri() {
        return wordPackageUri;
    }

    public void setWordPackageUri(String wordPackageUri) {
        this.wordPackageUri = wordPackageUri;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGradeName() {
        return gradeName;
    }

    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public Edition getEdition() {
        return edition;
    }

    public void setEdition(Edition edition) {
        this.edition = edition;
    }

    public class Edition{
        String name;

        public String getName() {
            return name;
        }
    }

    public String getPackageUri() {
        return packageUri;
    }

    public void setPackageUri(String packageUri) {
        this.packageUri = packageUri;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    public WordPackage getWordPackage() {
        return wordPackage;
    }

    public void setWordPackage(WordPackage wordPackage) {
        this.wordPackage = wordPackage;
    }

    public class  WordPackage{
        String packageUri;
        long updateTime;
        public String getPackageUri() {
            return packageUri;
        }

        public void setPackageUri(String packageUri) {
            this.packageUri = packageUri;
        }

        public long getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(long updateTime) {
            this.updateTime = updateTime;
        }
    }

}
