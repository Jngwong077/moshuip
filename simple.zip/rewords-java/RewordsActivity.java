package com.readboy.simpleLauncher.rewords;

import static com.readboy.practiselistening.utils.LogUtil.w;
import static com.readboy.simpleLauncher.rewords.tool.Logger.e;
import static com.readboy.simpleLauncher.rewords.tool.TimeProcess.isTodayFirstLearn;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.arch.persistence.room.Room;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.apkfuns.logutils.LogUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.readboy.simpleLauncher.Main_UI.Fragment.Tool.ToastUtil;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.aiconversation.utils.SystemPropertiesInvoke;
import com.readboy.simpleLauncher.rewords.complete.CompleteActivity;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AppDatabase;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWordsDao;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.NewWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.NewWordsDao;
import com.readboy.simpleLauncher.rewords.download.HttpDownloader;
import com.readboy.simpleLauncher.rewords.fragment.Fragment_Rewords;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.Logger;
import com.readboy.simpleLauncher.rewords.tool.PlayWordSound;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;

public class RewordsActivity extends AppCompatActivity implements View.OnClickListener {
    private final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private String TAG = "RewordsActivity";
    private int START_TYPE;
    private int uid, sectionId;
    private int totalWord;
    private int number = 0;
    private int hardWordCount, studyAgainWordCount, recoverCount;
    private boolean next = false;

    private ArrayList<String> unitWords = new ArrayList<>();
    private ArrayList<String> recoverWords = new ArrayList<>();
    private List<DetailWords> detailWords = new ArrayList<>();
    private ArrayList<DetailWords> totalWordList = new ArrayList<>();
    private ArrayList<Integer> sectionIds = new ArrayList<>();

    TextView btn_back;
    TextView hard_word,study_again_word, recover_word;
    TextView learned_word, total_word, word, word_pronunciation, btn_modify;
    TextView word_explain, word_phrase, word_phrase_explain, word_phrase2, word_phrase_explain2, word_sentence, word_sentence_explain;
    ConstraintLayout img_word_play;

    Button btn_control, btn_un_control, btn_next;
    ConstraintLayout cl_hand, cl_scroll_view;
    RelativeLayout rl_phrase, rl_explain, rl_word;
    ScrollView sc_view;

    // 插拔是否注册
    private boolean mReceiverTag = false;
    private static final String BROADCAST_INK_PAD_PLUG = "com.readboy.intent.action.InkPadPlug";

    /*      不出现重复元素的数组      */
    LinkedHashSet<String> hashSet = new LinkedHashSet<>();

    SettingSharePreference sharePreference;

    DetailWordsDao wordsDao;
    NewWordsDao newWordsDao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharePreference = new SettingSharePreference(this);
        //全透明实现
        Config.FLAG_TRANSLUCENT_STATUS(getWindow());

        setContentView(R.layout.activity_rewords);
        AppDatabase db;
        db = Room.databaseBuilder(RewordsActivity.this, AppDatabase.class, "newRewords.db" )
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();
        wordsDao = db.detailWordsDao();

        newWordsDao = db.newWordsDao();
        initView();


        /*       插拔监听       */
        IntentFilter filter = new IntentFilter();
        filter.addAction(BROADCAST_INK_PAD_PLUG);
        mReceiverTag = true;
        registerReceiver(mReceiver, filter);
    }

    @SuppressLint({"NonConstantResourceId", "SetTextI18n"})
    @Override
    public void onClick(View v) {
        if (Config.isFastDoubleClick()) return;//防止快速点击
        switch (v.getId()){
            case R.id.back_text:
                if (number <= detailWords.size())
                    Config.TEMPORARY_WORD = detailWords.subList(number, detailWords.size());
                Log.e(TAG, "detailWords:Config.TEMPORARY_WORD   " + Config.TEMPORARY_WORD );
                finish();
                break;
            case R.id.btn_control:
                if (detailWords.size() != 0){
                    /*          生词库减一，复习库加一       */
                    if (newWordsDao.getIsExit(detailWords.get(number).getWord()) != null){
                        newWordsDao.delete(detailWords.get(number).getWord());
                        wordsDao.insert(detailWords.get(number));
                    }

                    //第一次使用点击掌握时出现的
                    if (sharePreference.getBoolean("first_click", true)){
                        sharePreference.putBoolean("first_click", false);
                        sharePreference.commit();
                        AlertDialog.Builder dialog = new AlertDialog.Builder(RewordsActivity.this);
                        dialog.setTitle("提示");
                        dialog.setMessage("已经掌握的单词会减少学习的次数");
                        dialog.setCancelable(true);
                        dialog.setPositiveButton("我知道了", null);
                        dialog.show();
                    }

                    if (recoverCount + studyAgainWordCount == totalWord && studyAgainWordCount > 0){
                        recoverCount++;
                        studyAgainWordCount--;
                        study_again_word.setText("" + studyAgainWordCount);
                        recover_word.setText("" + recoverCount);
                    } else if (recoverCount <= totalWord){
                        recoverCount++;
                        recover_word.setText("" + recoverCount);
                    } else
                        recover_word.setText("" + totalWord);
//                    HttpUtil.uploadWordStudy(uid, detailWords.get(number).getWord(), 1);
                    PlayWordSound.stop();

                    hashSet.add(detailWords.get(number).getWord());
                    /*          点击掌握时的数据库更新     */
                    controlDeal(true);
                    Random ra = new Random();
                    int random = ra.nextInt(Config.WORD_APPEAR_RAN_MAX - Config.WORD_APPEAR_RAN_MIN) + Config.WORD_APPEAR_RAN_MIN;
                    Log.w(TAG, "random: " + random  + "  learn: " + learn);
                    if (detailWords.get(number).getIsNewWord() == 0) {
                        wordsDao.updatecontrol(appear, learn, detailWords.get(number).getWord());
                        detailWords.get(number).setLearnTime(learn);
                    } else {
                        wordsDao.updateNewControl(random, detailWords.get(number).getWord());
                        detailWords.get(number).setLearnTime(7);
                    }

//                    detailWords.get(number).setLearnTime(simpleDateFormat.format(date));
//                    detailWords.get(number).setIsNewWord(0);
//                    detailWords.get(number).save();
                    saveRecoverWordSound();
                    Log.d(TAG, "onClick: getWord" + detailWords.get(number).getWord());

                    //设置当前单词掌握时间，方便后续复习该单词
                    Date date = new Date(System.currentTimeMillis());
                    Log.d(TAG, "onClick: simpleDateFormat.format(date)" + simpleDateFormat.format(date));

                    if (rl_explain.getVisibility() == View.VISIBLE){
                        number++;
                        //跳转到完成界面
                        if (number == detailWords.size()){
                            Log.d(TAG, "goLearning: totalWordList.size()2222  " + totalWordList.size());
                            Intent intent = new Intent();
                            intent.setClass(RewordsActivity.this, CompleteActivity.class);
                            ArrayList<String> haveLearningWord = new ArrayList<>(hashSet);
                            intent.putStringArrayListExtra("detailWords", haveLearningWord);
                            startActivity(intent);
                            finish();
                            break;
                        }

                        LogUtils.i( detailWords.get(number).getWord() + number);

                        initData();
                        btn_control.setVisibility(View.VISIBLE);
                        btn_un_control.setVisibility(View.VISIBLE);
                        btn_modify.setVisibility(View.INVISIBLE);
                    } else {
                        phraseNoUS();
                        btn_modify.setText("掌握");
                        btn_modify.setVisibility(View.VISIBLE);
                        btn_next.setVisibility(View.VISIBLE);
                        cl_hand.setVisibility(View.INVISIBLE);
                        rl_explain.setVisibility(View.VISIBLE);
                        btn_control.setVisibility(View.INVISIBLE);
                        btn_un_control.setVisibility(View.INVISIBLE);
                    }

                }
                break;
            case R.id.btn_un_control:
                PlayWordSound.stop();
                detailWords.get(number).setIsNewWord(0);
                /*          生词库减一，复习库加一       */
                if (newWordsDao.getIsExit(detailWords.get(number).getWord()) != null){
                    newWordsDao.delete(detailWords.get(number).getWord());
                    wordsDao.insert(detailWords.get(number));
                }

//                if (detailWords.size() != 0 && cl_hand.getVisibility() == View.VISIBLE)
                if (detailWords.size() != 0){
                    //由于接口短语美式读音为空，故判断当前读音是否是美式，美式的就拿英式去发音
                    phraseNoUS();
                    detailWords.add(detailWords.get(number));
                    hashSet.add(detailWords.get(number).getWord());

                }
                phraseNoUS();
                PlayWordSound.stop();
//                detailWords.get(number).setIsControl(1);
//                detailWords.get(number).setControlTime(0);
//                detailWords.get(number).setIsNewWord(0);
                /*          未掌握时的数据库更新       */
                controlDeal(false);
                if (detailWords.get(number).getLearnTime() > 0){
                    wordsDao.updateUnControl(appear, learn, detailWords.get(number).getWord());
                    detailWords.get(number).setLearnTime(learn);
                }
                /*          保存单词音频              */
                saveRecoverWordSound();

                /*          当未掌握数为5个时，跳到只学习这5个直到全部掌握        */
                if (Config.UN_CONTROL_NUMBER < 5)
                    Config.UN_CONTROL_NUMBER++;

                if (Config.UN_CONTROL_NUMBER >= 5){
                    if (detailWords.size() > 5)
                        number = detailWords.size() - 6;
                    for (int i = number; i < detailWords.size(); i++)
                        Log.e(TAG, "detailWords:number  " + detailWords.get(i).getWord() );
                }

//                if (detailWords.size() != 0){
//                    phraseNoUS();
//                    PlayWordSound.stop();
//                    detailWords.get(number).setIsControl(1);
//                    detailWords.get(number).setControlTime(0);
//
//                    detailWords.get(number).setIsNewWord(0);
//                    saveRecoverWordSound();
////                        number++;
////                        LogUtils.i( detailWords.get(number).getWord() + number);
////                        initData();
//                    //利用数据库记录是否为单元生词，0则不是生词，1是生词
//
//                }
//                cl_hand.setVisibility(View.INVISIBLE);
//                rl_explain.setVisibility(View.VISIBLE);
//                btn_next.setVisibility(View.VISIBLE);
//                btn_control.setVisibility(View.INVISIBLE);
//                btn_un_control.setVisibility(View.INVISIBLE);

                if (rl_explain.getVisibility() == View.VISIBLE){
                    if (detailWords.size() != 0){

//                        phraseNoUS();
//                        PlayWordSound.stop();
//                        detailWords.get(number).setIsControl(1);
//                        detailWords.get(number).setControlTime(0);
//
//                        detailWords.get(number).setIsNewWord(0);
//                        saveRecoverWordSound();
                        number++;
                        LogUtils.i( detailWords.get(number).getWord() + number);
                        initData();

                        //利用数据库记录是否为单元生词，0则不是生词，1是生词

                    }
//                    btn_next.setVisibility(View.VISIBLE);
                    btn_control.setVisibility(View.VISIBLE);
                    btn_un_control.setVisibility(View.VISIBLE);
                    btn_modify.setVisibility(View.INVISIBLE);

                } else {
                    next = true;
                    btn_modify.setText("未掌握");
                    btn_modify.setVisibility(View.VISIBLE);
                    btn_next.setVisibility(View.VISIBLE);
                    cl_hand.setVisibility(View.INVISIBLE);
                    rl_explain.setVisibility(View.VISIBLE);
                    btn_control.setVisibility(View.INVISIBLE);
                    btn_un_control.setVisibility(View.INVISIBLE);
                }
                Log.w(TAG, "nextnextnext: " + next + "     " +  studyAgainWordCount + "     " + totalWord);
                if (next){
                    next = false;
                    if (number <= totalWord)
                        if (studyAgainWordCount + recoverCount == totalWord && recoverCount > 0){
                            studyAgainWordCount++;
                            recoverCount--;
                            study_again_word.setText("" + studyAgainWordCount);
                            recover_word.setText("" + recoverCount);
                        } else if (studyAgainWordCount < totalWord){
                            studyAgainWordCount++;
                            study_again_word.setText("" + studyAgainWordCount);
                        } else
                            study_again_word.setText("" + totalWord);
                }
                break;
            case R.id.btn_next:
                if (detailWords.size() != 0){
                    PlayWordSound.stop();
                    number++;
                    //跳转到完成界面
                    if (number == detailWords.size()){
                        Intent intent = new Intent();
                        intent.setClass(RewordsActivity.this, CompleteActivity.class);
                        ArrayList<String> haveLearningWord = new ArrayList<>(hashSet);
                        intent.putStringArrayListExtra("detailWords", haveLearningWord);
                        startActivity(intent);
                        finish();
                        break;
                    }

                    LogUtils.i( detailWords.get(number).getWord() + number);
                    initData();
                }
                btn_modify.setVisibility(View.INVISIBLE);
                btn_next.setVisibility(View.INVISIBLE);
                btn_control.setVisibility(View.VISIBLE);
                btn_un_control.setVisibility(View.VISIBLE);
                break;
            case R.id.btn_modify:
                int item;
                if (btn_modify.getText() == "未掌握"){
                    item = 1;
                } else
                    item = 0;

                AlertDialog.Builder dialog = new AlertDialog.Builder(RewordsActivity.this);
                dialog.setTitle("单词状态");
                dialog.setSingleChoiceItems(status, item, (d, which) -> {
                    if (which == 0){
                        btn_modify.setText("掌握");
//                        controlDeal();
                        Log.d(TAG, "onClick: getWord" + detailWords.get(number).getWord());
//                        //设置当前单词掌握时间，方便后续复习该单词
//                        Date date = new Date(System.currentTimeMillis());
//                        Log.d(TAG, "onClick: simpleDateFormat.format(date)" + simpleDateFormat.format(date));
//                        detailWords.get(number).setLearnTime(simpleDateFormat.format(date));
//                        detailWords.get(number).setIsNewWord(0);
//                        detailWords.get(number).save();
                        /*           掌握时的数据库更新       */
                        controlDeal(true);
                        detailWords.get(number).setLearnTime(learn);
                        Random ra = new Random();
                        int random = ra.nextInt(Config.WORD_APPEAR_RAN_MAX - Config.WORD_APPEAR_RAN_MIN) + Config.WORD_APPEAR_RAN_MIN;
                        Log.w(TAG, "random: " + random );
                        if (detailWords.get(number).getIsNewWord() == 0) {
                            wordsDao.updatecontrol(appear, learn, detailWords.get(number).getWord());
                        } else
                            wordsDao.updateNewControl(random, detailWords.get(number).getWord());
                    } else {
                        btn_modify.setText("未掌握");
                        detailWords.add(detailWords.get(number));
                        /*          未掌握时的数据库更新      */
                        controlDeal(false);
                        if (detailWords.get(number).getLearnTime() > 0)
                            wordsDao.updateUnControl(appear, learn, detailWords.get(number).getWord());
//                        detailWords.get(number).setIsControl(1);
//                        detailWords.get(number).setControlTime(0);
//                        detailWords.get(number).setIsNewWord(0);
//                        detailWords.get(number).save();
                    }
                    d.dismiss();
                });

                dialog.setCancelable(true);
                dialog.show();

                break;
            case R.id.cl_hand:
                cl_hand.setVisibility(View.INVISIBLE);
                rl_explain.setVisibility(View.VISIBLE);
                break;
            case R.id.rl_explain:
            case R.id.scroll_view:
                cl_hand.setVisibility(View.VISIBLE);
                rl_explain.setVisibility(View.INVISIBLE);
                break;
            case R.id.cl_sound:
                PlayWordSound.stop();
                if (detailWords.size() != 0){
                    //由于接口短语美式读音为空，故判断当前读音是否是美式，美式的就拿英式去发音
                    phraseNoUS();
                }
                break;
            case R.id.rl_word:
                Log.w(TAG, "clicks: " + clicks );
                clicks++;
                if (clicks > 10)
                    coverReWord();
                break;
        }

    }

    int clicks;

    String[] status = new String[] { "掌握", "未掌握" };
    @SuppressLint("SetTextI18n")
    private void initData(){
        sc_view.scrollTo(0,0);
        next = true;
        if (number >= totalWord){
            learned_word.setText("" + totalWord);
        } else
            learned_word.setText("" + number);
        cl_hand.setVisibility(View.VISIBLE);
        rl_explain.setVisibility(View.INVISIBLE);
        if (detailWords.size() != 0){
            if (!sharePreference.getBoolean("is_auto_read", true)){
                if (!sharePreference.getBoolean("word_sound_is_en", true)) {
                    String text = detailWords.get(number).getUs_bs().equals("") ? detailWords.get(number).getUk_bs() : detailWords.get(number).getUs_bs();
                    word_pronunciation.setText(text);
                } else
                    word_pronunciation.setText(detailWords.get(number).getUk_bs());
            } else
                phraseNoUS();

            word.setText(detailWords.get(number).getWord());
            word_explain.setText(detailWords.get(number).getExplain());
            word_sentence.setText(detailWords.get(number).getSentence());
            word_sentence_explain.setText(detailWords.get(number).getSentence_explain());
            rl_phrase.setVisibility(View.VISIBLE);
            //单词短语处理，最多显示两个短语
            if (detailWords.get(number).getWord_parse() != null && !detailWords.get(number).getWord_parse().equals("")){
                word_phrase.setText(detailWords.get(number).getWord_parse());
                word_phrase_explain.setText(detailWords.get(number).getWord_parse_explain());
                if (detailWords.get(number).getWord_parse2() != null && !detailWords.get(number).getWord_parse2().equals("")){
                    word_phrase2.setText(detailWords.get(number).getWord_parse2());
                    word_phrase_explain2.setText(detailWords.get(number).getWord_parse_explain2());
                } else {
                    word_phrase2.setVisibility(View.GONE);
                    word_phrase_explain2.setVisibility(View.GONE);
                }
            } else
                rl_phrase.setVisibility(View.GONE);
        }

    }

    List<DetailWords> words = new ArrayList<>();
    ArrayList<DetailWords> newWordList = new ArrayList<>();
    List<DetailWords> rWords = new ArrayList<>();



    @SuppressLint("StaticFieldLeak")
    private class wordAsyncTask extends AsyncTask<String, Void, Void>{
        @Override
        protected Void doInBackground(String... strings) {
            if (words.size() != 0) words.clear();

//            DetailWords detail = dao.getOne("bag");
//            Log.w(TAG, "detail: " + detail );
//            Log.w(TAG, "detail.getWord: " + "   " + detail.getId()  );

//            if (START_TYPE == Config.BACK_CONTINUE_START){
//                detailWords = Config.TEMPORARY_WORD;
//                Log.w(TAG, "detailWords.size: " + Config.TEMPORARY_WORD.size());
//            } else {
//                if (wordsDao.getAll().size() != 0 && START_TYPE != Config.BACK_CONTINUE_START)
//                    wordsDao.updateAll();
                detailWords.addAll(newWordsDao.getAll());

                Log.w(TAG, "detailWords before: " + detailWords.size() + " isTodayFirstLearn " + isTodayFirstLearn(RewordsActivity.this) );

                if (detailWords.size() < Config.WORD_NUMBER) {
//                    if (isTodayFirstLearn(RewordsActivity.this)){
//                        detailWords.addAll(wordsDao.getTodayFirstLearn());
//
//                    } else {
//                        detailWords.addAll(wordsDao.getUnFirstLearn());
//                    }

                    if (words.size() != 0)
                        detailWords.addAll(words);

                    if (detailWords.size() > Config.WORD_NUMBER)
                        detailWords = detailWords.subList(0, Config.WORD_NUMBER);
                }



//            if (words.size() != 0) words.clear();
//            words = LitePal.where("uid = ? and sectionId = ?", String.valueOf(uid), String.valueOf(sectionId)).find(DetailWords.class);
//            Log.d(TAG, "doInBackground: " + words.size());
//            if (words.size() != 0){
//                for (DetailWords w: words){
//                    if (w.getIsNewWord() == 1)
//                        newWordList.add(w);
//                }
//                Log.d(TAG, "doInBackground: newWordList.size  " + newWordList.size());
//                detailWords.addAll(newWordList);
//                totalWordList.addAll(newWordList);
//            } else{
//                saveWordData();
//                if (word != null && words.size() != 0) words.clear();
//                words = LitePal.where("uid = ? and sectionId = ?", String.valueOf(uid), String.valueOf(sectionId)).find(DetailWords.class);
//                detailWords.addAll(words);
//                totalWordList.addAll(words);
//            }
//
//            rWords = LitePal.where("uid = ? and iscontrol = ?", String.valueOf(uid), String.valueOf(1)).find(DetailWords.class);
//            Log.d(TAG, "doInBackground:  rWords.size   " + rWords.size());
//            if (rWords.size() != 0 && rWords.size() > 20){
//                for (int i = 0; i < 20; i ++){
//                    detailWords.add(rWords.get(i));
//                    totalWordList.add(rWords.get(i));
//                }
//            } else{
//                detailWords.addAll(rWords);
//                totalWordList.addAll(rWords);
//            }

            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            totalWord = detailWords.size();
            total_word.setText("/" + totalWord);
            initData();
            next = false;
      }

    }

    //对于用户单词不存在该单词数据的处理
    private void toFindWordIsExist(ArrayList<String> list){
        List<DetailWords> find =  newWordsDao.getAll();
        List<String> noFindWordList = new ArrayList<>();
        boolean isExist = false;
        for (int i = 0; i < find.size(); i++){
            for (String str : list){
                isExist = false;
                if (str.equals(find.get(i).getWord())){
                    isExist = true;
                    break;
                }
            }

            if (!isExist)
                noFindWordList.add(find.get(i).getWord());
        }

        Log.d(TAG, "noFindWordList : " + noFindWordList);

        for (String str : noFindWordList)
            newWordsDao.delete(str);

    }

    String recoverWordSound;
    String uWord;
    File ukSoundFile;
    File usSoundFile;

    /*          单词为短语时,有无美音的特殊处理        */
    private void phraseNoUS(){
        Log.d(TAG, "phraseNoUS: detailWords.get(number).getWord()   " + detailWords.get(number).getWord());
        Log.d(TAG, "phraseNoUS: detailWords.get(number).getIsNewWord()   " + detailWords.get(number).getIsNewWord());
        if (detailWords.get(number).getIsNewWord() == 1){
            uWord = detailWords.get(number).getWord();
            ukSoundFile = new File(Config.rewordsPath + "uk_word_sound/" + uWord + ".mp3");
            usSoundFile = new File(Config.rewordsPath + "us_word_sound/" + uWord + ".mp3");

            Log.d(TAG, "phraseNoUS: ukSoundFile.exists   " + ukSoundFile.exists());
            //单词为短语时的文件名有些为look_up，有些为look up，此处为特殊处理
            dealSpecialWord();

            if (sharePreference.getBoolean("word_sound_is_en", true)) {
                word_pronunciation.setText(detailWords.get(number).getUk_bs());
                PlayWordSound.setMediaPlayer(ukSoundFile.toString());
                recoverWordSound = ukSoundFile.toString();
            } else
                //当短语美式读音为空，故判断当前读音是否是美式，美式的就拿英式去发音
                if (!usSoundFile.exists()) {
                    word_pronunciation.setText(detailWords.get(number).getUk_bs());
                    PlayWordSound.setMediaPlayer(ukSoundFile.toString());
                    recoverWordSound = ukSoundFile.toString();
                } else {
                    String text = detailWords.get(number).getUs_bs().equals("") ? detailWords.get(number).getUk_bs() : detailWords.get(number).getUs_bs();
                    word_pronunciation.setText(text);
                    PlayWordSound.setMediaPlayer(usSoundFile.toString());
                    recoverWordSound = usSoundFile.toString();
                }
        } else {
            //当单词为复习单词时的处理
            if (sharePreference.getBoolean("word_sound_is_en", true)) {
                word_pronunciation.setText(detailWords.get(number).getUk_bs());
            } else {
                String text = detailWords.get(number).getUs_bs().equals("") ? detailWords.get(number).getUk_bs() : detailWords.get(number).getUs_bs();
                word_pronunciation.setText(text);
            }
            PlayWordSound.setMediaPlayer(detailWords.get(number).getPathSound());
        }

    }

    //保存复习单词的音频位置
    private void saveRecoverWordSound(){
        if (recoverWordSound != null && !recoverWordSound.equals("")){
//            Log.d(TAG, "saveRecoverWordSound:recoverWordSound   " + recoverWordSound);
            File oldFile = new File(recoverWordSound);
            File file = new File(Config.wordSoundPath + detailWords.get(number).getWord() + ".mp3");
            if (!file.exists()){
                Config.copyFile(oldFile, file);
                Log.d(TAG, "saveRecoverWordSound: " +    Config.copyFile(oldFile, file));
            }
            if (detailWords.get(number).getIsNewWord() == 1)
                wordsDao.updateIsNewWord(file.toString(), detailWords.get(number).getWord());
            detailWords.get(number).setPathSound(file.toString());
//            detailWords.get(number).save();
        }
    }



    /**
     *  复习单词，数据库处理逻辑
     *  controlTime  掌握次数
     *  isControl    是否已掌握
     *
     *  learnTime = 7存在两种情况：
     *  1.正常流程到learnTime=7
     *  2.生词点击了掌握learnTime=7，当该单词再次学习时，点击未掌握则需判断是否生词学习时误点掌握
     *  若未误点则learn=1，appear=1，反之，learn--，appear根据learn值而定
     */
    int appear;
    int learn;
    private void controlDeal(Boolean isControl){
        if (detailWords.get(number).getLearnTime() == 0){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : 0;
            appear = Config.WORD_APPEAR_1;
        } else if (detailWords.get(number).getLearnTime() == 1){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
            appear = Config.WORD_APPEAR_1;
        } else if (detailWords.get(number).getLearnTime() == 2){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
            appear = isControl ? Config.WORD_APPEAR_4 : Config.WORD_APPEAR_1;
        } else if (detailWords.get(number).getLearnTime() == 3){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
            appear = isControl ? Config.WORD_APPEAR_7 : Config.WORD_APPEAR_2;
        }  else if (detailWords.get(number).getLearnTime() == 4){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
            appear = isControl ? Config.WORD_APPEAR_12 : Config.WORD_APPEAR_4;
        } else if (detailWords.get(number).getLearnTime() == 5){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
            appear = isControl ? Config.WORD_APPEAR_21 : Config.WORD_APPEAR_7;
        } else if (detailWords.get(number).getLearnTime() == 6){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
            appear = isControl ? Config.WORD_APPEAR_45 : Config.WORD_APPEAR_12;
        } else if (detailWords.get(number).getLearnTime() == 7){

            if(isControl){
                learn = detailWords.get(number).getLearnTime() + 1;
                appear = Config.WORD_APPEAR_50;
            } else {

                if (detailWords.get(number).getWrongClick() == 1)
                    wordsDao.updateWrongClick(detailWords.get(number).getWord());
                learn = detailWords.get(number).getWrongClick() == 1 ?  1 : detailWords.get(number).getLearnTime() - 1;
                appear = detailWords.get(number).getWrongClick() == 1 ? Config.WORD_APPEAR_1 : Config.WORD_APPEAR_21;
            }
        }

//        if (detailWords.get(number).getControlTime() == 0){
//            detailWords.get(number).setIsControl(2);
//            detailWords.get(number).setControlTime(1);
//        } else if (detailWords.get(number).getControlTime() == 1){
//            detailWords.get(number).setIsControl(3);
//            detailWords.get(number).setControlTime(2);
//        } else if (detailWords.get(number).getControlTime() == 2){
//            detailWords.get(number).setIsControl(4);
//            detailWords.get(number).setControlTime(3);
//        } else if (detailWords.get(number).getControlTime() == 3){
//            detailWords.get(number).setIsControl(5);
//            detailWords.get(number).setControlTime(4);
//        }  else if (detailWords.get(number).getControlTime() == 4){
//            detailWords.get(number).setIsControl(6);
//            detailWords.get(number).setControlTime(5);
//        }
    }

    /**
     * 当音频出现问题时，进行覆盖处理
     */
    private void coverReWord(){
        uWord = detailWords.get(number).getWord();
        ukSoundFile = new File(Config.rewordsPath + "uk_word_sound/" + uWord + ".mp3");
        usSoundFile = new File(Config.rewordsPath + "us_word_sound/" + uWord + ".mp3");

        //单词为短语时的文件名有些为look_up，有些为look up，此处为特殊处理
        Log.d(TAG, "phraseNoUS: ukSoundFile.exists   " + ukSoundFile.exists());
        if (ukSoundFile.exists()){
            dealSpecialWord();
            if (sharePreference.getBoolean("word_sound_is_en", true)) {
                word_pronunciation.setText(detailWords.get(number).getUk_bs());
                recoverWordSound = ukSoundFile.toString();
            } else
                //当短语美式读音为空，故判断当前读音是否是美式，美式的就拿英式去发音
                if (!usSoundFile.exists()) {
                    word_pronunciation.setText(detailWords.get(number).getUk_bs());
                    recoverWordSound = ukSoundFile.toString();
                } else {
                    String text = detailWords.get(number).getUs_bs().equals("") ? detailWords.get(number).getUk_bs() : detailWords.get(number).getUs_bs();
                    word_pronunciation.setText(text);
                    recoverWordSound = usSoundFile.toString();
                }

            Log.e(TAG, "clicks:recoverWordSound   " + recoverWordSound);
            if (recoverWordSound != null && !recoverWordSound.equals("")){
                File oldFile = new File(recoverWordSound);
                File file = new File(Config.wordSoundPath + detailWords.get(number).getWord() + ".mp3");
                Config.copyFile(oldFile, file);
                if (Config.copyFile(oldFile, file)){
                    ToastUtil.showToast(this, "覆盖成功");
                    clicks = 0;
                } else
                    ToastUtil.showToast(this, "覆盖失败");
            }
        } else
            ToastUtil.showToast(this, "该书本无该单词，请切换课本教材");
    }


    /**
     *      单词文件的特殊处理
     *
     */
    private void dealSpecialWord(){
        ArrayList<File> files = new ArrayList<>();
        String directoryName = Config.rewordsPath + "uk_word_sound/";
        File directory = new File(directoryName);
        File[] fList = directory.listFiles();

        if (!ukSoundFile.exists()){
            if (uWord.contains(" "))
                uWord = uWord.replaceAll(" ", "_");
            uWord = uWord.toLowerCase();
            Log.e(TAG, "dealSpecialWord: uWord  " + uWord + "    fList: " + fList);
            if (fList != null){
                for (File file : fList)
                    if (file.isFile() && file.getName().endsWith(".mp3"))
                        files.add(file);

                for (File s : files)
                    if (s.getName().contains(uWord)){
                        ukSoundFile = s;
                        break;
                    }
            } else {
                finish();
                ToastUtil.showToast(this, "课本资料发生错误，请重新选择课本");
            }
        }

    }



    private void saveWordData(){
        String fileString =  HttpDownloader.readFileData(Config.rewordsPath + "words.json");
        Gson gson = new Gson();
        words = gson.fromJson(fileString, new TypeToken<List<DetailWords>>() {}.getType());
        if (words != null && words.size() != 0) {
            for (String s : unitWords) {
                for (DetailWords newWord : words) {
                    if (newWord.getWord().equals(s) && newWordsDao.getIsExit(s) == null){
                        NewWords w = new NewWords();
                        w.setUid(uid);
//                        w.setSectionId(sectionId);
                        w.setIsNewWord(1);
//                        w.setIsControl(0);

                        w.setWord(newWord.getWord());
                        w.setExplain(newWord.getExplain());
                        w.setUk_bs(newWord.getUk_bs());
                        w.setUs_bs(newWord.getUs_bs());
                        w.setSentence(newWord.getSentence());
                        w.setSentence_explain(newWord.getSentence_explain());
                        if (newWord.getCommon_phrases() != null && newWord.getCommon_phrases().size() != 0){
                            if (newWord.getCommon_phrases().get(0).getContent().size() == 1) {
                                w.setWord_parse(newWord.getCommon_phrases().get(0).getContent().get(0).getText());
                                w.setWord_parse_explain(newWord.getCommon_phrases().get(0).getContent().get(0).getParaphrase());
                            } else {
                                w.setWord_parse(newWord.getCommon_phrases().get(0).getContent().get(0).getText());
                                w.setWord_parse_explain(newWord.getCommon_phrases().get(0).getContent().get(0).getParaphrase());
                                w.setWord_parse2(newWord.getCommon_phrases().get(0).getContent().get(1).getText());
                                w.setWord_parse_explain2(newWord.getCommon_phrases().get(0).getContent().get(1).getParaphrase());
                            }
                        }

                        if(wordsDao.getOne(newWord.getWord()) != null)
                            wordsDao.delect(newWord.getWord());
                        newWordsDao.insert(w);
                        break;
                    }

                }

            }
        }

    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BROADCAST_INK_PAD_PLUG.equals(action)) {

                Bundle bundle = intent.getExtras();
                String stateStr;
                if (bundle != null){
                    stateStr = bundle.getString("state", "");
                    if (isY38() && isSmallPhone()){
                        if (stateStr.equals("on")){//插上掌机
                            // 释放资源，关闭界面
                            releaseListen();
                            finish();
                        } else if (stateStr.equals("off")){//拔掉掌机
                            // 释放资源，关闭界面
                            releaseListen();
                            finish();
                        }
                    }
                }
            }
        }
    };

    public boolean isY38(){
        String str = SystemPropertiesInvoke.get("ro.readboy.internal.model","");
        return str.startsWith("Y38");
    }

    /** 1小机  0大机  */
    public boolean isSmallPhone(){
        return SystemPropertiesInvoke.getInt("persist.sys.is_readboy_y38_ink_pad", 0) == 1 ;
    }

    private void releaseListen(){
        PlayWordSound.finish();
    }

    @Override
    public void onBackPressed() {
        Log.w(TAG, "---------------onBackPressed: ----------------------");
        super.onBackPressed();
        if (number <= detailWords.size())
            Config.TEMPORARY_WORD = detailWords.subList(number, detailWords.size());
    }

    @Override
    protected void onDestroy() {
        Log.w(TAG, "---------------onDestroy: ----------------------");
        super.onDestroy();
        Fragment_Rewords.getInstance().setVisibility();
        releaseListen();
//        Config.setIsNeedToRefresh(true);

        // 取消插拔监听
        if (mReceiverTag){
            mReceiverTag = false;
            unregisterReceiver(mReceiver);
        }

    }

    ScrollView scrollView;
    @SuppressLint("SetTextI18n")
    private void initView() {
        
        hard_word = findViewById(R.id.hard_word);
        study_again_word = findViewById(R.id.study_again_word);
        recover_word = findViewById(R.id.recover_word);
        learned_word = findViewById(R.id.have_learn_word);
        total_word = findViewById(R.id.today_total_word);
        word = findViewById(R.id.word);
        img_word_play = findViewById(R.id.cl_sound);

        word_pronunciation = findViewById(R.id.word_pronunciation);
        word_explain = findViewById(R.id.word_explain);
        word_phrase = findViewById(R.id.word_phrase);
        word_phrase_explain = findViewById(R.id.word_phrase_explain);
        word_phrase2 = findViewById(R.id.word_phrase2);
        word_phrase_explain2 = findViewById(R.id.word_phrase_explain2);

        word_sentence = findViewById(R.id.word_sentence);
        word_sentence_explain = findViewById(R.id.word_sentence_explain);

        btn_control = findViewById(R.id.btn_control);
        btn_un_control = findViewById(R.id.btn_un_control);
        btn_next = findViewById(R.id.btn_next);
        btn_back = findViewById(R.id.back_text);
        btn_modify = findViewById(R.id.btn_modify);


        cl_hand = findViewById(R.id.cl_hand);
        rl_explain = findViewById(R.id.rl_explain);
        rl_phrase = findViewById(R.id.rl_phrase);
        cl_scroll_view = findViewById(R.id.scroll_view);
        sc_view = findViewById(R.id.sc_view);
        rl_word = findViewById(R.id.rl_word);

        hardWordCount = getIntent().getIntExtra("hardWordCount", 0);
//        studyAgainWordCount = getIntent().getIntExtra("studyAgainWordCount", 1);
//        recoverCount = getIntent().getIntExtra("recoverCount", 1);

        hard_word.setText("" + hardWordCount);

        totalWord = getIntent().getIntExtra("totalWordsCount", 1);

        btn_back.setOnClickListener(this);
        btn_control.setOnClickListener(this);
        btn_un_control.setOnClickListener(this);
        btn_next.setOnClickListener(this);
        btn_modify.setOnClickListener(this);

        cl_hand.setOnClickListener(this);
        rl_explain.setOnClickListener(this);
        cl_scroll_view.setOnClickListener(this);
        img_word_play.setOnClickListener(this);
        rl_word.setOnClickListener(this);

        uid = getIntent().getIntExtra("uid", 0);
        unitWords = getIntent().getStringArrayListExtra("unitWords");
        recoverWords = getIntent().getStringArrayListExtra("recoverWords");
        sectionId = getIntent().getIntExtra("sectionId", 0);
        sectionIds = getIntent().getIntegerArrayListExtra("ids");
        START_TYPE = getIntent().getIntExtra("type", 0);

        Logger.setIsEnableLog(true);
        e(TAG, "START_TYPE: " + START_TYPE );

        if (unitWords != null)
            Log.d(TAG, "goLearning: unitWords.size:   " + unitWords.size());

        if (START_TYPE == Config.BACK_SELECT_UNIT_START && unitWords != null)
            toFindWordIsExist(unitWords);

        if (unitWords != null)
            saveWordData();


        new wordAsyncTask().execute();
    }





}