package com.readboy.simpleLauncher.rewords.fragment;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.readboy.simpleLauncher.R;

/**
 * Created by jng wong
 * on 2022/9/23 19:31
 */
public class End_Img_Adapter extends RecyclerView.Adapter<End_Img_Adapter.MyHolder>{
    Context context;
    int round;
    public End_Img_Adapter(Context context, int round){
        this.context = context;
        this.round = round;
    }
    @NonNull
    @Override
    public End_Img_Adapter.MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View inflater = LayoutInflater.from(context).inflate(R.layout.item_end_img, viewGroup, false);
        return new End_Img_Adapter.MyHolder(inflater);

    }

    @Override
    public void onBindViewHolder(@NonNull End_Img_Adapter.MyHolder myHolder, int i) {
        Log.w("TAG", "getItemCount: " + i);

        if (i > 7){
            myHolder.flower_img.setImageResource(R.drawable.flower_no);
        } else
             myHolder.flower_img.setImageResource(R.drawable.flower_finsh);
    }

    @Override
    public int getItemCount() {
        return round;
    }

    public class MyHolder extends RecyclerView.ViewHolder{

        ImageView flower_img;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            flower_img = itemView.findViewById(R.id.flower_img);
        }
    }
}
