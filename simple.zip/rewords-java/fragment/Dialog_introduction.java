package com.readboy.simpleLauncher.rewords.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.readboy.simpleLauncher.R;

import java.util.Objects;

/**
 * Created by jng wong
 * on 2022/9/22 9:18
 */
public class Dialog_introduction extends DialogFragment {
    private AlertDialog dialog;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        final View view = LayoutInflater.from(requireActivity()).inflate(R.layout.dialog_introduction, null);
        TextView textView = view.findViewById(R.id.in_text);
        textView.setText("点击右上角可进行\n" + "修改计划、切换词书");
        builder.setView(view);
        dialog = builder.create();

        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.w("fffff", "onStart: ");
        Window window = Objects.requireNonNull(getDialog()).getWindow();
        WindowManager.LayoutParams params = window.getAttributes();
        /*      去除dialogfragment的边框     */
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setBackgroundDrawableResource(R.drawable.top_tip);
//        params.x = 50;
        params.y = 120;
        params.gravity = Gravity.CENTER;
        params.width = 580;
        params.height = 300;
        window.setAttributes(params);
        getDialog().show();
        window.setGravity(Gravity.TOP);
    }

}
