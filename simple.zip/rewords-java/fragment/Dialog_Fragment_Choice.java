package com.readboy.simpleLauncher.rewords.fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.selectBookAndUnit.SelectBookActivity;
import com.readboy.simpleLauncher.rewords.setting.SettingActivity;
import com.readboy.simpleLauncher.rewords.tool.Config;

import java.util.Objects;

/**
 * Created by jng wong
 * on 2022/8/31 11:34
 */
@SuppressLint("ValidFragment")
public class Dialog_Fragment_Choice extends DialogFragment implements View.OnClickListener{
    private AlertDialog dialog;

    Fragment_Select_Unit fragment_select_unit;
    Fragment_Learning_Word fragment;

    public static Dialog_Fragment_Choice instance;
    public static Dialog_Fragment_Choice getInstance(){
        return instance;
    }
    FragmentTransaction fragmentTransaction;

    public Dialog_Fragment_Choice(Fragment_Learning_Word fragment_learning_word) {
        fragment = fragment_learning_word;

    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Log.w("fffff", "onCreateDialog: ");
        instance = this;
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        final View view = LayoutInflater.from(requireActivity()).inflate(R.layout.dialog_choice, null);


        view.findViewById(R.id.cl_choice_plan).setOnClickListener(this);
        view.findViewById(R.id.choice_plan).setOnClickListener(this);
        view.findViewById(R.id.choice_plan_1).setOnClickListener(this);

        view.findViewById(R.id.cl_choice_book).setOnClickListener(this);
        view.findViewById(R.id.choice_book).setOnClickListener(this);
        view.findViewById(R.id.choice_plan_2).setOnClickListener(this);

        view.findViewById(R.id.cl_choice_setting).setOnClickListener(this);
        view.findViewById(R.id.choice_setting).setOnClickListener(this);
        view.findViewById(R.id.choice_plan_3).setOnClickListener(this);

//        view.findViewById(R.id.choice_plan).setOnClickListener(v -> {
////            Intent intent = new Intent();
////            intent.setClass(getContext(), SelectUnitActivity.class);
////            startActivity(intent);
//            if (fragment_select_unit == null)
//                fragment_select_unit = new Fragment_Select_Unit();
//            fragment.switchContent(fragment_select_unit);
//
//            dismiss();
//        });
//
//        view.findViewById(R.id.choice_book).setOnClickListener(v -> {
//            Intent intent = new Intent();
//            intent.setClass(getContext(), SelectBookActivity.class);
//            startActivity(intent);
//
//            if (fragment_select_unit == null)
//                fragment_select_unit = new Fragment_Select_Unit();
//            fragment.switchContent(fragment_select_unit);
//
//            dismiss();
//        });
//
//        view.findViewById(R.id.choice_setting).setOnClickListener(v -> {
//            Intent intent = new Intent();
//            intent.setClass(getContext(), SettingActivity.class);
//            startActivity(intent);
//            dismiss();
//        });

        builder.setView(view);
        dialog = builder.create();
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.w("fffff", "onStart: ");
        Window window = Objects.requireNonNull(getDialog()).getWindow();
        WindowManager.LayoutParams params = window.getAttributes();
        /*      去除dialogfragment的边框     */
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setBackgroundDrawableResource(R.drawable.more_show);
//        params.x = 50;
        params.y = 140;
        params.gravity = Gravity.CENTER;
        params.width = 660;
        params.height = 200;
        window.setAttributes(params);
        getDialog().show();
        window.setGravity(Gravity.TOP);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.cl_choice_plan:
            case R.id.choice_plan:
            case R.id.choice_plan_1:
                Log.w("TAG", "qqqq: 1111" );
                if (fragment_select_unit == null)
                    fragment_select_unit = new Fragment_Select_Unit();
                fragment.switchContent(fragment_select_unit);

                dismiss();
                break;

            case R.id.cl_choice_book:
            case R.id.choice_book:
            case R.id.choice_plan_2:
                Log.w("TAG", "qqqq: 2222" );
                Intent intent = new Intent();
                intent.setClass(Objects.requireNonNull(getContext()), SelectBookActivity.class);
                startActivity(intent);

                dismiss();
                break;

            case R.id.cl_choice_setting:
            case R.id.choice_setting:
            case R.id.choice_plan_3:
                Log.w("TAG", "qqqq: 33333" );
                Intent intent2 = new Intent();
                intent2.setClass(Objects.requireNonNull(getContext()), SettingActivity.class);
                startActivity(intent2);
                dismiss();
                break;
        }
    }

    public void isShowUnit(boolean isShow){
        if (isShow){
            Config.IsFromSelectBook = true;
            if (fragment_select_unit == null)
                fragment_select_unit = new Fragment_Select_Unit();
            fragment.switchContent(fragment_select_unit);
        }

    }

}
