package com.readboy.simpleLauncher.rewords.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.readboy.simpleLauncher.MainActivity;
import com.readboy.simpleLauncher.R;

public class Fragment_Tip extends Fragment {

    FragmentTransaction fragmentTransaction;
    public static Fragment_Tip newInstance() {
        return new Fragment_Tip();
    }


    @SuppressLint("CommitTransaction")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_learning_tip, container, false);
        Fragment_Learning_Word fragment_learning_word = new Fragment_Learning_Word();
        view.findViewById(R.id.tip_back).setOnClickListener(v -> {

            fragmentTransaction = fragmentManager.beginTransaction();
            Log.d("bbbbbb", "onCreateView:        " + fragment_learning_word.isAdded());
            if (!fragment_learning_word.isAdded()) {
                fragmentTransaction.hide(this).add(R.id.switch_fragment, fragment_learning_word).commitAllowingStateLoss();
            } else
            fragmentTransaction.hide(this).show(fragment_learning_word).commitAllowingStateLoss();


        });
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // TODO: Use the ViewModel
    }

    MainActivity mac ;
    FragmentManager fragmentManager;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        mac = (MainActivity) context;
        fragmentManager = mac.getSupportFragmentManager();

    }

}