package com.readboy.simpleLauncher.rewords.fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.readboy.loveread.fragment.base.LazyFragment;
import com.readboy.simpleLauncher.MainActivity;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.aiconversation.utils.InkPadPlugReceiver;
import com.readboy.simpleLauncher.aiconversation.utils.NetworkUtils;
import com.readboy.simpleLauncher.aiconversation.utils.SystemPropertiesInvoke;
import com.readboy.simpleLauncher.rewords.tool.GetUserInfo;
import com.readboy.simpleLauncher.rewords.tool.IsNetWorkConnected;
import com.readboy.simpleLauncher.rewords.tool.PlayWordSound;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;
import com.readboy.simpleLauncher.rewords.tool.WordContentProvider;

import java.util.Objects;

/**
 * Created by jng wong
 * on 2022/9/9 15:25    Fragment_control
 */
public class Fragment_Control extends LazyFragment {
    String TAG = "bbbbbb";
    @Override
    protected int getLayoutRes() {
        return R.layout.fragment_control;
    }
    Bundle savedInstanceState;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.v("bbbbbb", " onCreate:  " + getContext() + "   " + savedInstanceState);
        this.savedInstanceState = savedInstanceState;
//        if (savedInstanceState == null){
//            if (fragmentManager != null)
//                fragmentTransaction = fragmentManager.beginTransaction();
//
//            if (fragment_learning_word == null ){
//                fragment_learning_word = Fragment_Learning_Word.newInstance(isSmallPhone());
//                isIniView = true;
//            }
//
//            switchContent(fragment_learning_word);
//        }
//        //        /*       插拔监听       */
//        IntentFilter filter = new IntentFilter();
//        filter.addAction(BROADCAST_INK_PAD_PLUG);
//        mReceiverTag = true;
//        Log.i("TAG", "bbbbbb   onCreate: " +  getContext().registerReceiver(mReceiver, filter));

    }

    boolean isIniView = false;

    FrameLayout container_fragment;
    Context mContext;
    @SuppressLint("Recycle")
    @Override
    protected void initView(View rootView) {
        mContext = getContext();
        container_fragment = rootView.findViewById(R.id.switch_fragment);

        Log.v("bbbbbb", " initView:isSmallPhoneisSmallPhone    " + isSmallPhone());

//        ContentResolver contentResolver;
//        contentResolver = Objects.requireNonNull(getContext()).getContentResolver();
//
//        Cursor cursor = contentResolver.query(WordContentProvider.NOTIFY_URI, null, null,null,null);
//
//        if (cursor.moveToNext()){
//            String word = cursor.getString(cursor.getColumnIndex("word"));
//            String explain = cursor.getString(cursor.getColumnIndex("explain"));
//            Log.w("cursorcursorcursorcursor", "initView: " + word + "         " + explain );
//        }
//        Log.v("cursorcursorcursorcursor", "initView: " + cursor.getCount());
    }

    public static Fragment_Control instance;

    public static Fragment_Control getInstance(){
        return instance;
    }


    MainActivity mAc;

    @Override
    public void onAttach(@NonNull Context context) {
        Log.v("bbbbbb", " onAttach:  " );
        super.onAttach(context);
        mAc = (MainActivity) context;
        fragmentManager = mAc.getSupportFragmentManager();
        instance = this;

    }

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    Fragment_Learning_Word fragment_learning_word;

    @Override
    protected void loadData() {
        Log.v("bbbbbb", " loadData:  " );
    }

    @Override
    protected void onFragmentResume() {
        Log.v("bbbbbb", "Fragment_Control onFragmentResume:  " + isSmallPhone());

        if (!isSmallPhone()){
            Log.e("bbbbbb", "Fragment_Control releaseListen:  " + isSmallPhone());
            releaseListen();
        }

    }

    @Override
    protected void onFragmentPause() {
        Log.v("bbbbbb", " onFragmentPause:  " );
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        Log.v("bbbbbb", "Fragment_Control isVisibleToUser:  " + isVisibleToUser + "   " + isIniView);

        if (isVisibleToUser && isSmallPhone()){
            if (savedInstanceState == null){
                if (fragmentManager != null)
                    fragmentTransaction = fragmentManager.beginTransaction();

                if (fragment_learning_word == null ){
                    fragment_learning_word = Fragment_Learning_Word.newInstance(isSmallPhone());
                    isIniView = true;
                }

                switchContent(fragment_learning_word);
            }

            showUpdateDialog();
        }

//        if (isSmallPhone){
//            if (fragmentManager != null)
//                fragmentTransaction = fragmentManager.beginTransaction();
//            if (isVisibleToUser){
//                if (fragment_learning_word == null)
//                    fragment_learning_word = Fragment_Learning_Word.newInstance();
//
//                switchContent(fragment_learning_word);
//            }

//                if (fragmentTransaction != null ){
//                    if (!fragment_learning_word.isAdded()) {
//                        Log.w("bbbbbb", "switchContent:    1111  " );
//                        fragmentTransaction.add(R.id.switch_fragment, fragment_learning_word).commitAllowingStateLoss();
//                    } else {
//                        Log.w("bbbbbb", "Fragment_Control   switchContent:2222  " + fragment_learning_word.getUserVisibleHint());
//                    }
//                }
//        } else{
//
//        }

    }



    private Fragment mCurrent;
    private void switchContent(Fragment to) {
        fragmentTransaction = fragmentManager.beginTransaction();
        if (mCurrent != null && mCurrent != to) {
            Log.e(TAG, "setFragment: 4");
            if (!to.isAdded()) { // 判断是否被add过
                // 隐藏当前的fragment，将 下一个fragment 添加进去
                fragmentTransaction.hide(mCurrent).add(R.id.switch_fragment, to).commitAllowingStateLoss();
                Log.e(TAG, "setFragment: 5");
            } else {
                // 隐藏当前的fragment，显示下一个fragment
                fragmentTransaction.hide(mCurrent).show(to).commitAllowingStateLoss();
                Log.e(TAG, "setFragment: 6");
            }
            mCurrent = to;
        } else if (mCurrent == null && to != null) {
            mCurrent = to;
            if (!to.isAdded()) {
                Log.e(TAG, "setFragment: 8");
                fragmentTransaction.add(R.id.switch_fragment, to).commitAllowingStateLoss();
            } else {
                Log.e(TAG, "setFragment: 9");
                fragmentTransaction.show(to).commitAllowingStateLoss();
            }
        }
    }

    // 插拔是否注册
    private boolean mReceiverTag = false;
    private static final String BROADCAST_INK_PAD_PLUG = "com.readboy.intent.action.InkPadPlug";

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.i("bbbbbb", "onReceive: context  " + context + "    " + intent.getExtras() + "   " + intent.getExtras().getString("state", ""));
            String action = intent.getAction();
            if (BROADCAST_INK_PAD_PLUG.equals(action)) {
                Bundle bundle = intent.getExtras();
                String stateStr;
                if (bundle != null){
                    stateStr = bundle.getString("state", "");
                    if (isY38()){
                        if (stateStr.equals("on")){             //插上掌机
                            // 释放资源，关闭界面
                            Log.i("bbbbbb", "onReceive: on  ");
                            releaseListen();
                        } else if (stateStr.equals("off")){     //拔掉掌机
                            // 释放资源，关闭界面
                            releaseListen();
                        }
                    }
                }
            }
        }
    };

    public boolean isY38(){
        String str = SystemPropertiesInvoke.get("ro.readboy.internal.model","");
        return str.startsWith("Y38");
    }

    /** 1小机  0大机  */
    public boolean isSmallPhone(){
        return SystemPropertiesInvoke.getInt("persist.sys.is_readboy_y38_ink_pad", 0) == 1 ;
    }

    private void releaseListen(){
        PlayWordSound.finish();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.w("bbbbbb", "---------------onDestroy: ----------------------" + mReceiverTag);
        Log.e("bbbbbb", "Fragment_Control  switchContent:3333  " + fragmentManager + "    " + fragmentTransaction + "    " + fragment_learning_word);
        container_fragment.setVisibility(View.GONE);
        // 取消插拔监听
//        if (mReceiverTag){
//            mReceiverTag = false;
//            getContext().unregisterReceiver(mReceiver);
//        }
    }

    private void showUpdateDialog(){
        /*          同步数据对话框           */
        SettingSharePreference sharePreference = new SettingSharePreference(mContext);
        long uid = sharePreference.getLong("uid", 111111);
        if (IsNetWorkConnected.isNetworkConnected(mContext) && GetUserInfo.getUserBaseInfo(mContext) != null){
            Log.i("TAG", "showUpdateDialog: " + uid);
            int personUid = Objects.requireNonNull(GetUserInfo.getUserBaseInfo(mContext)).uid;
            if (uid != personUid){
                if (fragment_learning_word != null){
                    fragment_learning_word.requestBookRecords(personUid, mContext);
                }
                sharePreference.putInt("uid", personUid);
                sharePreference.commit();
            }

        }

    }
}
