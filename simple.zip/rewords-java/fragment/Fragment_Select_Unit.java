package com.readboy.simpleLauncher.rewords.fragment;

import android.annotation.SuppressLint;
import android.arch.persistence.room.Room;
import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.readboy.loveread.fragment.base.LazyFragment;
import com.readboy.simpleLauncher.MainActivity;
import com.readboy.simpleLauncher.Main_UI.Fragment.Tool.ToastUtil;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.data.ObjectChangeString;
import com.readboy.simpleLauncher.rewords.data.book.UnitData;
import com.readboy.simpleLauncher.rewords.data.detail_word.DBInstance;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AppDatabase;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWordsDao;
import com.readboy.simpleLauncher.rewords.download.HttpDownloader;
import com.readboy.simpleLauncher.rewords.selectBookAndUnit.SelectUnitAdapter;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.GetUserInfo;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;

import org.litepal.LitePal;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jng wong
 * on 2022/9/9 15:50
 */
public class Fragment_Select_Unit extends LazyFragment {
    TextView btn_select_unit_back, learning_progress;
    TextView unit_book_name;
    RelativeLayout rv_select_book;
    RecyclerView select_unit_recyclerview;
    SeekBar learn_seekbar;

    int bookId, uid;
    String bookName;
    SettingSharePreference sharePreference;

    Fragment_Learning_Word fragment;


    @Override
    protected int getLayoutRes() {
        return R.layout.activity_select_unit;
    }

    @SuppressLint({"ClickableViewAccessibility", "SetTextI18n"})
    @Override
    protected void initView(View rootView) {

        DetailWordsDao wordsDao = DBInstance.initDb(getActivity()).detailWordsDao();

        rv_select_book = rootView.findViewById(R.id.rv_select_book);
        btn_select_unit_back = rootView.findViewById(R.id.select_unit_back_btn);
        select_unit_recyclerview = rootView.findViewById(R.id.select_unit_recyclerview);

        sharePreference = new SettingSharePreference(getContext());
        bookName = sharePreference.getString("bookName", "");
//        unit_book_name.setText(bookName);
        Log.d("bookName", "initView: " + bookName);

        if (GetUserInfo.getUserBaseInfo(getContext()) != null) {
            uid = GetUserInfo.getUserBaseInfo(getContext()).uid;
        }else
            uid = 111111;
        bookId =  sharePreference.getInt("bookId", 142167);
        Log.d("bookName", "initView: " + bookId);

        String unitDataString =  sharePreference.getString("unitDataString", null);
//        String unitDataString = getIntent().getStringExtra("unitDataString");
        unit = ObjectChangeString.stringToUnitData(unitDataString);
        Log.d("bookName", "unit: " + unit);
        new unitAsyncTask().execute(bookId);

        btn_select_unit_back.setOnClickListener(v -> {
            if (fragment == null)
                fragment = new Fragment_Learning_Word();

            fragmentTransaction = fragmentManager.beginTransaction();
            if (!fragment.isAdded()) {
                fragmentTransaction.hide(this).add(R.id.switch_fragment, fragment).commitAllowingStateLoss();
            } else
                fragmentTransaction.hide(this).show(fragment).commitAllowingStateLoss();

        });

        rootView.findViewById(R.id.generate_plan).setOnClickListener(v -> {
            if (fragment == null)
                fragment = new Fragment_Learning_Word();

            fragmentTransaction = fragmentManager.beginTransaction();
            if (!fragment.isAdded()) {
                fragmentTransaction.hide(this).add(R.id.switch_fragment, fragment).commitAllowingStateLoss();
            } else
                fragmentTransaction.hide(this).show(fragment).commitAllowingStateLoss();

            ToastUtil.showToast(getContext(), "已为您制定新的学习计划");
        });

        /*          学习统计            */
        learning_progress = rootView.findViewById(R.id.learning_progress);
        int haveLearn = wordsDao.getHaveLearnWord(uid, bookId).size();
        if (Config.words == null)
            Config.words = new ArrayList<>();
        if (Config.words.size() == 0){
            String fileString =  HttpDownloader.readFileData(Config.rewordsPath + uid + "/" + bookId +"/" + "words.json");
            Log.w("bbbbbbb", "saveWordData: bookId: " + bookId );
            Gson gson = new Gson();
            Config.words = gson.fromJson(fileString, new TypeToken<List<DetailWords>>() {}.getType());
        }
        int wordCount = Config.words.size();
        learning_progress.setText(haveLearn + " / " + wordCount);


        /*      学习进度条       */
        learn_seekbar = rootView.findViewById(R.id.learn_seekbar);
        learn_seekbar.setOnTouchListener((v, event) -> true);
        double progress = ((double)haveLearn / wordCount) * 100;
        Log.w("TAG", "Fragment_Select_Unit: " + haveLearn + "   / " + wordCount + "    " + new DecimalFormat("0").format(progress));
        Log.e("TAG", "Fragment_Select_Unit: " + new DecimalFormat("0").format(progress));
        learn_seekbar.setProgress(Integer.parseInt(new DecimalFormat("0").format(progress)));



    }

    @Override
    protected void loadData() {

    }

    @Override
    protected void onFragmentResume() {
    }

    @Override
    protected void onFragmentPause() {

    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        Log.i("bbbbbb", "onHiddenChanged: " + hidden);

        if (hidden){
            if (sharePreference.getBoolean("isSelectBook", false)) {
                sharePreference.putBoolean("isSelectBook", false);
                Log.d("TAG", "init: " +
                        "   getUnitIdList  " + Config.getUnitIdList() +
                        "  getUnitNameList  " + Config.getUnitNameList());

//            sharePreference.putInt("unitId", Collections.min(Config.getGetMinId()));
                Log.w("qwe", "33333: " );
                sharePreference.putString("bookName", bookName);
                sharePreference.putIntList("unitIdList", Config.getUnitIdList());
                sharePreference.putStringList("unitNameList", Config.getUnitNameList());
                sharePreference.commit();
            }

            Config.IsFromSelectBook = false;
            Config.getUnitNameList().clear();
            Config.getUnitIdList().clear();
        }
    }

    UnitData unit;
    List<UnitData> unitData = new ArrayList<>();
    private class unitAsyncTask extends AsyncTask<Integer, Void, Void> {
        @Override
        protected Void doInBackground(Integer... integers) {
            unitData.clear();
            unitData.addAll(LitePal.where("bid = ?", String.valueOf(integers[0])).find(UnitData.class));
            if (unitData.size() == 0){
                if (unit != null){
                    String c =  ObjectChangeString.listObjectToString(unit.getChildren());
                    UnitData data = new UnitData();
                    data.setBid(unit.getBid());
                    data.setData(c);
                    data.setName(unit.getEdition().getName() + bookName);
                    data.save();
                    Log.d("TAG", "bookName:  isSave: " + data.isSaved());
                    unitData.add(data);
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            if (unitData.size() != 0){
                SelectUnitAdapter unitAdapter = new SelectUnitAdapter(ObjectChangeString.stringToObject(unitData.get(0).getData()),
                        getContext(), bookId, bookName);

                LinearLayoutManager manager = new LinearLayoutManager( getContext());
                select_unit_recyclerview.setLayoutManager(manager);
                select_unit_recyclerview.setAdapter(unitAdapter);
            } else
                ToastUtil.showToast( getContext(), R.string.get_data_fail);


//            if (bookPage != null && catalogueData != null &&catalogueData.getData() != null & bookPage.getData() != null){
//                SelectUnitAdapter unitAdapter = new SelectUnitAdapter(catalogueData.getData().getBooks().getChildren(),
//                        bookPage.getData().getBook().getPage().getData(), SelectUnitActivity.this, bookId, bookName);
//
//                LinearLayoutManager manager = new LinearLayoutManager(SelectUnitActivity.this);
//                select_unit_recyclerview.setLayoutManager(manager);
//                select_unit_recyclerview.setAdapter(unitAdapter);
//            } else
//                ToastUtil.showToast(SelectUnitActivity.this, R.string.get_data_fail);

        }

    }

    MainActivity mac ;
    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        mac = (MainActivity) context;
        fragmentManager = mac.getSupportFragmentManager();

    }




}
