package com.readboy.simpleLauncher.rewords.fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.constraint.ConstraintLayout;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.readboy.loveread.fragment.base.LazyFragment;
import com.readboy.practiselistening.view.LoadStatusView;
import com.readboy.provider.UserDbSearch;
import com.readboy.simpleLauncher.Main_UI.Fragment.Tool.ToastUtil;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.AuthHelper;
import com.readboy.simpleLauncher.rewords.RewordsActivity;
import com.readboy.simpleLauncher.rewords.data.ObjectChangeString;
import com.readboy.simpleLauncher.rewords.data.book.BookData;
import com.readboy.simpleLauncher.rewords.data.book.BookDetails;
import com.readboy.simpleLauncher.rewords.data.book.Children;
import com.readboy.simpleLauncher.rewords.data.book.Children2;
import com.readboy.simpleLauncher.rewords.data.book.UnitData;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;
import com.readboy.simpleLauncher.rewords.download.HttpDownloader;
import com.readboy.simpleLauncher.rewords.selectBookAndUnit.SelectBookActivity;
import com.readboy.simpleLauncher.rewords.selectBookAndUnit.SelectUnitActivity;
import com.readboy.simpleLauncher.rewords.setting.SettingActivity;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.GetUserInfo;
import com.readboy.simpleLauncher.rewords.tool.HttpUtil;
import com.readboy.simpleLauncher.rewords.tool.IsNetWorkConnected;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;
import com.readboy.simpleLauncher.rewords.tool.TimeProcess;

import org.litepal.LitePal;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by hjy on 2022/3/29 8:58
 */
public class Fragment_Rewords extends LazyFragment implements View.OnClickListener{
    int bid = 9803167;
    int uid, grade;
//    LinearLayout fragment_book_downloading;
    LinearLayout no_login_view;
    ConstraintLayout rl_select_book;
    ConstraintLayout cl_fragment;
    TextView book, book_unit, btn_no_login;
    TextView new_word, recover_word, learn_complete_text, estimated_time_text;
    ImageView  btn_setting, img_com_time;
    Button btn_start_learn, btn_continue_study, btn_switch_book;
    Button btn_study;
    private LoadStatusView loadStatusView;

    private int recoverCount;
    private String TAG = "Fragment_Rewords";

    private ArrayList<String> unitWords = new ArrayList<>();
    private ArrayList<String> recoverWords = new ArrayList<>();

    private Intent intent;
    private int sectionId, bookId;
    private int b = -1;
    SettingSharePreference sharePreference;
    static Fragment_Rewords instance;

    public static Fragment_Rewords getInstance() {
        return instance;
    }
    ArrayList<Integer> ids = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        sharePreference = new SettingSharePreference(getContext());
        sharePreference.putBoolean("isNeedToGet", true);
        sharePreference.commit();
        ids.add(9804167);
        ids.add(9805167);
        ids.add(9806167);

//        NetworkUtils.registerNetworkStatusChangedListener(new NetworkUtils.OnNetworkStatusChangedListener() {
//            @Override
//            public void onDisconnected() {
//                disConnect=true;
//            }
//
//            @Override
//            public void onConnected(NetworkUtils.NetworkType networkType) {
//                if (!disConnect)
//                    onFragmentResume();
//            }
//        });

    }

    @Override
    protected int getLayoutRes() {
        return R.layout.fragment_rewords;
    }


    @SuppressLint("NonConstantResourceId")
    @Override   
    public void onClick(View v) {
        if (Config.isFastDoubleClick()) return;//防止快速点击
        switch (v.getId()){
            case R.id.btn_setting:
                intent = new Intent();
                intent.setClass(getContext(), SettingActivity.class);
                intent.putExtra("uid", uid);
                intent.putExtra("bookId", bookId);
                startActivity(intent);
                break;
            case R.id.rl_book:
                Config.setStudyAll(false);
                Config.setIsNeedToRefresh(true);
                Config.isGoSelectUnit = true;
                ids.remove(0);
                ids.add(9807167);
                toSelectBook();
                break;
            case R.id.btn_switch_book:
                if (!IsNetWorkConnected.isNetworkConnected(getContext())){
                    ToastUtil.showToast(getContext(), R.string.btn_no_net_text);
                    return;
                }
                Intent intent = new Intent();
                intent.setClass(getContext(), SelectBookActivity.class);
                startActivity(intent);
                break;
            case R.id.btn_start_learn:
                Log.w(TAG, "recoverWords.size: " +  Config.isIsNeedToRefresh());
                if (Config.isGoSelectUnit) {
                    goLearning(Config.BACK_SELECT_UNIT_START);
                    Config.setIsNeedToRefresh(false);
                } else
                    goLearning(Config.SELECT_UNIT_START);

                break;
            case R.id.btn_study:
                goLearning(Config.BACK_CONTINUE_START);
                break;
            case R.id.btn_continue_study:
                Config.setStudyAll(false);
                continueStudy();
                break;
            case  R.id.no_login_btn:
                UserDbSearch.getInstance(getContext()).startPersonalsetting(getContext());
                break;
        }
    }


//    private class dataAsyncTask extends AsyncTask<Integer, Void, Void>{
//
//        @Override
//        protected Void doInBackground(Integer... integers) {
//            AuthHelper.newAuth(getContext());
//            HttpUtil.setAuth(getContext());
//            return null;
//        }
//
//        @SuppressLint("SetTextI18n")
//        @Override
//        protected void onPostExecute(Void unused) {
//            if (unitWordsData != null &&  unitWordsData.getData() != null ){
//                studyAgainWordCount = unitWordsData.getData().getStudyAgainWordCount();
//                //生词总数
//                int newWordsCount = unitWordsData.getData().getNewWordCount();
//                new_word.setText(String.valueOf(newWordsCount));
//                //单元生词总数
//                int totalUnitWord = unitWordsData.getData().getTotal();
//
//
//                for (int i = 0; i < newWordsCount; i++)
//                    if (unitWordsData.getData().getWords().get(i).getIsNewWord() == 1)
//                        unitWords.add(unitWordsData.getData().getWords().get(i).getWords());
//
//
//                //待复习单词
//                if (dataUserWords != null && dataUserWords.getData() != null){
//                    //待复习单词
//                    recoverCount = dataUserWords.getData().getDailyWords().getWords().size();
//                    if (recoverCount > 20)
//                        recoverCount = 20;
//                    recover_word.setText("" + recoverCount);
//
//                    if (recoverCount != 0)
//                        for (int i = 0; i < recoverCount; i++)
//                            recoverWords.add(dataUserWords.getData().getDailyWords().getWords().get(i).getWords());
//
//                    studyAgainWordCount += dataUserWords.getData().getDailyWords().getStudyAgainWordCount();
//                    hardWordCount = dataUserWords.getData().getDailyWords().getHardWordCount();
//                }
//                //总共需学习单词数
//                totalWordsCount = newWordsCount + recoverCount;
//                //预计单词学习时间
//                int totalTime = totalWordsCount / 3;
//                if (totalWordsCount < 3)
//                    estimated_time_text.setText("预计用时1分钟");
//                estimated_time_text.setText("预计用时" + totalTime + "分钟");
//
//
//                //中间文本及提示对话框显示
//                if (newWordsCount == 0 && recoverCount ==0){
//                    if (b + 1 < unitIdList.size()){
//                        estimated_time_text.setVisibility(View.GONE);
//                        learn_complete_text.setVisibility(View.VISIBLE);
//
//                        btn_start_learn.setVisibility(View.INVISIBLE);
//                        btn_continue_study.setVisibility(View.VISIBLE);
//
//                        continueStudy = false;
//
//                        //对话框显示
//                        if (!Config.isConfirmKnow()){
//                            if (tipDialog == null)
//                                tipDialog =new TipDialog(getContext(), true, null, "该单元已学习完！");
//                            tipDialog.show();
//                            Config.setConfirmKnow(true);
//                        }
//
//
//                        cl_fragment.setVisibility(View.VISIBLE);
//                    } else
//                        lastUnitView();
//
//                } else {
//                    estimated_time_text.setVisibility(View.VISIBLE);
//                    learn_complete_text.setVisibility(View.GONE);
//                }
//
//            } else{
//                UserDbSearch mUserDbSearch = UserDbSearch.getInstance(getContext());
//                UserBaseInfo mUserInfo = mUserDbSearch.getUserInfo();
//                if (mUserInfo != null && mUserInfo.uid > 0)
//                    ToastUtil.showToast(getContext(), "数据获取出错或者网络连接出错");
//            }
//
//            if (continueStudy){
//                goLearning();
//                continueStudy = false;
//                btn_start_learn.setVisibility(View.VISIBLE);
//                btn_continue_study.setVisibility(View.INVISIBLE);
//            }
//
//        }
//    }


    private void goLearning(int type){
        Log.d(TAG, "goLearning: " + unitWords.size() + "  recoverWords.size" + recoverWords.size() + "   type: " + type);
        intent = new Intent();
        intent.setClass(Objects.requireNonNull(getContext()), RewordsActivity.class);

        if ((unitWords.size() != 0 || recoverWords.size() != 0) && type == 0){
            intent.putExtra("type", 0);
            intent.putStringArrayListExtra("unitWords", unitWords);
            intent.putStringArrayListExtra("recoverWords", recoverWords);
            intent.putExtra("sectionId", sectionId);
            intent.putExtra("uid", uid);
            sharePreference.putBoolean("isNeedToGet", true);
            sharePreference.commit();
            btn_start_learn.setVisibility(View.VISIBLE);
            btn_switch_book.setVisibility(View.INVISIBLE);
            btn_continue_study.setVisibility(View.INVISIBLE);
        } else if (type == 1){
            intent.putStringArrayListExtra("unitWords", unitWords);
            intent.putExtra("uid", uid);
            intent.putExtra("type", 1);
        } else if (type == 2)
            intent.putExtra("type", 2);

        startActivity(intent);


    }



    public void continueStudy(){
        if (b != -1){
            Log.w(TAG, "continueStudy: " + b + "   " + unitIdList.size() );
            if (b + 1 < unitIdList.size()){
                cl_fragment.setVisibility(View.INVISIBLE);

                b++;
                book_unit.setText(unitNameList.get(b));
                sectionId = unitIdList.get(b);
                sharePreference.putInt("unitId", sectionId);
                Log.w("qwe", "11111: ");
                sharePreference.putBoolean("sectionIdHaveChange", true);
                sharePreference.commit();
                onFragmentResume();
                goLearning(3);
            } else
               lastUnitView();

        }

    }


    private void toSelectBook(){
        Intent intent = new Intent();
        intent.setClass(getContext(), SelectUnitActivity.class);
        intent.putExtra("bookId", bookId);
        intent.putExtra("unitDataString", unitInfo2);
        intent.putExtra("bookName", sharePreference.getString("bookName", "人教PEP三年级上册"));
        startActivity(intent);
    }

    @Override
    protected void loadData() {

    }

    List<Integer> unitIdList = new ArrayList<>();
    List<String> unitNameList = new ArrayList<>();
    UnitData unitData;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onFragmentResume() {
        uid = GetUserInfo.getUid(getContext());
        Log.d(TAG, "onFragmentResume: ");
        unitInfo2 = null;
        unitInfo2 = sharePreference.getString("unitDataString", "");
        loadStatusView.setHide();
//        no_login_view.setVisibility(View.INVISIBLE);
//        cl_fragment.setVisibility(View.VISIBLE);
//        if (!unitInfo2.equals("")) {
//            unitData = ObjectChangeString.stringToUnitData(unitInfo2);
//            initData(unitData, 2);
//        } else{
//            loadStatusView.setLoading();
////            fragment_book_downloading.setVisibility(View.VISIBLE);
//            new unitAsyncTask().execute();
//        }

        if (GetUserInfo.getUserBaseInfo(getContext()) != null){
//            Log.d(TAG, "onFragmentResume: " + GetUserInfo.getUserBaseInfo(getContext()));
            grade = sharePreference.getInt("grade", 0);
            if (grade == 0)
                grade = 3;
//                grade = GetUserInfo.getUserBaseInfo(getContext()).gradeInt + 1;

            uid = GetUserInfo.getUserBaseInfo(getContext()).uid;
            Log.d(TAG, "onFragmentResume: uid  " + uid + "  grade: " + grade );
            no_login_view.setVisibility(View.INVISIBLE);
            cl_fragment.setVisibility(View.VISIBLE);
            if (!unitInfo2.equals("")) {
                unitData = ObjectChangeString.stringToUnitData(unitInfo2);
                initData(unitData, 2);
            } else{
                loadStatusView.setLoading();
//            fragment_book_downloading.setVisibility(View.VISIBLE);
                new unitAsyncTask().execute();
            }
        } else {
            no_login_view.setVisibility(View.VISIBLE);
            cl_fragment.setVisibility(View.INVISIBLE);
        }


    }

    @Override
    protected void onFragmentPause() {
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        sharePreference.putBoolean("first_click", false);
        sharePreference.commit();
    }

    private void lastUnitView(){
        Log.d(TAG, "lastUnitView: ");
        ToastUtil.showToast(getContext(),R.string.last_unit);
        btn_switch_book.setVisibility(View.VISIBLE);

        btn_continue_study.setVisibility(View.INVISIBLE);
        btn_start_learn.setVisibility(View.INVISIBLE);

        learn_complete_text.setVisibility(View.VISIBLE);
        estimated_time_text.setVisibility(View.INVISIBLE);
        img_com_time.setVisibility(View.INVISIBLE);
        learn_complete_text.setText("恭喜你！本书学习已完成");

    }

    public void setVisibility(){
        cl_fragment.setVisibility(View.VISIBLE);
    }


    @SuppressLint("SetTextI18n")
    private void initData(UnitData data, int i){
        if (data.getChildren() != null && data.getChildren().size() != 0){
            //课本名称
            String bName = data.getName();
            if (bName.length() > 2)
                bName = bName.substring(2);
            bookId = sharePreference.getInt("bookId", bid);
            sharePreference.putString("bookName", data.getEdition().getName() + bName);
            sharePreference.putInt("grade", grade);
            sharePreference.putInt("bookId", bookId);
            sharePreference.commit();
            sectionId = sharePreference.getInt("unitId", 9804167);
            Log.w(TAG, "ffffff: " + sectionId);
            String idList = sharePreference.getString("unitIdList", "");
            String nameList = sharePreference.getString("unitNameList", "");
            Log.d(TAG, "initData: idList" + idList);
            if (!idList.equals("")){
                Gson gson = new Gson();
                //将json数据转成List集合
                unitIdList = gson.fromJson(idList, new TypeToken<List<Integer>>(){}.getType());
                if (unitIdList.size() != 0){
                    Gson gson2 = new Gson();
                    unitNameList = gson2.fromJson(nameList, new TypeToken<List<String>>(){}.getType());

                    for (int j = 0;j < unitIdList.size(); j++)
                        if (unitIdList.get(j) == sectionId){
                            b = j;
                            break;
                        }

                    Log.d(TAG, "initData: sectionId" + sectionId + "  b " + b);
                    if (b != -1){
                        sectionId = unitIdList.get(b);
                        //单元名称
                        book_unit.setText(unitNameList.get(b));
                        book.setText(data.getEdition().getName() + bName);
                        setLearnNumberTime(data);
                    } else
                        Toast.makeText(getContext(), "数据有误，请尝试重新选择教材", Toast.LENGTH_SHORT).show();
                }
            }
        }

    }

    //设置预计学习用时
    @SuppressLint("SetTextI18n")
    private void setLearnNumberTime(UnitData data){
        int wordCount = 0;

        words.clear();
        unitWords.clear();
        recoverWords.clear();
        toGetData(data);

        wordCount = unitWords.size();
        recoverCount = recoverWords.size();
        Log.d(TAG, "initData: wordCount" + wordCount + "  recoverCount " + recoverCount);
        //总共需学习单词数
        new_word.setText("" + wordCount);
        recover_word.setText("" + recoverCount);
        //预计单词学习时间
        int totalTime = (wordCount + recoverCount) / 3;
        if ((wordCount + recoverCount) < 3){
            estimated_time_text.setText("预计用时1分钟");
        } else
            estimated_time_text.setText("预计用时" + totalTime + "分钟");

        //中间文本及提示对话框显示
        if (wordCount == 0 && recoverCount ==0){
            if (b + 1 < unitIdList.size()){
                img_com_time.setVisibility(View.GONE);
                estimated_time_text.setVisibility(View.GONE);
                learn_complete_text.setText("恭喜你！今日学习已完成");
                learn_complete_text.setVisibility(View.VISIBLE);
                btn_start_learn.setVisibility(View.INVISIBLE);
                btn_continue_study.setVisibility(View.VISIBLE);
                btn_switch_book.setVisibility(View.INVISIBLE);

                //对话框显示
                if (!Config.isStudyAll()){
                    AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
                    dialog.setTitle("提示");
                    dialog.setMessage("该单元已学习完!");
                    dialog.setCancelable(true);
                    dialog.setPositiveButton("我知道了", null);
                    dialog.show();
//                    if (tipDialog == null)
//                        tipDialog =new TipDialog(getContext(), true, null, "该单元已学习完！");
//                    tipDialog.show();
                    Config.setStudyAll(true);
                }

                cl_fragment.setVisibility(View.VISIBLE);
            } else
                lastUnitView();

        } else {
            img_com_time.setVisibility(View.VISIBLE);
            estimated_time_text.setVisibility(View.VISIBLE);
            learn_complete_text.setVisibility(View.GONE);
            btn_start_learn.setVisibility(View.VISIBLE);
            btn_switch_book.setVisibility(View.INVISIBLE);
            btn_continue_study.setVisibility(View.INVISIBLE);
        }

    }

    List<DetailWords> words = new ArrayList<>();
    List<DetailWords> rWords = new ArrayList<>();
    private void toGetData(UnitData data) {
        words = LitePal.where("uid = ? and sectionId = ?", String.valueOf(uid), String.valueOf(sectionId)).find(DetailWords.class);
        Log.d(TAG, "toGetData: uid  "  + uid + "    words.size()  " + words.size() + "   qq  " + ids);
        if (words.size() == 0){
            for (Children c : data.getChildren()) {
                if (c.getChildren() != null) {
                    for (Children2 c2 : c.getChildren())
                        for (int id : ids)
                            if (c2.getId() == id){
                                unitWords.addAll(c2.getWord());
                                break;
                            }
                } else
                    for (int id : ids)
                        if (c.getId() == id){
                            unitWords.addAll(c.getWord());
                            break;
                        }
            }
            Log.w(TAG, "toGetData:uuuuuuuuuuuuuuuuuuuuuuuuuu 1111" + unitWords.size() );
        } else{
            for (DetailWords d : words)
                if (d.getIsNewWord() == 1)
                    unitWords.add(d.getWord());
            Log.w(TAG, "toGetData:uuuuuuuuuuuuuuuuuuuuuuuuuu 22222" + unitWords.size() );
        }


        if (Config.isIsNeedToRefresh()){
            rWords = LitePal.where("uid = ? and iscontrol > ?", String.valueOf(uid), String.valueOf(1)).find(DetailWords.class);
            Log.d(TAG, "initData: rWords.size  isControl > 1  " + rWords.size());
            //根据时间判断单词是否已经到了复习时间
            TimeProcess.isTimeToRecover(rWords);
            Config.setIsNeedToRefresh(false);
        }

        rWords = LitePal.where("uid = ? and iscontrol = ?", String.valueOf(uid), String.valueOf(1)).find(DetailWords.class);
        //复习单词最多显示20个
        if (rWords.size() != 0 && rWords.size() > 20){
            for (int i = 0; i < 20; i ++)
                recoverWords.add(rWords.get(i).getWord());
        }
        Log.w(TAG, "toGetData:uuuuuuuuuuuuuuuuuuuuuuuuuu3333 " + unitWords.size() );
//        else
//            for (DetailWords d : rWords)
//                if (d.getIsControl() == 1)
//                    recoverWords.add(d.getWord());
    }


    /**
     *      获取书本内容
     *      下载文件，并解压zip
     *
     */
    List<BookDetails> bookDetails = new ArrayList<>();
    BookData bookData;
    private class unitAsyncTask extends AsyncTask<Integer, Void, Void>{
        @Override
        protected Void doInBackground(Integer... integers) {
            AuthHelper.newAuth(getContext());
            HttpUtil.setAuth(getContext());
            bookDetails.clear();
            bookDetails.addAll(LitePal.where("bid = ?", String.valueOf(bid)).find(BookDetails.class));
            Log.d(TAG, "doInBackground: " + bookDetails.size());
            if (bookDetails.size() == 0){
                bookData = HttpUtil.requestBookData(grade);
                if (bookData != null &&  bookData.getData()!= null) {
                    bookDetails = bookData.getData().getBooks();
                    for (BookDetails details : bookDetails){
                        details.setCover(details.getCover());
                        String bName = details.getName();
                        if (bName.length() > 2)
                            bName = bName.substring(2);
                        details.setGradeName(bName);
                        details.setName(details.getEdition().getName());
                        details.setGrade(details.getGrade());
                        details.setBid(details.getBid());
                        details.setPackageUri(details.getPackageUri());
                        details.setWordPackageUri(details.getWordPackage().getPackageUri());
                        details.save();
                    }
                } else{
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);
                }
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            String path = null;
            if (bookDetails.size() != 0){
                for (BookDetails details : bookDetails){
                    if (details.getBid() == bid){
                        path = details.getWordPackageUri();
                        break;
                    }
                }
                String finalPath = path;
                Thread thread = new Thread(){
                    @Override
                    public void run(){
                        String result = null;
                        try {
//                            result = HttpDownloader.download( Config.ADDRESS_RESOURCE + finalPath);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Log.d(TAG, "run: result " + result);
                        String regEx="[^0-9]";
                        Pattern p = Pattern.compile(regEx);
                        Matcher m = p.matcher(result);
                        String bid =  m.replaceAll("").trim();
                        try {
                            FileInputStream mFileInStream = null;
                            File mFile = new File(result);
                            byte[] s = new byte[1024];
                            if (mFile.exists()) {
                                mFileInStream = new FileInputStream(mFile);
                                s = HttpDownloader.bookReadBuffer(mFileInStream, true);
                            }
//                            HttpDownloader.bytesToFile(getContext(), s, bid);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                };
                thread.start();
            }
        }

    }

    //处理完成后给handler发送消息
    public void hideDownloading(){
        Message msg = new Message();
        msg.what = 0;
        handler.sendMessage(msg);
    }

    String unitInfo2 = null;
    UnitData unitData2;

    List<Integer> unitIdList2 = new ArrayList<>();
    List<String> unitNameList2 = new ArrayList<>();
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0) {
                loadStatusView.setHide();
//                book_downloading.setVisibility(View.GONE);
                String fileString =  HttpDownloader.readFileData(Config.rewordsPath + "book.json");

                Gson gson = new Gson();
                unitData2 = gson.fromJson(fileString, UnitData.class);
                if (unitData2.getChildren() != null && unitData2.getChildren().size() != 0){
                    for (Children children : unitData2.getChildren()){
                        if (children.getChildren() != null){
                            //二级目录处理
                            for (Children2 children2 : children.getChildren()){
                                //将章节id和章节名保存
                                if (children2.getWord() != null){
                                    Config.getUnitIdList().add(children2.getId());
                                    Config.getUnitNameList().add(children2.getName());
                                }
                            }
                            sharePreference.putIntList("unitIdList", Config.getUnitIdList());
                            sharePreference.putStringList("unitNameList", Config.getUnitNameList());
                            Log.d("ModuleUnitAdapter", "init: " + Config.getUnitIdList().size() + "   " + Config.getUnitNameList().size());
                        } else {
                            //将章节id和章节名保存
                            if (children.getWord() != null){
                                unitIdList2.add(children.getId());
                                unitNameList2.add(children.getName());
                            }
                        }
                    }

                    if (unitIdList2.size() != 0){
                        sharePreference.putIntList("unitIdList", unitIdList2);
                        sharePreference.putStringList("unitNameList", unitNameList2);
                    }
                }
                //书本单元数据，转成string便于传输
                unitInfo2 =  ObjectChangeString.objectToString(unitData2);
                sharePreference.putString("unitDataString", unitInfo2);
                sharePreference.commit();
                initData(unitData2, 0);
            } else if (msg.what == 1)
                loadStatusView.setError();

        }
    };

    @Override
    protected void initView(View v) {
        loadStatusView = v.findViewById(R.id.load_status_view);
        btn_no_login = v.findViewById(R.id.no_login_btn);
//        fragment_book_downloading = v.findViewById(R.id.fragment_book_downloading);
        rl_select_book = v.findViewById(R.id.rl_book);
        new_word = v.findViewById(R.id.new_word);
        recover_word = v.findViewById(R.id.study_again_word);
        learn_complete_text = v.findViewById(R.id.learn_complete_text);
        estimated_time_text = v.findViewById(R.id.estimated_time);
        book = v.findViewById(R.id.book);
        book_unit = v.findViewById(R.id.book_unit);
        img_com_time = v.findViewById(R.id.img_com_time);

        btn_start_learn = v.findViewById(R.id.btn_start_learn);
        btn_continue_study = v.findViewById(R.id.btn_continue_study);
        btn_switch_book = v.findViewById(R.id.btn_switch_book);
        btn_setting = v.findViewById(R.id.btn_setting);
        btn_study = v.findViewById(R.id.btn_study);

        btn_study.setOnClickListener(this);
        btn_no_login.setOnClickListener(this);
        btn_switch_book.setOnClickListener(this);
        btn_start_learn.setOnClickListener(this);
        btn_continue_study.setOnClickListener(this);
        btn_setting.setOnClickListener(this);
        rl_select_book.setOnClickListener(this);

        btn_switch_book.setVisibility(View.INVISIBLE);
        btn_continue_study.setVisibility(View.INVISIBLE);
        btn_start_learn.setVisibility(View.VISIBLE);

        learn_complete_text.setVisibility(View.INVISIBLE);
        estimated_time_text.setVisibility(View.VISIBLE);
        img_com_time.setVisibility(View.VISIBLE);

        cl_fragment = v.findViewById(R.id.cl_fragment);
        no_login_view = v.findViewById(R.id.no_login_view);
    }



}
