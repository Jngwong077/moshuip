package com.readboy.simpleLauncher.rewords.fragment;

import static com.readboy.simpleLauncher.rewords.tool.TimeProcess.isTodayFirstLearn;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;

import com.google.gson.reflect.TypeToken;
import com.readboy.auth.Auth;
import com.readboy.loveread.fragment.base.LazyFragment;
import com.readboy.practiselistening.ListeningApplication;
import com.readboy.practiselistening.receiver.NetworkReceiverHelper;
import com.readboy.practiselistening.utils.NetUtil;
import com.readboy.practiselistening.view.LoadStatusView;
import com.readboy.simpleLauncher.MainActivity;
import com.readboy.simpleLauncher.Main_UI.Fragment.Tool.ToastUtil;
import com.readboy.simpleLauncher.MyApplication;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.aiconversation.utils.SystemPropertiesInvoke;
import com.readboy.simpleLauncher.rewords.AuthHelper;
import com.readboy.simpleLauncher.rewords.RewordsActivity;
import com.readboy.simpleLauncher.rewords.complete.CompleteActivity;
import com.readboy.simpleLauncher.rewords.data.ObjectChangeString;
import com.readboy.simpleLauncher.rewords.data.book.BookData;
import com.readboy.simpleLauncher.rewords.data.book.BookDetails;
import com.readboy.simpleLauncher.rewords.data.book.Children;
import com.readboy.simpleLauncher.rewords.data.book.Children2;
import com.readboy.simpleLauncher.rewords.data.book.UnitData;
import com.readboy.simpleLauncher.rewords.data.detail_word.DBInstance;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AllWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AllWordsDao;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWordsDao;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.NewWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.NewWordsDao;
import com.readboy.simpleLauncher.rewords.data.netRecords.BookReacordsData;
import com.readboy.simpleLauncher.rewords.data.netRecords.CheckBookData;
import com.readboy.simpleLauncher.rewords.download.HttpDownloader;
import com.readboy.simpleLauncher.rewords.setting.WindowUtils;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.GetUserInfo;
import com.readboy.simpleLauncher.rewords.tool.HttpUtil;
import com.readboy.simpleLauncher.rewords.tool.IsNetWorkConnected;
import com.readboy.simpleLauncher.rewords.tool.Pagination;
import com.readboy.simpleLauncher.rewords.tool.PlayWordSound;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;
import com.readboy.simpleLauncher.rewords.tool.TimeProcess;

import org.json.JSONException;
import org.json.JSONObject;
import org.litepal.LitePal;

import java.io.File;
import java.io.FileInputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by jng wong
 * on 2022/8/24 10:20
 */
public class Fragment_Learning_Word extends Fragment implements View.OnClickListener {

    private int bid;
    private int grade;
    private long uid;
    private String TAG = "Fragment_Learning_Word";
    private String unitInfo;

    private TextView mTextView, title_text;
    private ImageView choice_box;


    /*      学习单词界面控件        */
    private ConstraintLayout cl_background, cl_sound, cl_hand, cl_scroll_view, cl_word_info;
    private RelativeLayout rl_explain, rl_complete;
    private TextView word_pronunciation, word, word_eng_sentence, word_info, page_text, pre_page, next_page;
    private ImageView img_word_play, tip_1, tip_2, tip_3;

    private Button btn_un_control, btn_control, btn_next;
    private TextView btn_motify;
    private ImageButton btn_go_tip;

    /*      学习结束界面控件        */
    ConstraintLayout cl_end_of_round, cl_end_bottom;
    RecyclerView rv_end_img;
    ImageView end_img;
    TextView end_congratulations_text, end_encourage_text, end_go_continue, end_view_study_details;
    Button btn_end_again, btn_end_change_plan;


    private Pagination mPagination;
    private CharSequence mText;
    /*      单词释义页码      */
    private int mCurrentIndex = 0;


    SettingSharePreference sharePreference;
    LoadStatusView loadStatusView;
    Dialog_Fragment_Choice dialogFragment_choice;
    Fragment_Tip fragment_tip;

    UnitData unitData;

    NewWordsDao newWordsDao;
    DetailWordsDao recoverWordDao;
    AllWordsDao allWordsDao;

    /*      不出现重复元素的数组      */
    LinkedHashSet<String> hashSet = new LinkedHashSet<>();

    Boolean isCover = false;
    private NetworkReceiverHelper networkReceiverHelper;

    // 插拔是否注册
    private boolean mReceiverTag = false;
    private static final String BROADCAST_INK_PAD_PLUG = "com.readboy.intent.action.InkPadPlug";


    static Fragment_Learning_Word instance;

    public static Fragment_Learning_Word getInstance() {
        return instance;
    }


    public static Fragment_Learning_Word newInstance(Boolean is) {
        if (is){
            return new Fragment_Learning_Word();
        } else
            return null;
    }
    Context mContext;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.w("bbbbbb", " onCreate" + this.getUserVisibleHint() );
        instance = this;
        sharePreference = new SettingSharePreference(getContext());
        mContext = getContext();
        /*       注册网络监听器        */
        networkReceiverHelper = new NetworkReceiverHelper(ListeningApplication.getApp());
        networkReceiverHelper.register();

        networkReceiverHelper.setOnNetworkListener(networkState -> {
            if (networkState != NetUtil.NETWORK_NONE){
                // 有网络
                Log.w(TAG, "uploadWordRecords: 有网络拉！！！！" + networkState);
                String obj = sharePreference.getString("obj", "");
                if (!obj.equals("[]"))
                    uploadWordRecords(ObjectChangeString.stringToDetailWords(obj));
            }
        });




    }

    @Override
    public void onResume() {
        super.onResume();

    }

    /**
     *      学习单词界面
     */
    int g;
    public void showLearningView(Context context) {
        mContext = context;
//        if (cl_all != null)
//            cl_all.setVisibility(View.VISIBLE);

        recoverWordDao = DBInstance.initDb(mContext).detailWordsDao();
        newWordsDao = DBInstance.initDb(mContext).newWordsDao();
        allWordsDao = DBInstance.initDb(mContext).allWordsDao();

        unitInfo = null;
        if (sharePreference == null)
            sharePreference = new SettingSharePreference(mContext);
        unitInfo = sharePreference.getString("unitDataString", "");

        cl_end_of_round.setVisibility(View.GONE);
        loadStatusView.setHide();
        if (GetUserInfo.getUserBaseInfo(mContext) != null) {
            uid = GetUserInfo.getUserBaseInfo(mContext).uid;
            Log.i("TAG", "showUpdateDialog:  showLearningView  " + uid);
            sharePreference.putLong("uid", uid);
            sharePreference.commit();
            g =  GetUserInfo.getUserBaseInfo(mContext).gradeInt + 1;
            bid = GetUserInfo.getEngBookId(mContext);
        } else {
            uid = 111111;
            g = 3;
            bid = 9803167;
        }
//        uploadBookRecords(null);
//        requestBookRecords();
//        requestWordRecords();


        grade = sharePreference.getInt("grade", g);

        if (!unitInfo.equals("")){
            cl_background.setVisibility(View.VISIBLE);
            unitData = ObjectChangeString.stringToUnitData(unitInfo);
            initData(unitData, 2);
        } else {
            cl_background.setVisibility(View.INVISIBLE);
            loadStatusView.setLoading();
            new unitAsyncTask().execute();
        }
    }


    private int bookId;
    List<Integer> unitIdList = new ArrayList<>();
    List<Integer> noHaveIdList = new ArrayList<>();

    ArrayList<String> unitWords = new ArrayList<>();
    private List<DetailWords> detailWords = new ArrayList<>();
    private int number = 0;
    private void initData(UnitData data, int i) {
        if (cl_background != null)
            cl_background.setVisibility(View.VISIBLE);

        if (TimeProcess.isTodayFirstLearn(mContext))
            Config.ROUND = 0;


        if (data != null && data.getChildren() != null && data.getChildren().size() != 0){
            bookId = sharePreference.getInt("bookId",  bid);
            sharePreference.putInt("grade", grade);
            sharePreference.putInt("bookId", bookId);
            Log.d("bbbbbb", "  uid : " + uid + "\n" +
                    "  bookId: " + bookId + "\n" +
                    "  grade: " + g + "  TimeProcess.isTodayFirstLearn(mContext):   " + TimeProcess.isTodayFirstLearn(mContext));
            String bName = data.getName();
            if (bName.length() > 2)
                bName = bName.substring(2);
            sharePreference.putString("bookName", data.getEdition().getName() + bName);

            String beforeidl = sharePreference.getString("beforeUnitIdList", "");
            String nowIdl = sharePreference.getString("unitIdList", "");
            sharePreference.putString("beforeUnitIdList", nowIdl);
            sharePreference.commit();
            isSectionIdChange = !beforeidl.equals(nowIdl);
            Log.e("bbbbbb", "   unitIdList:" + nowIdl + "     " + isSectionIdChange);

            if (!nowIdl.equals("")){
                Gson g = new Gson();
                List<Integer> idList;
                /*      将json数据转成List集合     */
//                idList = g.fromJson(beforeidl, new TypeToken<List<Integer>>(){}.getType());
                unitIdList = g.fromJson(nowIdl, new TypeToken<List<Integer>>(){}.getType());
//                List<Boolean> unitSelectList;
//                Log.v("bbbbbb", " idList" + idList);
//                String usl = sharePreference.getString("unitSelectList", "");
//                if (!usl.equals("")){
//                    unitSelectList =  g.fromJson(usl, new TypeToken<List<Boolean>>(){}.getType());
//                    Log.w("bbbbbb", " unitSelectList" + unitSelectList);
//                    if (unitSelectList.size() != 0){
//                        unitIdList.clear();
//                        for (int k = 0; k < idList.size(); k++)
//                            if (unitSelectList.get(k))
//                                unitIdList.add(idList.get(k));
//                    }
//                }
//                if (idList != null)
//                    for (int d : unitIdList)
//                        if (!idList.contains(d))
//                            noHaveIdList.add(d);
//
//
//
//                Log.e("bbbbbb", "   beforeidl:" + idList + "\n"  +
//                        " unitIdList" + unitIdList + "\n" +
//                        "   noHaveIdList:" + noHaveIdList);

                if (unitIdList.size() != 0)
                    initLearning(data);

            }

        }

    }

    Dialog_introduction dialog_introduction;
    boolean isClickEndToAgain = false;
    boolean isSectionIdChange = false;
    boolean isFirstOpen = true;
    private void initLearning(UnitData data) {
        unitWords.clear();
        Config.UN_CONTROL_NUMBER = 0;
        /*      第一次打开背单词app页面 /相当于引导页       */
        isFirstOpen = sharePreference.getBoolean("isFirstOpen", true);
        if (isFirstOpen){
            sharePreference.putBoolean("isFirstOpen", false);
            sharePreference.commit();
            if (dialog_introduction == null)
                dialog_introduction = new Dialog_introduction();
            dialog_introduction.show(getFragmentManager(), "DialogIntroduction");
        }

        loaddingWords(data);

        toFindWordIsExist(unitWords);

        if (unitWords != null)
            saveWordData();

        detailWords.clear();
//        if (ObjectChangeString.objectToString(detailWords).equals("[]"))
//            Log.v(TAG, "uploadWordRecords:  " + ObjectChangeString.objectToString(detailWords) + "    " +
//                        ObjectChangeString.stringToDetailWords(ObjectChangeString.objectToString(detailWords))
//                );


        /*          每轮的开始，appear-1，需判断何时为开始！        */
        if (recoverWordDao.getAll(uid).size() != 0 && (TimeProcess.isTodayFirstLearn(Objects.requireNonNull(getActivity())) || isClickEndToAgain || isSectionIdChange)){
            isClickEndToAgain = false;
            recoverWordDao.updateAll(uid);
            Log.w(TAG, "onFinsh initLearning: updateAllupdateAllupdateAllupdateAll");
        }

        /**
         *  单词的获取规则：
         *  当章节id发生改变时，优先学习章节id内的新单词，不足数量则补充复习库单词
         *          没发生改变时。优先学习复习库单词，不足则补充章节id单词
         *
         */
        if (isSectionIdChange){
            isSectionIdChange = false;
            detailWords.addAll(newWordsDao.getAll());
            if (detailWords.size() < Config.WORD_NUMBER)
                sortingDb();
        } else {
            sortingDb();
            if (detailWords.size() < Config.WORD_NUMBER && !isSectionIdChange)
                detailWords.addAll(newWordsDao.getAll());
        }

        Log.w(TAG, "detailWords before: " + detailWords.size() + " isTodayFirstLearn " + isTodayFirstLearn(Objects.requireNonNull(getActivity())) );

//            if (words.size() != 0)
//                detailWords.addAll(words);
        if (detailWords.size() > Config.WORD_NUMBER)
            detailWords = detailWords.subList(0, Config.WORD_NUMBER);

        setWordInfo();

    }

    /*      根据是否为每日首次学习对获取到的数据进行排序      */
    private void sortingDb(){
        if (isTodayFirstLearn(Objects.requireNonNull(getActivity()))) {
            detailWords.addAll(recoverWordDao.getTodayFirstLearn(uid));
        } else
            detailWords.addAll(recoverWordDao.getUnFirstLearn(uid));

        Log.w(TAG, "detailWords sortingDb: " + recoverWordDao.getTodayFirstLearn(uid).size() + "\n sadas   " + recoverWordDao.getUnFirstLearn(uid).size() );

    }

    /**
     *      初始化单词数据
     */
    private void setWordInfo() {
        /*      顶部花显示       */
        showOrHideFlower(Config.ROUND);

        cl_sound.setVisibility(View.VISIBLE);
        cl_hand.setVisibility(View.VISIBLE);
        rl_explain.setVisibility(View.INVISIBLE);
        String tt = "";
        for (DetailWords d : detailWords){
            tt += d.getWord() + " lt:" + d.getLearnTime()+ " ar:" + d.getAppear() + " \n";
        }

        mTextView.setText(tt);
        if (detailWords.size() != 0){
            if (!sharePreference.getBoolean("is_auto_read", true)){
                if (!sharePreference.getBoolean("word_sound_is_en", true)) {
                    String text = detailWords.get(number).getUs_bs().equals("") ? detailWords.get(number).getUk_bs() : detailWords.get(number).getUs_bs();
                    word_pronunciation.setText(text);
                } else
                    word_pronunciation.setText(detailWords.get(number).getUk_bs());
            } else
                phraseNoUS();

            word.setText(detailWords.get(number).getWord());
            word_eng_sentence.setText(detailWords.get(number).getSentence());
        }

    }

    String recoverWordSound;
    String uWord;
    File ukSoundFile;
    File usSoundFile;

    /**
     *      单词为短语时,有无美音的特殊处理
     */
    private void phraseNoUS() {
        Log.e("bbbbbb", "phraseNoUS: " + Fragment_Control.getInstance().getUserVisibleHint());
        if (detailWords.get(number).getIsNewWord() == 1 || detailWords.get(number).getIsFromNet() == 1){
            uWord = detailWords.get(number).getWord();
//            ukSoundFile = new File(Config.rewordsPath + "uk_word_sound/" + uWord + ".mp3");
//            usSoundFile = new File(Config.rewordsPath + "us_word_sound/" + uWord + ".mp3");
//
//            Log.d(TAG, "phraseNoUS: ukSoundFile.exists   " + ukSoundFile.exists());
//            //单词为短语时的文件名有些为look_up，有些为look up，此处为特殊处理
//            dealSpecialWord();

            ukSoundFile = new File(Config.rewordsPath + uid + "/" + detailWords.get(number).getBookId() + detailWords.get(number).getUk_word_sound());
            usSoundFile = new File(Config.rewordsPath + uid + "/" + detailWords.get(number).getBookId() + detailWords.get(number).getUs_word_sound());

            Log.d(TAG, "phraseNoUS: ukSoundFile.exists   " + ukSoundFile.exists());

            if (sharePreference.getBoolean("word_sound_is_en", true)) {
                word_pronunciation.setText(detailWords.get(number).getUk_bs());
                PlayWordSound.setMediaPlayer(ukSoundFile.toString());
                recoverWordSound = ukSoundFile.toString();
            } else
                /*  当短语美式读音为空，故判断当前读音是否是美式，美式的就拿英式去发音   */
                if (!usSoundFile.exists()) {
                    word_pronunciation.setText(detailWords.get(number).getUk_bs());
                    PlayWordSound.setMediaPlayer(ukSoundFile.toString());
                    recoverWordSound = ukSoundFile.toString();
                } else {
                    String text = detailWords.get(number).getUs_bs().equals("") ? detailWords.get(number).getUk_bs() : detailWords.get(number).getUs_bs();
                    word_pronunciation.setText(text);
                    PlayWordSound.setMediaPlayer(usSoundFile.toString());
                    recoverWordSound = usSoundFile.toString();
                }
        } else {
            /*      当单词为复习单词时的处理        */
            if (!sharePreference.getBoolean("word_sound_is_en", true)) {
                String text = detailWords.get(number).getUs_bs().equals("") ? detailWords.get(number).getUk_bs() : detailWords.get(number).getUs_bs();
                word_pronunciation.setText(text);
            } else
                word_pronunciation.setText(detailWords.get(number).getUk_bs());

            PlayWordSound.setMediaPlayer(detailWords.get(number).getPathSound());
        }

    }

    /**
     *      单词文件的特殊处理
     *
     */
    private void dealSpecialWord(){
        ArrayList<File> files = new ArrayList<>();
        String directoryName = Config.rewordsPath + "uk_word_sound/";
        File directory = new File(directoryName);
        File[] fList = directory.listFiles();

        if (!ukSoundFile.exists()){
            if (uWord.contains(" "))
                uWord = uWord.replaceAll(" ", "_");
            uWord = uWord.toLowerCase();
            Log.e(TAG, "dealSpecialWord: uWord  " + uWord + "    fList: " + Arrays.toString(fList));
            if (fList != null){
                for (File file : fList)
                    if (file.isFile() && file.getName().endsWith(".mp3"))
                        files.add(file);

                for (File s : files)
                    if (s.getName().contains(uWord)){
                        ukSoundFile = s;
                        break;
                    }
            } else {
                ToastUtil.showToast(mContext, "课本资料发生错误，请重新选择课本");
            }
        }

    }


    /**
     *      加载所选章节单词
     * @param data
     */
    private void loaddingWords(UnitData data) {
        for (Children c : data.getChildren()) {
            if (c.getChildren() != null) {
                for (Children2 c2 : c.getChildren())
                    for (int id : unitIdList)
                        if (c2.getId() == id){
                            unitWords.addAll(c2.getWord());
                            break;
                        }
            } else
                for (int id : unitIdList)
                    if (c.getId() == id){
                        unitWords.addAll(c.getWord());
                        break;
                    }
        }

        Log.w("bbbbbb", "toGetData: unitWords.size  " + unitWords.size() );
    }


    /**
     *      对于生词库中不包含所选单词的处理
     *
     */
    private void toFindWordIsExist(ArrayList<String> list){
        List<DetailWords> find =  newWordsDao.getAll();
        List<String> noFindWordList = new ArrayList<>();
        boolean isExist = false;
        for (int i = 0; i < find.size(); i++){
            for (String str : list){
                isExist = false;
                if (str.equals(find.get(i).getWord())){
                    isExist = true;
                    break;
                }
            }

            if (!isExist)
                noFindWordList.add(find.get(i).getWord());
        }

        Log.d(TAG, "noFindWordList : " + noFindWordList);

        for (String str : noFindWordList)
            newWordsDao.delete(str);
    }


    /**
     *      将单词数据入库
     */
    List<DetailWords> words = new ArrayList<>();
    private void saveWordData() {
        if (Config.words == null)
            Config.words = new ArrayList<>();
        if (Config.words.size() == 0){
            String fileString =  HttpDownloader.readFileData(Config.rewordsPath + uid + "/" + bookId +"/" + "words.json");
            Log.w("bbbbbbb",   "saveWordData: bookId: " + bookId + "  uid :" + uid );
            Gson gson = new Gson();
            Config.words = gson.fromJson(fileString, new TypeToken<List<DetailWords>>() {}.getType());
        }

        words = Config.words;
        if (words != null && words.size() != 0) {
            Log.d(TAG, "saveWordData: words.size " + words.size() );

            sharePreference.putInt("bookCount", words.size());
            sharePreference.commit();
            for (String s : unitWords) {
                for (DetailWords w : words) {
                    if (w.getWord().equals(s) && newWordsDao.getIsExit(s) == null && recoverWordDao.getOne(s) == null  && w.getUk_word_sound() != null){
                        NewWords newWords = new NewWords();
                        newWords.setUid(uid);
                        newWords.setIsNewWord(1);

                        newWords.setWord(w.getWord());
//                        newWords.setWord(w.getSync_explain());
                        newWords.setExplain(w.getExplain());

                        newWords.setBookId(bookId);
                        newWords.setUk_word_sound(w.getUk_word_sound());
                        newWords.setUs_word_sound(w.getUs_word_sound());

                        newWords.setUk_bs(w.getUk_bs());
                        newWords.setUs_bs(w.getUs_bs());
                        newWords.setSentence(w.getSentence());
                        newWords.setSentence_explain(w.getSentence_explain());
                        if (w.getCommon_phrases() != null && w.getCommon_phrases().size() != 0){
                            if (w.getCommon_phrases().get(0).getContent().size() == 1) {
                                newWords.setWord_parse(w.getCommon_phrases().get(0).getContent().get(0).getText());
                                newWords.setWord_parse_explain(w.getCommon_phrases().get(0).getContent().get(0).getParaphrase());
                            } else {
                                newWords.setWord_parse(w.getCommon_phrases().get(0).getContent().get(0).getText());
                                newWords.setWord_parse_explain(w.getCommon_phrases().get(0).getContent().get(0).getParaphrase());
                                newWords.setWord_parse2(w.getCommon_phrases().get(0).getContent().get(1).getText());
                                newWords.setWord_parse_explain2(w.getCommon_phrases().get(0).getContent().get(1).getParaphrase());
                            }
                        }
                        newWordsDao.insert(newWords);
                        break;
                    }

                }
            }
        }
    }


    @Override
    public void onPause() {
        super.onPause();
        Log.i("bbbbbb", "onFragmentPause: FLW   " + this.getUserVisibleHint());

    }

//    @Override
//    protected void onFragmentPause() {
//    }



    @SuppressLint({"NonConstantResourceId", "SetTextI18n"})
    @Override
    public void onClick(View v) {
        if (Config.isFastDoubleClick()) return;//防止快速点击
        switch (v.getId()){
            case R.id.cl_sound:
                PlayWordSound.stop();
                if (detailWords.size() != 0){
                    //由于接口短语美式读音为空，故判断当前读音是否是美式，美式的就拿英式去发音
                    phraseNoUS();
                }
                break;
            case R.id.word_eng_sentence:
            case R.id.scroll_view:
            case R.id.rl_explain:

                cl_hand.setVisibility(View.VISIBLE);
                rl_explain.setVisibility(View.INVISIBLE);
                break;

            case R.id.cl_hand:
                cl_hand.setVisibility(View.INVISIBLE);
                rl_explain.setVisibility(View.VISIBLE);
                break;
            case R.id.pre_page:
                Log.w(TAG, "textPageFlip: " + mCurrentIndex  + mPagination.size());
                mCurrentIndex = (mCurrentIndex > 0) ? mCurrentIndex - 1 : 0;
                if (mCurrentIndex == 0){
                    word_info.setMaxLines(8);
                    cl_sound.setVisibility(View.VISIBLE);
                    rl_complete.setVisibility(View.VISIBLE);
                }

                update();
                break;
            case R.id.next_page:
                Log.w(TAG, "textPageFlip: " + mCurrentIndex  + mPagination.size());
                if (mPagination.size() != 1){
                    cl_sound.setVisibility(View.GONE);
                    rl_complete.setVisibility(View.GONE);
                }
                mCurrentIndex = (mCurrentIndex < mPagination.size() - 1) ? mCurrentIndex + 1 : mPagination.size() - 1;
                word_info.setMaxLines(18);
                update();
                break;
            case R.id.btn_un_control:
                unrecognizeDeal();
                break;
            case R.id.btn_control:
                recognizeDeal();
                break;
            case R.id.btn_next:
                mCurrentIndex = 0;
                nextWord();
                break;
            case R.id.btn_motify:

                break;

        }
    }

    /*      下一个单词处理   */
    private void nextWord(){
        if (detailWords.size() != 0){
            PlayWordSound.stop();
            number++;

            if (number == detailWords.size()){
                cl_background.setVisibility(View.GONE);
                cl_end_of_round.setVisibility(View.VISIBLE);
                endOfRoundDeal();
            } else
                setWordInfo();
        }

        cl_sound.setVisibility(View.VISIBLE);
        cl_hand.setVisibility(View.VISIBLE);
        cl_word_info.setVisibility(View.GONE);
        btn_un_control.setVisibility(View.VISIBLE);
        btn_control.setVisibility(View.VISIBLE);
    }


    /*      认识处理        */
    private void recognizeDeal(){
        int item = 1;

//        String[] status = new String[] { "认识", "不认识" };
//        AlertDialog.Builder dialog = new AlertDialog.Builder(mContext);
//        dialog.setTitle("单词状态");
//        dialog.setSingleChoiceItems(status, 1, (d, which) -> {
//            d.dismiss();
//        });
//
//        dialog.setCancelable(true);
//        dialog.show();
//
//        AlertDialog dialog2 = new AlertDialog.Builder(mContext).create();
//        dialog2.setCancelable(true);
//        dialog2.show();
//        Window window = dialog2.getWindow();
//        // 设置对话框的大小
//        android.view.WindowManager.LayoutParams layoutParams = dialog2.getWindow().getAttributes();
//        DisplayMetrics dm = getResources().getDisplayMetrics(); //获取该弹窗的参数值
//        int displayHeight = dm.heightPixels;
//        layoutParams.height = (int) (displayHeight * 0.22);    //宽度设置为屏幕的0.8
//        dialog2.getWindow().setAttributes(layoutParams);
//        window.setContentView(R.layout.dialog_rewords);

        if (detailWords.size() != 0){
            if (rl_explain.getVisibility() == View.VISIBLE){
                /*          生词库减一，复习库加一       */
                if (newWordsDao.getIsExit(detailWords.get(number).getWord()) != null){
                    newWordsDao.delete(detailWords.get(number).getWord());
                    if (recoverWordDao.getOne(detailWords.get(number).getWord()) == null){
                        recoverWordDao.insert(detailWords.get(number));
                    } else
                        recoverWordDao.updateData(detailWords.get(number));
                }

                PlayWordSound.stop();
                hashSet.add(detailWords.get(number).getWord());
                /*          点击掌握时的数据库更新     */
                controlDeal(true);
                /*          随机数的生词              */
                Random ra = new Random();
                int random = ra.nextInt(Config.WORD_APPEAR_RAN_MAX - Config.WORD_APPEAR_RAN_MIN) + Config.WORD_APPEAR_RAN_MIN;
                Log.w(TAG, "random: " + random  + "  learn: " + learn);
                if (detailWords.get(number).getIsNewWord() == 0) {
                    recoverWordDao.updatecontrol(appear, learn, detailWords.get(number).getWord());
                    detailWords.get(number).setLearnTime(learn);
                } else {
                    recoverWordDao.updateNewControl(random, detailWords.get(number).getWord());
                    detailWords.get(number).setLearnTime(7);
                    detailWords.get(number).setWrongClick(1);
                }
                /*          保存单词音频              */
                saveRecoverWordSound();

                /*      翻页        */
                textPageFlip();

                cl_word_info.setVisibility(View.VISIBLE);
                btn_control.setVisibility(View.INVISIBLE);
                btn_un_control.setVisibility(View.INVISIBLE);

                cl_hand.setVisibility(View.INVISIBLE);
                rl_explain.setVisibility(View.INVISIBLE);

            } else {
                phraseNoUS();

                cl_hand.setVisibility(View.INVISIBLE);
                rl_explain.setVisibility(View.VISIBLE);
            }

        }
    }

    /*      不认识处理       */
    private void unrecognizeDeal(){
        if (rl_explain.getVisibility() == View.VISIBLE){
            PlayWordSound.stop();
            /*          保存单词音频              */
            saveRecoverWordSound();

            detailWords.get(number).setIsNewWord(0);
            /*          生词库去掉该单词，复习库新增该单词       */
            if (newWordsDao.getIsExit(detailWords.get(number).getWord()) != null){
                newWordsDao.delete(detailWords.get(number).getWord());
                if (recoverWordDao.getOne(detailWords.get(number).getWord()) == null){
                    recoverWordDao.insert(detailWords.get(number));
                } else
                    recoverWordDao.updateData(detailWords.get(number));
            }

            if (detailWords.size() != 0){
                phraseNoUS();
                detailWords.add(detailWords.get(number));
                hashSet.add(detailWords.get(number).getWord());
            }

            /*          未掌握时的数据库更新       */
            controlDeal(false);
            if (detailWords.get(number).getLearnTime() > 0){
                recoverWordDao.updateUnControl(appear, learn, detailWords.get(number).getWord());
                detailWords.get(number).setLearnTime(learn);
            }


            /*          当未掌握数为5个时，跳到只学习这5个直到全部掌握        */
            if (Config.UN_CONTROL_NUMBER < 5)
                Config.UN_CONTROL_NUMBER++;

            if (Config.UN_CONTROL_NUMBER >= 5){
                if (detailWords.size() > 5){
                    Config.UN_CONTROL_NUMBER = 0;
                    number = detailWords.size() - 6;
                }
                for (int i = number; i < detailWords.size(); i++)
                    Log.e(TAG, "detailWords:number  " + detailWords.get(i).getWord() );
            }


            textPageFlip();

            cl_word_info.setVisibility(View.VISIBLE);
            btn_control.setVisibility(View.INVISIBLE);
            btn_un_control.setVisibility(View.INVISIBLE);

            cl_hand.setVisibility(View.INVISIBLE);
            rl_explain.setVisibility(View.INVISIBLE);
        } else {
            phraseNoUS();

            cl_hand.setVisibility(View.INVISIBLE);
            rl_explain.setVisibility(View.VISIBLE);
        }

    }


    /**
     *  复习单词，数据库处理逻辑
     *  controlTime  掌握次数
     *  isControl    是否已掌握
     *
     *  learnTime = 7存在两种情况：
     *  1.正常流程到learnTime=7
     *  2.生词点击了掌握learnTime=7，当该单词再次学习时，点击未掌握则需判断是否生词学习时误点掌握
     *  若未误点则learn=1，appear=1，反之，learn--，appear根据learn值而定
     */
    int appear;
    int learn;
    private void controlDeal(Boolean isControl){
        if (detailWords.get(number).getLearnTime() == 0){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : 0;
            appear = isControl ? Config.WORD_APPEAR_2 : Config.WORD_APPEAR_1;
        } else if (detailWords.get(number).getLearnTime() == 1){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
            appear = isControl ? Config.WORD_APPEAR_4 : Config.WORD_APPEAR_1;
        } else if (detailWords.get(number).getLearnTime() == 2){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
            appear = isControl ? Config.WORD_APPEAR_7 : Config.WORD_APPEAR_2;
        } else if (detailWords.get(number).getLearnTime() == 3){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
            appear = isControl ? Config.WORD_APPEAR_12 : Config.WORD_APPEAR_4;
        }  else if (detailWords.get(number).getLearnTime() == 4){

            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
            appear = isControl ? Config.WORD_APPEAR_21 : Config.WORD_APPEAR_7;

            appear = isControl ? Config.WORD_APPEAR_12 : Config.WORD_APPEAR_4;
        } else if (detailWords.get(number).getLearnTime() == 5){

            learn = isControl ? detailWords.get(number).getLearnTime() + 2 : detailWords.get(number).getLearnTime() - 1;
            appear = isControl ? Config.WORD_APPEAR_45 : Config.WORD_APPEAR_12;
        } else if (detailWords.get(number).getLearnTime() == 7){

            if(isControl){
                learn = detailWords.get(number).getLearnTime() + 1;
                appear = Config.WORD_APPEAR_50;
            } else {
                if (detailWords.get(number).getWrongClick() == 1)
                    recoverWordDao.updateWrongClick(detailWords.get(number).getWord());
                learn = detailWords.get(number).getWrongClick() == 1 ?  1 : detailWords.get(number).getLearnTime() - 1;
                appear = detailWords.get(number).getWrongClick() == 1 ? Config.WORD_APPEAR_1 : Config.WORD_APPEAR_21;
            }
        }

//        else if (detailWords.get(number).getLearnTime() == 6){
//
//            learn = isControl ? detailWords.get(number).getLearnTime() + 1 : detailWords.get(number).getLearnTime() - 1;
//        }

    }

    /**
     *      翻页处理
     */
    private void textPageFlip(){
        word_info.setMaxLines(8);
        String wordInfo;
        wordInfo = "释义：" + "\n";
        wordInfo += detailWords.get(number).getExplain() + "\n";
        wordInfo += "释义：" + "\n";
        wordInfo += detailWords.get(number).getExplain() + "\n";
        wordInfo += "释义：" + "\n";
        wordInfo += detailWords.get(number).getExplain() + "\n";
        wordInfo += "释义：" + "\n";
        wordInfo += detailWords.get(number).getExplain() + "\n";
        wordInfo += "\n" + "例句：" + "\n";
        wordInfo += detailWords.get(number).getSentence() + "\n";
        wordInfo += detailWords.get(number).getSentence_explain() + "\n";

        mText = Pagination.textProcess(wordInfo);
        word_info.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                // Removing layout listener to avoid multiple calls
                word_info.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                mPagination = new Pagination(
                        mText, word_info.getWidth(),
                        word_info.getHeight(),
                        word_info.getPaint(),
                        word_info.getLineSpacingMultiplier(),
                        word_info.getLineSpacingExtra(),
                        word_info.getIncludeFontPadding());
                update();
            }
        });

    }

    @SuppressLint("SetTextI18n")
    private void update() {
        final CharSequence text = mPagination.get(mCurrentIndex);
        page_text.setText((mCurrentIndex + 1) + "/" + mPagination.size());
        if (text != null) word_info.setText(text);
    }


    //保存复习单词的音频位置
    private void saveRecoverWordSound(){
        if (recoverWordSound != null && !recoverWordSound.equals("")){
            File oldFile = new File(recoverWordSound);
            File file = new File(Config.wordSoundPath + detailWords.get(number).getWord() + ".mp3");
            if (!file.exists() || isCover){
                isCover = false;
                Config.copyFile(oldFile, file);
            }

            if (detailWords.get(number).getIsNewWord() == 1){
                recoverWordDao.updateIsNewWord(file.toString(), detailWords.get(number).getWord());
                Log.w("bbbbbb", "saveRecoverWordSound: " );
            }
            detailWords.get(number).setPathSound(file.toString());
        }

    }


    /*         学习结束界面控制           */
    private void endOfRoundDeal(){
        Config.ROUND++;
        if(Config.ROUND >= 3){
            end_go_continue.setVisibility(View.VISIBLE);
            btn_end_again.setVisibility(View.GONE);
            btn_end_change_plan.setVisibility(View.GONE);
        } else {
            end_go_continue.setVisibility(View.GONE);
            btn_end_again.setVisibility(View.VISIBLE);
        }

        LinearLayoutManager manager = new LinearLayoutManager(mContext);
        manager.setOrientation(LinearLayoutManager.HORIZONTAL);
        rv_end_img.setLayoutManager(manager);
        End_Img_Adapter endImgAdapter = new End_Img_Adapter(mContext, Config.ROUND);

        rv_end_img.setAdapter(endImgAdapter);


        /*      中间图片显示           */
        int endBg =  Config.ROUND < 8 ? Config.end_bg[Config.ROUND - 1] : Config.end_bg[7];
        end_img.setBackgroundResource(endBg);

        /*      中间文本显示           */
        String m_text = Config.ROUND < 10 ? Config.learn_text[Config.ROUND - 1] : Config.learn_text[9];
        end_congratulations_text.setText(m_text);


        /*      底部提示文本显示        */
        String b_text = Config.ROUND < 3 ? Config.encourage_text[Config.ROUND - 1] : Config.encourage_text[2];
        end_encourage_text.setText(b_text);


        /*      修改计划监听            */
        btn_end_change_plan.setOnClickListener(v -> {
            if (dialogFragment_choice == null)
                dialogFragment_choice = new Dialog_Fragment_Choice(this);
            dialogFragment_choice.show(getFragmentManager(), "FragmentChoice");
        });

        /*      再来一组监听            */
        btn_end_again.setOnClickListener(v -> {
            number = 0;
            isClickEndToAgain = true;
            showLearningView(mContext);
        });


        /*      继续学习监听            */
        end_go_continue.setOnClickListener(v -> {
            number = 0;
            showLearningView(mContext);
        });

        ArrayList<DetailWords> haveLearningWord = new ArrayList<>();
        for (String w : hashSet)
            for (DetailWords d : detailWords)
                if (d.getWord().equals(w)){
                    haveLearningWord.add(d);
                    break;
                }
        String finalObj = ObjectChangeString.listObjectToString(haveLearningWord);
        String obj = null;
        if (!IsNetWorkConnected.isNetworkConnected(mContext)){
            List<DetailWords> lastList = new ArrayList<>();
            if (!sharePreference.getString("obj", "[]").equals("[]"))
                lastList.addAll(ObjectChangeString.stringToDetailWords(sharePreference.getString("obj", "[]")));

            haveLearningWord.addAll(lastList);
            obj = ObjectChangeString.listObjectToString(haveLearningWord);
            sharePreference.putString("obj", obj);
            sharePreference.commit();
        } else
            uploadWordRecords(haveLearningWord);


        /*      查看详情监听            */
        end_view_study_details.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(mContext, CompleteActivity.class);
            intent.putExtra("detailWords", finalObj);
            startActivity(intent);
        });
    }

    /*      学单词界面顶部的三朵小花        */
    private void showOrHideFlower(int r){
        btn_go_tip.setVisibility(View.VISIBLE);
        rl_complete.setVisibility(View.VISIBLE);
        if (r == 1) {
            tip_1.setBackgroundResource(R.drawable.flower_finsh);
            tip_2.setBackgroundResource(R.drawable.flower_no);
            tip_3.setBackgroundResource(R.drawable.flower_no);
        } else if (r == 2){
            tip_1.setBackgroundResource(R.drawable.flower_finsh);
            tip_2.setBackgroundResource(R.drawable.flower_finsh);
            tip_3.setBackgroundResource(R.drawable.flower_no);
        } else if (r >= 3){
            tip_1.setBackgroundResource(R.drawable.flower_finsh);
            tip_2.setBackgroundResource(R.drawable.flower_finsh);
            tip_3.setBackgroundResource(R.drawable.flower_finsh);
        } else {
            tip_1.setBackgroundResource(R.drawable.flower_no);
            tip_2.setBackgroundResource(R.drawable.flower_no);
            tip_3.setBackgroundResource(R.drawable.flower_no);
        }

    }

    ConstraintLayout cl_all;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.w("bbbbbb", " onCreateView");
        if (!isSmallPhone())
            return null;

        View v =  inflater.inflate(R.layout.fragment_learning_word, container, false);

//        cl_all = v.findViewById(R.id.cl_all);
//        cl_all.setVisibility(View.GONE);

        mTextView = v.findViewById(R.id.tv);
        title_text = v.findViewById(R.id.learn_title_text);
        choice_box = v.findViewById(R.id.choice_box);

        loadStatusView = v.findViewById(R.id.load_status_view);

        /*      学习单词界面控件        */
        word_pronunciation = v.findViewById(R.id.word_pronunciation);
        word = v.findViewById(R.id.word);
        word_eng_sentence = v.findViewById(R.id.word_eng_sentence);

        word_eng_sentence.setOnClickListener(this);

        btn_un_control = v.findViewById(R.id.btn_un_control);
        btn_control = v.findViewById(R.id.btn_control);
        btn_next = v.findViewById(R.id.btn_next);
        btn_motify = v.findViewById(R.id.btn_motify);


        btn_un_control.setOnClickListener(this);
        btn_control.setOnClickListener(this);
        btn_next.setOnClickListener(this);
        btn_motify.setOnClickListener(this);

        cl_background = v.findViewById(R.id.cl_background);
        cl_hand = v.findViewById(R.id.cl_hand);
        cl_sound = v.findViewById(R.id.cl_sound);
        cl_scroll_view = v.findViewById(R.id.scroll_view);
        rl_explain = v.findViewById(R.id.rl_explain);

        cl_sound.setOnClickListener(this);
        cl_hand.setOnClickListener(this);
        cl_scroll_view.setOnClickListener(this);
        rl_explain.setOnClickListener(this);

        cl_word_info = v.findViewById(R.id.cl_word_info);
        cl_word_info.setVisibility(View.GONE);

        word_info =v.findViewById(R.id.word_info);
        page_text = v.findViewById(R.id.page_text);
        pre_page = v.findViewById(R.id.pre_page);
        next_page = v.findViewById(R.id.next_page);

        pre_page.setOnClickListener(this);
        next_page.setOnClickListener(this);

        rl_complete = v.findViewById(R.id.rl_complete);
        tip_1 = v.findViewById(R.id.tip_1);
        tip_2 = v.findViewById(R.id.tip_2);
        tip_3 = v.findViewById(R.id.tip_3);

        /*      学习结束界面控件        */
        cl_end_of_round = v.findViewById(R.id.cl_end_of_round);
        cl_end_bottom = v.findViewById(R.id.cl_end_bottom);
        rv_end_img = v.findViewById(R.id.rv_end_img);
        end_img = v.findViewById(R.id.end_img);

        end_congratulations_text = v.findViewById(R.id.end_congratulations_text);
        end_encourage_text = v.findViewById(R.id.end_encourage_text);

        end_go_continue = v.findViewById(R.id.end_go_continue);
        btn_end_again = v.findViewById(R.id.btn_end_again);
        btn_end_change_plan = v.findViewById(R.id.btn_end_change_plan);
        end_view_study_details = v.findViewById(R.id.end_view_study_details);

//        end_go_continue.setOnClickListener(this);
//        btn_end_again.setOnClickListener(this);
//        btn_end_change_plan.setOnClickListener(this);


        v.findViewById(R.id.choice_box).setOnClickListener(view -> {
            if (dialogFragment_choice == null)
                dialogFragment_choice = new Dialog_Fragment_Choice(this);
            dialogFragment_choice.show(getFragmentManager(), "FragmentChoice");

        });

        btn_go_tip = v.findViewById(R.id.btn_go_tip);
        btn_go_tip.setOnClickListener(view -> {
            if (fragment_tip == null)
                fragment_tip = Fragment_Tip.newInstance();
            switchContent(fragment_tip);
        });


        title_text.setOnClickListener(view -> {
            cover += 1;
            if (cover > 4){
                isCover = true;
                cover = 0;
            }
        });

        showLearningView(mContext);


        return v;
    }

    /** 1小机  0大机  */
    public boolean isSmallPhone(){
        return SystemPropertiesInvoke.getInt("persist.sys.is_readboy_y38_ink_pad", 0) == 1 ;
    }

    int cover = 0;
//    @Override
//    protected void initView(View v) {
//        Log.w("bbbbbb", " initView");
//
//
//        /*      文本翻页处理      */
////        textPageFlip(v);
//
//    }

    MainActivity mac ;
    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mac = (MainActivity) context;
        fragmentManager = mac.getSupportFragmentManager();
    }


    /**
     *      修改显示的内容，不会销毁与重建
     *      to 要切换的fragment
     *
     */
    public void switchContent(Fragment to) {
        fragmentTransaction = fragmentManager.beginTransaction();

        if (!to.isAdded()) {
            Log.e(TAG, "setFragment: isAdded");
            /*   隐藏当前的fragment，将 下一个fragment 添加进去     */
            fragmentTransaction.hide(this).add(R.id.switch_fragment, to).commitAllowingStateLoss();
        } else{
            /*   隐藏当前的fragment，显示下一个fragment            */
            Log.e(TAG, "setFragment: isShow");
            fragmentTransaction.hide(this).show(to).commitAllowingStateLoss();
        }
    }


    /**
     *      获取书本内容
     *      下载文件，并解压zip
     *
     */
    List<BookDetails> bookDetails = new ArrayList<>();
    BookData bookData;
    private class unitAsyncTask extends AsyncTask<Integer, Void, Void> {
        @Override
        protected Void doInBackground(Integer... integers) {
            Log.w(TAG, "doInBackground: " + cl_background.getVisibility() );
            AuthHelper.newAuth(mContext);
            HttpUtil.setAuth(mContext);
            bookDetails.clear();
            bookDetails.addAll(LitePal.where("bid = ?", String.valueOf(bid)).find(BookDetails.class));
            Log.d(TAG, "doInBackground: " + bookDetails.size());
            if (bookDetails.size() == 0){
                bookData = HttpUtil.requestBookData(grade);
                if (bookData != null &&  bookData.getData()!= null){
                    bookDetails = bookData.getData().getBooks();
                    for (BookDetails details : bookDetails){
                        if (details.getWordPackage() != null){
                            details.setCover(details.getCover());
                            String bName = details.getName();
                            if (bName.length() > 2)
                                bName = bName.substring(2);
                            details.setGradeName(bName);
                            details.setName(details.getEdition().getName());
                            details.setGrade(details.getGrade());
                            details.setBid(details.getBid());
                            details.setPackageUri(details.getPackageUri());
                            details.setWordPackageUri(details.getWordPackage().getPackageUri());
                            details.save();
                        }
                    }
                } else{
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);
                }
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            String path = null;
            if (bookDetails.size() != 0){
                for (BookDetails details : bookDetails){
                    if (details.getBid() == bid){
                        Log.d(TAG, "onPostExecute: path  " + path);
                        path = details.getWordPackageUri();
                        updateTime = details.getUpdateTime();
                        break;
                    }
                }

                for (BookDetails details : bookDetails) {
                    if (path == null && details.getWordPackageUri() != null) {
                        path = details.getWordPackageUri();
                        bid = details.getBid();
                        updateTime = details.getUpdateTime();
                        break;
                    }
                }

                sharePreference.putLong("updateTime",  updateTime);
                Log.i(TAG, "onPostExecute: path  " + path);
                String finalPath = path;
                startDownloadThread(Config.ADDRESS_RESOURCE + finalPath, uid, bid, true);

            }
        }

    }

    /*      开启线程下载解压包，并解压到本地目录下             */
    private void startDownloadThread(String path, long threadUid, long threadBid, boolean isEnd){
        Thread thread = new Thread(){
            @Override
            public void run(){
                Looper.prepare();
                String result = null;
                try {
                    result = HttpDownloader.download(path, threadUid, threadBid);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Log.d(TAG, "run: result " + result);
                if (result != null){
                    String regEx="[^0-9]";
                    Pattern p = Pattern.compile(regEx);
                    Matcher m = p.matcher(result);
                    String bid =  m.replaceAll("").trim();
                    try {
                        FileInputStream mFileInStream = null;
                        File mFile = new File(result);
                        byte[] s = new byte[1024];
                        if (mFile.exists()) {
                            mFileInStream = new FileInputStream(mFile);
                            s = HttpDownloader.bookReadBuffer(mFileInStream, true);
                        }
                        HttpDownloader.bytesToFile(mContext, s, threadUid , threadBid, isEnd);
                        if (mFile.exists())
                            mFile.delete();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else
                    hideDownloading(true);
                Looper.loop();
            }
        };
        thread.start();
    }

    /**
     *      处理完成后给handler发送消息
     */
    public void hideDownloading(boolean isEnd){
        Message msg = new Message();
        if (isEnd){
            msg.what = 0;
            handler.sendMessage(msg);
        }

    }

    UnitData unitData2;

    List<Integer> unitIdList2 = new ArrayList<>();
    List<String> unitNameList2 = new ArrayList<>();
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0) {
                if (goData){
                    goData = false;
                    requestWordRecords();
                }
                loadStatusView.setHide();
                String fileString =  HttpDownloader.readFileData(Config.rewordsPath + uid + "/" + bid +"/"  + "book.json");

                Gson gson = new Gson();
                unitData2 = gson.fromJson(fileString, UnitData.class);
                if (unitData2 != null && unitData2.getChildren() != null && unitData2.getChildren().size() != 0){
                    Config.getUnitIdList().clear();
                    Config.getUnitNameList().clear();
                    unitIdList2.clear();
                    for (Children children : unitData2.getChildren()){
                        if (children.getChildren() != null){
                            //二级目录处理
                            for (Children2 children2 : children.getChildren())
                                //将章节id和章节名保存
                                if (children2.getWord() != null)
                                    Config.getUnitIdList().add(children2.getId());

                            sharePreference.putIntList("unitIdList", Config.getUnitIdList());
                            Log.d("ModuleUnitAdapter", "init: " + Config.getUnitIdList().size());
                        } else {
                            //将章节id和章节名保存
                            if (children.getWord() != null)
                                unitIdList2.add(children.getId());
                        }
                    }
                    Log.d(TAG, "handleMessage:   " + unitIdList2.size());
                    if (unitIdList2.size() != 0){
                        sharePreference.putIntList("unitIdList", unitIdList2);
                        sharePreference.putStringList("unitNameList", unitNameList2);
                    }
                }
                //书本单元数据，转成string便于传输
                unitInfo =  ObjectChangeString.objectToString(unitData2);
                sharePreference.putString("unitDataString", unitInfo);
                sharePreference.commit();
                initData(unitData2, 0);
            } else if (msg.what == 1)
                loadStatusView.setError();
        }
    };

//    @Override
//    protected int getLayoutRes() {
//        return R.layout.fragment_learning_word;
//    }
//
//    @Override
//    protected void loadData() {
//        Log.w("bbbbbb", " loadData");
//    }

    String sn, device_id, t;
    String appsec = "5c9fb24e1130826cb712faa40021f08a";
    String host = "http://192.168.20.94:8210/api";

    /*          上传单词学习记录            */
    private void uploadWordRecords(List<DetailWords> list){
        Log.e(TAG, "uploadWordRecords start: " + list.size());
        JSONArray data = new JSONArray();
        int minNumber = Math.min(list.size(), 100);
        HashSet<Integer> bookList = new HashSet<>();
        for (int i = 0; i < minNumber ; i++){
            JSONObject obj = new JSONObject();
            try {
                obj.put("userId", uid);
                obj.put("lastBookId", list.get(i).getBookId());
                bookList.add(list.get(i).getBookId());
                obj.put("word", list.get(i).getWord());
                obj.put("learnCount", list.get(i).getLearnTime());
                obj.put("appearCount", list.get(i).getAppear());
                obj.put("isNewWord", list.get(i).getIsNewWord());
                obj.put("isWrongClick", list.get(i).getWrongClick());
                data.put(obj);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        setAuth(mContext, uid);

        String address = host + "/v1/wordRecords/upload?uid=" + uid + "&sn=" + sn;
        Log.i(TAG, "upload   WordRecords: " + address);
        HttpUtil.sendHttpPOSTRequest(address, data, new HttpUtil.HttpCallbackListener() {
            @Override
            public void onFinish(String response) {
                Log.e(TAG, "upload   WordRecords onFinish: " + response);
                list.subList(0, minNumber).clear();
                if (list.size() <= 0){
                    sharePreference.putString("obj", ObjectChangeString.objectToString(list));
                    sharePreference.commit();
                } else
                    uploadWordRecords(list);
                uploadBookRecords(bookList);
            }

            @Override
            public void onError(Exception e) {
                Log.w(TAG, "uploadWordRecords onError: " + e);
            }
        });

    }


    /*          上传课本学习记录            */
    private void uploadBookRecords(HashSet<Integer> bookList){
//        List<Integer> b = new ArrayList<>();
//        b.add(123);
//        b.add(456);
//
//        String data;
//        String[] key = {"userId", "bookIds"};
//        data = "{" + "\"" + key[0] + "\"" + ":" + uid + "," +
//                "\"" + key[1] + "\"" + ":" + b + "}";
//
//        Log.e(TAG, "uploadBookRecords:   obj:" + data  );
//        bookList = new ArrayList<>();
//        bookList.add(3605167);
//        bookList.add(190167);
        JSONArray b = new JSONArray();
        for (int i : bookList)
            b.put(i);

        JSONObject obj = new JSONObject();
        try {
            obj.put("userId", uid);
            obj.put("bookIds", b);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        Log.e(TAG, "upload  BookRecords:   obj:" + obj );
        setAuth(mContext, uid);
        String address = host + "/v1/bookRecord/upload?uid=" + uid + "&sn=" + sn;

        Log.i(TAG, "uploadBookRecords: " + address);
        HttpUtil.sendHttpPOSTRequest(address, obj, new HttpUtil.HttpCallbackListener() {
            @Override
            public void onFinish(String response) {
                Log.w(TAG, "upload  BookRecords onFinish: " + response);
            }

            @Override
            public void onError(Exception e) {
                Log.w(TAG, "uploadBookRecords onError: " + e);
            }
        });
    }


    /*          获取单词学习记录            */
    public void requestWordRecords(){
        for (int netBid : netRecordBookIds){
            String fileString =  HttpDownloader.readFileData(Config.rewordsPath + uid + "/" + netBid +"/" + "words.json");
            Log.w("bbbbbbb", "saveWordData: bookId: " + bookId );
            Gson gson = new Gson();
            List<AllWords> words= gson.fromJson(fileString, new TypeToken<List<AllWords>>() {}.getType());

            Log.w("bbbbbbb", "onFinish words.size():  " + words.size());
            allWordsDao.insertAll(words);
            Log.e("bbbbbbb", "onFinish dao.getAl.size():  " + allWordsDao.getAll().size());
        }



        setAuth(mContext, uid);
        String address = host + "/v1/wordRecords?uid=" + uid + "&sn="+sn;
        Log.e(TAG, "request WordRecords:  " + address);
        HttpUtil.sendHttpGETRequest(address, new HttpUtil.HttpCallbackListener() {
            @Override
            public void onFinish(String response) {
                try {
                    Log.w(TAG, "request WordRecords onFinish: " + response);
                    Log.v(TAG, "onFinish  allWordsDao.getAll   : " + allWordsDao.getAll().size());
                    JSONArray data = new JSONObject(response).getJSONArray("data");
                    Log.i(TAG, "onFinish data.length : " + data.length());
                    for (int i = 0; i < data.length(); i++){
                        String word = data.getJSONObject(i).getString("word");
                        AllWords allWords = allWordsDao.getData(word);
                        if (allWords != null){
                            DetailWords d = new DetailWords();
                            d.setWord(word);
                            d.setSync_explain(allWords.getSync_explain());
                            d.setExplain(allWords.getExplain());
                            d.setUk_bs(allWords.getUk_bs());
                            d.setUk_word_sound(allWords.getUk_word_sound());
                            d.setUs_bs(allWords.getUs_bs());
                            d.setUs_word_sound(allWords.getUs_word_sound());
                            d.setSentence(allWords.getSentence());
                            d.setSentence_explain(allWords.getSentence_explain());

                            if (allWords.getCommon_phrases() != null && allWords.getCommon_phrases().size() != 0){
                                if (allWords.getCommon_phrases().get(0).getContent().size() == 1) {
                                    d.setWord_parse(allWords.getCommon_phrases().get(0).getContent().get(0).getText());
                                    d.setWord_parse_explain(allWords.getCommon_phrases().get(0).getContent().get(0).getParaphrase());
                                } else {
                                    d.setWord_parse(allWords.getCommon_phrases().get(0).getContent().get(0).getText());
                                    d.setWord_parse_explain(allWords.getCommon_phrases().get(0).getContent().get(0).getParaphrase());
                                    d.setWord_parse2(allWords.getCommon_phrases().get(0).getContent().get(1).getText());
                                    d.setWord_parse_explain2(allWords.getCommon_phrases().get(0).getContent().get(1).getParaphrase());
                                }
                            }

                            d.setUid(uid);
                            d.setBookId(data.getJSONObject(i).getInt("lastBookId"));
                            d.setIsFromNet(1);
                            d.setLearnTime(data.getJSONObject(i).getInt("learnCount"));
                            d.setAppear(data.getJSONObject(i).getInt("appearCount"));
                            d.setIsNewWord(data.getJSONObject(i).getInt("isNewWord"));
                            d.setWrongClick(data.getJSONObject(i).getInt("isWrongClick"));

                            if (recoverWordDao.getUserOne(word, uid) == null)
                                recoverWordDao.insert(d);
//                            else{
//                                Log.e(TAG, "onFinish updateData : " + word);
//                                wordsDao.updateData(d);
//                                Log.i(TAG, "onFinish: " + wordsDao.getOne(word).getAppear());
//                            }
                        }
                    }
                } catch (Exception e){
                    Log.e(TAG, "request WordRecords onFinish:Exception  " + e);
                }
            }

            @Override
            public void onError(Exception e) {
                Log.w(TAG, "request WordRecords onError: " + e.getMessage());
            }
        });
    }

    /*          获取课本学习记录            */
    public void requestBookRecords(int userId, Context context){
        uid = userId;
        mContext = context;
//        setAuth(mContext, uid);
        String address = host + "/v1/bookRecord?uid=" + userId;
        if (IsNetWorkConnected.isNetworkConnected(context))
            new BookRecordAsyncTask().execute(address);
        HashSet<Integer> netBookIds = new HashSet<>();
//        HttpUtil.sendHttpGETRequest(address, new HttpUtil.HttpCallbackListener() {
//            @Override
//            public void onFinish(String response) {
//                Log.w(TAG, "request BookRecords onFinish: "  + response);
//                try{
//
//                    JSONObject data = new JSONObject(response).getJSONObject("data");
//                    JSONArray bookIds = data.getJSONArray("bookIds");
//
//                    if (bookIds.length() > 0){
//                        Looper.prepare();
//                        if (dialog == null){
//                            if (loadStatusView == null)
//                                loadStatusView = new LoadStatusView(mContext);
//                            loadStatusView.setLoading();
//
//                            dialog = new AlertDialog.Builder(mContext);
//                            dialog.setTitle("温馨提示");
//                            dialog.setMessage("是否同步您的云端\n" + "学习记录到本机器？");
//                            dialog.setCancelable(true);
//                            dialog.setNegativeButton("不同步", null);
//                            dialog.setPositiveButton("同步", (dialog, which) -> {
//
//                                try {
//                                    for (int i = 0; i < bookIds.length(); i++)
//                                        netBookIds.add(bookIds.getInt(i));
//                                } catch (JSONException e) {
//                                    Log.e(TAG, "request BookRecords dialogShow onFinish:Exception  " + e);
//                                    e.printStackTrace();
//                                }
//
//                                requestWordRecords();
//                                requestBookInfo(netBookIds);
//                            });
//                        }
//                        dialog.show();
//                        Looper.loop();
//                    }
//
//                    Log.i(TAG, "request BookRecords: " + bookIds + "    " + netBookIds);
//
//                } catch (Exception e){
//                    Log.e(TAG, "request BookRecords onFinish:Exception  " + e);
//                }
//            }
//
//            @Override
//            public void onError(Exception e) {
//                Log.w(TAG, "request BookRecords onError: " + e.getMessage());
//            }
//        });

    }

    AlertDialog.Builder dialog = null;
    BookReacordsData reacordsData;
    List<Integer> recordBookIds = new ArrayList<>();
    HashSet<Integer> netRecordBookIds = new HashSet<>();
    Boolean goData = false;
    /*          网络请求获取课本学习记录            */
    private class BookRecordAsyncTask extends AsyncTask<String, Void, Void>{

        @Override
        protected Void doInBackground(String... address) {
            reacordsData = HttpUtil.requestBookReacordsData(address[0]);
            if (reacordsData != null)
                recordBookIds = reacordsData.getData().getBookIds();
            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            if (recordBookIds != null && recordBookIds.size() > 0){
                if (dialog == null){
                    dialog = new AlertDialog.Builder(mContext);
                    dialog.setTitle("温馨提示");
                    dialog.setMessage("是否同步您的云端\n" + "学习记录到本机器？");
                    dialog.setCancelable(true);
                    dialog.setNegativeButton("不同步", null);
                    dialog.setPositiveButton("同步", (dialog, which) -> {
                        goData = true;
                        Config.words = null;
                        cl_background.setVisibility(View.GONE);
                        loadStatusView.setLoading();
                        netRecordBookIds.clear();
                        netRecordBookIds.addAll(recordBookIds);
                        requestBookInfo(netRecordBookIds);
                    });
                }
                dialog.show();
            } else {
                cl_background.setVisibility(View.GONE);
                loadStatusView.setLoading();
                Config.words = null;
                netRecordBookIds.clear();
                netRecordBookIds.add(9803167);
                requestBookInfo(netRecordBookIds);
            }

        }
    }

    long updateTime;
    /*          获取课本信息并解压到本地                 */
    private void requestBookInfo(HashSet<Integer> BIDS){
        newWordsDao.deleteAll();
        String bookIds = String.valueOf(BIDS);
        if (bookIds.contains("["))
            bookIds = bookIds.replace("[", "");

        if (bookIds.contains("]"))
            bookIds =bookIds.replace("]", "");

        if (bookIds.contains(" "))
            bookIds =bookIds.replace(" ", "");

        boolean isHave = false;
        if (bookIds.contains(String.valueOf(bid)))
            isHave = true;


        setAuth(mContext, uid);
        String address = host + "/v1/packages?uid=" + uid + "&bookIds=" + bookIds + "&sn="+ sn;
        Log.e(TAG, "requestBookRecords:requestBookInfo  " + address);

        boolean finalIsHave = isHave;
        HttpUtil.sendHttpGETRequest(address, new HttpUtil.HttpCallbackListener() {
            @Override
            public void onFinish(String response) {
                try{
                    Gson gson = new Gson();
                    CheckBookData bookData = gson.fromJson(response, CheckBookData.class);
                    if (bookData != null && bookData.getData().size() != 0)
                        for (int bookId : BIDS)
                            for (int i = 0; i < bookData.getData().size(); i++)
                                if (bookId == bookData.getData().get(i).getId()){
                                    startDownloadThread(Config.ADDRESS_RESOURCE + bookData.getData().get(i).getWordPackage().getPackageUri(), uid, bookId, i == bookData.getData().size() - 1);
                                    if (!finalIsHave){
                                        bid = bookId;
                                        sharePreference.putLong("updateTime", bookData.getData().get(i).getWordPackage().getUpdateTime());
                                    }
                                }
//                            for (CheckBookData.BookInfoData netBook : bookData.getData()){
//                                if (bookId == netBook.getId()) {
//                                    startDownloadThread(Config.ADDRESS_RESOURCE + netBook.getWordPackage().getPackageUri(), uid, bookId);
//                                }
//                            }
                    sharePreference.putLong("uid",  uid);
                    sharePreference.putInt("bookId", bid);
                    sharePreference.commit();

                } catch(Exception e){
                    Log.e(TAG, "requestWordRecords requestBookInfo onFinish:Exception  " + e);
                }

            }

            @Override
            public void onError(Exception e) {
                Log.e(TAG, "requestBookInfo requestBookInfo onError:Exception  " + e);
            }
        });

    }


    //签名参数
    public void setAuth(Context context, long uid) {
        try {
            Properties properties = Auth.getInstance(context).getSignature();
            device_id = URLEncoder.encode(properties.getProperty("device_id"), "utf-8");
            t = properties.getProperty("t");
            sn = uid + t + HttpUtil.getMD5String(t + appsec +  HttpUtil.getMD5String(String.valueOf(uid)));
            Log.d(TAG, "setAuth: " + sn + "  " + device_id + "  " + t);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (networkReceiverHelper != null){
            networkReceiverHelper.unregister();
        }
    }
}
