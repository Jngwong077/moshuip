package com.readboy.simpleLauncher.rewords.complete;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.TextView;

import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.data.ObjectChangeString;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;
import com.readboy.simpleLauncher.rewords.tool.Config;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class CompleteActivity extends AppCompatActivity {

    RecyclerView rv_word_list;
    ArrayList<DetailWords> detailWords = new ArrayList<>();
    TextView complete_time_text, new_word, re_word;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //全透明实现
        Config.FLAG_TRANSLUCENT_STATUS(getWindow());
        if (Config.TEMPORARY_WORD.size() != 0)
            Config.TEMPORARY_WORD.clear();
        Config.UN_CONTROL_NUMBER = 0;

        setContentView(R.layout.activity_rewords_complete);
        String object = getIntent().getStringExtra("detailWords");
        detailWords = ObjectChangeString.stringToDetailWords(object);
        int new_learn_count = 0;
        for (DetailWords d : detailWords) {
            Log.i("pppppppppp", "onCreate: "
                    + "\n" + "word: " + d.getWord()
                    + "\n" + "learnTime: "+ d.getLearnTime()
                    + "\n" + "wrongClick: "+ d.getWrongClick()
                    + "\n" + "appear: "+ d.getAppear()
                    + "\n" + "PathSound: "+ d.getPathSound()
            );

            if ((d.getLearnTime() == 7 && d.getWrongClick() == 1) || d.getLearnTime() == 1)
                new_learn_count++;
        }


        new_word = findViewById(R.id.complete_new_word);
        re_word = findViewById(R.id.complete_re_word);

        new_word.setText("新学" + new_learn_count);


        int recover_count = Math.max(detailWords.size() - new_learn_count, 0);
        re_word.setText("复习" + recover_count);


        complete_time_text = findViewById(R.id.complete_time_text);

        @SuppressLint("SimpleDateFormat") SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String time = sf.format(new Date());
        if (time.contains("-"))
            time = time.replaceAll("-", "/");
        complete_time_text.setText(time);


        rv_word_list = findViewById(R.id.rv_word_list);
        LinearLayoutManager manager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        CompleteWordsAdapter completeWordsAdapter = new CompleteWordsAdapter(CompleteActivity.this, detailWords);

        rv_word_list.setAdapter(completeWordsAdapter);
        rv_word_list.setLayoutManager(manager);


        findViewById(R.id.complete_back_text).setOnClickListener(v -> {
            finish();
        });

    }

}