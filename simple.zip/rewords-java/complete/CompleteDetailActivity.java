package com.readboy.simpleLauncher.rewords.complete;

import android.annotation.SuppressLint;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.TextView;

import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.data.ObjectChangeString;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;
import com.readboy.simpleLauncher.rewords.tool.Pagination;
import com.readboy.simpleLauncher.rewords.tool.PlayWordSound;

public class CompleteDetailActivity extends AppCompatActivity {
    String TAG = "CompleteDetailActivity";
    ConstraintLayout cp_sound;
    TextView cp_word, cp_word_pronunciation, cp_word_info, cp_page_text, cp_back_text;

    DetailWords words;

    private Pagination mPagination;
    private CharSequence mText;

    private int mCurrentIndex = 0;          /*      单词释义页码      */


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complete_detail);
        String object = getIntent().getStringExtra("words");
        words = ObjectChangeString.stringToWords(object);

        cp_word_info = findViewById(R.id.cp_word_info);
        cp_word_info.setMaxLines(18);
        cp_page_text = findViewById(R.id.cp_page_text);

        cp_word = findViewById(R.id.cp_word);
        cp_word.setText("" + words.getWord());

        cp_word_pronunciation = findViewById(R.id.cp_word_pronunciation);
        cp_word_pronunciation.setText("" + words.getUk_bs());


        cp_sound = findViewById(R.id.cp_sound);
        cp_sound.setOnClickListener(v -> {
            PlayWordSound.setMediaPlayer(words.getPathSound());
        });


        findViewById(R.id.cp_pre_page).setOnClickListener(v -> {
            Log.w(TAG, "textPageFlip: " + mCurrentIndex  + mPagination.size());
            mCurrentIndex = (mCurrentIndex > 0) ? mCurrentIndex - 1 : 0;
            if (mCurrentIndex == 0){
                cp_word_info.setMaxLines(18);
                cp_sound.setVisibility(View.VISIBLE);
            }
            update();
        });

        findViewById(R.id.cp_next_page).setOnClickListener(v -> {
            cp_word_info.setMaxLines(30);
            Log.w(TAG, "textPageFlip: " + mCurrentIndex  + mPagination.size());
            if (mPagination.size() != 1)
                cp_sound.setVisibility(View.GONE);
            mCurrentIndex = (mCurrentIndex < mPagination.size() - 1) ? mCurrentIndex + 1 : mPagination.size() - 1;
            update();
        });

        findViewById(R.id.cp_back_text).setOnClickListener(v -> {
            finish();
        });


        String wordInfo;
        wordInfo = "释义：" + "\n";
        wordInfo += words.getExplain() + "\n";
        wordInfo += "释义：" + "\n";
        wordInfo += words.getExplain() + "\n";
        wordInfo += "释义：" + "\n";
        wordInfo += words.getExplain() + "\n";
        wordInfo += "释义：" + "\n";
        wordInfo += words.getExplain() + "\n";
        wordInfo += "释义：" + "\n";
        wordInfo += words.getExplain() + "\n";
        wordInfo += "释义：" + "\n";
        wordInfo += words.getExplain() + "\n";
        wordInfo += "\n" + "例句：" + "\n";
        wordInfo += words.getSentence() + "\n";
        wordInfo += words.getSentence_explain() + "\n";

        mText = Pagination.textProcess(wordInfo);
//        cp_word_info.setText(wordInfo);
        cp_word_info.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                // Removing layout listener to avoid multiple calls
                cp_word_info.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                mPagination = new Pagination(
                        mText, cp_word_info.getWidth(),
                        cp_word_info.getHeight(),
                        cp_word_info.getPaint(),
                        cp_word_info.getLineSpacingMultiplier(),
                        cp_word_info.getLineSpacingExtra(),
                        cp_word_info.getIncludeFontPadding());
                update();
            }
        });

    }

    @SuppressLint("SetTextI18n")
    private void update() {
        final CharSequence text = mPagination.get(mCurrentIndex);
        cp_page_text.setText((mCurrentIndex + 1) + "/" + mPagination.size());
        if (text != null) cp_word_info.setText(text);
    }

}