package com.readboy.simpleLauncher.rewords.complete;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.data.ObjectChangeString;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;
import com.readboy.simpleLauncher.rewords.tool.CircleProgressBar;
import com.readboy.simpleLauncher.rewords.tool.PlayWordSound;

import java.util.ArrayList;

/**
 * Created by hjy on 2022/4/4 15:13
 */
public class CompleteWordsAdapter extends RecyclerView.Adapter<CompleteWordsAdapter.MyHolder> {
    Context context;
    ArrayList<DetailWords> detailWords = new ArrayList<>();

    public CompleteWordsAdapter(Context context, ArrayList<DetailWords> detailWords){
        this.context = context;
        this.detailWords.addAll(detailWords);
    }


    @NonNull
    @Override
    public CompleteWordsAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View inflater = LayoutInflater.from(context).inflate(R.layout.item_rewords_complete, viewGroup, false);
        return new MyHolder(inflater);

    }

    @Override
    public void onBindViewHolder(@NonNull CompleteWordsAdapter.MyHolder myHolder, int i) {
        myHolder.initView(i);
    }

    @Override
    public int getItemCount() {
        return detailWords == null ? 0 : detailWords.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder{
        TextView item_word, item_word_explain;
        CircleProgressBar progressBar;
        RelativeLayout rl_sound;
        public MyHolder(@NonNull View v) {
            super(v);
            item_word = v.findViewById(R.id.item_word);
            item_word_explain = v.findViewById(R.id.item_word_explain);
            progressBar = v.findViewById(R.id.complete_img);
            rl_sound = v.findViewById(R.id.rl_sound);
        }

        public void initView(int p){
            item_word.setText(detailWords.get(p).getWord());
            item_word_explain.setText(detailWords.get(p).getExplain());

//            itemView.findViewById(R.id.img_play).setOnClickListener(v -> {
//
//            });

            itemView.setOnClickListener(v -> {
                Intent intent = new Intent();
                intent.setClass(context, CompleteDetailActivity.class);
                intent.putExtra("words", ObjectChangeString.objectToString(detailWords.get(p)));
                context.startActivity(intent);
            });

            rl_sound.setOnClickListener(v -> PlayWordSound.setMediaPlayer(detailWords.get(p).getPathSound()));

            Log.e("CompleteWordsAdapter", "getLearnTime: " + detailWords.get(p).getLearnTime() + "    getWrongClick：" + detailWords.get(p).getWrongClick());
            if (detailWords.get(p).getWrongClick() == 1 && detailWords.get(p).getLearnTime() == 7){
                progressBar.update(180);
            } else {
                int percentage = (detailWords.get(p).getLearnTime() * 45) ;  // 45 = 360 / 8
                Log.i("CompleteWordsAdapter", "initView: " + percentage);
                progressBar.update(percentage);
            }
        }


    }


}
