package com.readboy.simpleLauncher.rewords.setting;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.core.sp.SharedPreferencesManager;
import com.readboy.simpleLauncher.MainActivity;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.data.detail_word.DBInstance;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWordsDao;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.GetUserInfo;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;

import java.text.DecimalFormat;
import java.util.Random;

/**
 * 弹窗辅助类
 *
 * @ClassName WindowUtils
 */
public class WindowUtils {
    private static final String LOG_TAG = "WindowUtils";
    private static View mView = null;
    private static WindowManager mWindowManager = null;
    private static Context mContext = null;
    public static Boolean isShown = false;

    /**
     * 显示弹出框
     *
     * @param context
     */
    @SuppressLint("ClickableViewAccessibility")
    public static void showPopupWindow(final Context context) {

        if (isShown) {
            Log.i(LOG_TAG, "return cause already shown");
            return;
        }
        isShown = true;
        // 获取应用的Context
        mContext = context.getApplicationContext();
        Log.i(LOG_TAG, "showPopupWindow" + mContext);

        acquireWakeLock(context);
        // 获取WindowManager
        mWindowManager = (WindowManager) mContext
                .getSystemService(Context.WINDOW_SERVICE);


        mView = setUpView(mContext);



        final WindowManager.LayoutParams params = new WindowManager.LayoutParams();
        //关键
        params.type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY   //8.0新特性
                                                                        : WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;

        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                | WindowManager.LayoutParams.FLAG_SECURE | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED;

        mView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_OUTSIDE)
                hidePopupWindow();
            return false;
        });
        // 不设置这个弹出框的透明遮罩显示为黑色
        params.format = PixelFormat.TRANSPARENT;
        params.width = 650;
        params.height = WindowManager.LayoutParams.WRAP_CONTENT;
        params.gravity = Gravity.CENTER;
        mWindowManager.addView(mView, params);
        Log.i(LOG_TAG, "add view");
    }

    /**
     * 隐藏弹出框
     */
    public static void hidePopupWindow() {
        Log.i(LOG_TAG, "hide " + isShown + ", " + mView);
        releaseWakeLock();
        if (isShown && null != mView && mWindowManager != null) {
            Log.i(LOG_TAG, "hidePopupWindow");
            mWindowManager.removeView(mView);
            isShown = false;
        }
    }

    @SuppressLint("SetTextI18n")
    private static View setUpView(final Context context) {
        Log.i(LOG_TAG, "setUp view");
        View view = LayoutInflater.from(context).inflate(R.layout.dialog_remind, null);
        SettingSharePreference sharePreference = new SettingSharePreference(context);

        view.findViewById(R.id.go_to_rewords).setOnClickListener(v -> {
            hidePopupWindow();
        });

        int uid, bookId;
        DetailWordsDao wordsDao = DBInstance.initDb(context).detailWordsDao();
        uid = GetUserInfo.getUserBaseInfo(context) != null ? GetUserInfo.getUserBaseInfo(context).uid : 111111;

        bookId =  sharePreference.getInt("bookId", 142167);
        int haveLearn = wordsDao.getHaveLearnWord(uid, bookId).size();
        int wordCount = sharePreference.getInt("wordCound", 100);
        double progress = ((double)haveLearn / wordCount) * 100;
        Log.w("TAG", "Fragment_Select_Unit: " + new DecimalFormat("0").format(progress));

        TextView remind_learn_plan = view.findViewById(R.id.remind_learn_plan);
        remind_learn_plan.setText(new DecimalFormat("0").format(progress) + "%  " +
                "(" + "已学" +haveLearn + " / 总共" + wordCount + ")");


        TextView remind_book = view.findViewById(R.id.remind_book);
        String bookName =  sharePreference.getString("bookName", "").equals("") ? "人教PEP三年级上册" : sharePreference.getString("bookName", "");
        remind_book.setText(bookName);


        Random ra = new Random();
        int random = ra.nextInt(Config.remind_text_eng.length);
        Log.v("TAG", "setUpView: " + random );
        TextView remind_sen_eng = view.findViewById(R.id.remind_sen_eng);
        remind_sen_eng.setText(Config.remind_text_eng[random]);

        TextView remind_sen_chs = view.findViewById(R.id.remind_sen_chs);
        remind_sen_chs.setText(Config.remind_text_chs[random]);

        return view;
    }


    static PowerManager.WakeLock mWakelock;
    /**
     * 唤醒屏幕
     */
    private static void acquireWakeLock(Context context) {
        Log.d("SettingActivity", "acquireWakeLock: " + context);

        if (mWakelock == null) {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            mWakelock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP
                    | PowerManager.SCREEN_DIM_WAKE_LOCK, context.getClass().getCanonicalName());
        }

        mWakelock.acquire();
    }

    /**
     * 释放锁屏
     */
    private static void releaseWakeLock() {
        if (mWakelock != null && mWakelock.isHeld()) {
            mWakelock.release();
            mWakelock = null;
        }
    }
}