package com.readboy.simpleLauncher.rewords.setting;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jng wong
 * on 2022/9/6 15:09
 */
public class SettingRepeatAdapter extends RecyclerView.Adapter<SettingRepeatAdapter.ViewHolder>{
    private String TAG = " SettingRepeatAdapter";
    private final String[] days = {"日", "一", "二", "三", "四", "五", "六"};

    private List<Boolean> repeatChooseList;
    SettingSharePreference sharePreference;
    Gson gson = new Gson();

    public SettingRepeatAdapter(SettingSharePreference sharePreference) {
        this.sharePreference = sharePreference;
        repeatChooseList = gson.fromJson(sharePreference.getString("repeatChooseList", ""), new TypeToken<List<Boolean>>(){}.getType());
        if (repeatChooseList == null){
            repeatChooseList = new ArrayList<>();
            for (int i = 0; i < 7; i++)
                repeatChooseList.add(i, false);
        }
        Log.w(TAG, "onBindViewHolder: " + repeatChooseList  );

    }

    @NonNull
    @Override
    public SettingRepeatAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_setting_repeat, viewGroup, false);
        return  new SettingRepeatAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SettingRepeatAdapter.ViewHolder viewHolder, int i) {
        viewHolder.t1.setText(days[i]);
        viewHolder.t2.setText(days[i]);
        viewHolder.onClick(i);
    }

    @Override
    public int getItemCount() {
        return 7;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView t1, t2;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            t1 = itemView.findViewById(R.id.day);
            t2 = itemView.findViewById(R.id.day2);
        }

        private void onClick(int i){
            showBackground(i);

            itemView.setOnClickListener(v -> {
                if (repeatChooseList.get(i)){
                    repeatChooseList.set(i, false);
                } else
                    repeatChooseList.set(i, true);
                sharePreference.putString("repeatChooseList", gson.toJson(repeatChooseList));
                sharePreference.commit();
                showBackground(i);
            });
        }

        @SuppressLint("ResourceAsColor")
        private void showBackground(int i){
            if (repeatChooseList.get(i)){
                t1.setVisibility(View.GONE);
                t2.setVisibility(View.VISIBLE);
                t2.setHintTextColor(R.color.white);
                t2.setBackgroundResource(R.drawable.item_day_bg_2);
            } else {
                t1.setVisibility(View.VISIBLE);
                t2.setVisibility(View.GONE);
                t1.setHintTextColor(R.color.black);
                t1.setBackgroundResource(R.drawable.item_day_bg);
            }

        }
    }





}
