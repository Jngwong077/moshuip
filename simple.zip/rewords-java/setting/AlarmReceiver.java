package com.readboy.simpleLauncher.rewords.setting;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.readboy.simpleLauncher.MainActivity;
import com.readboy.simpleLauncher.rewords.RewordsActivity;
import com.readboy.simpleLauncher.rewords.selectBookAndUnit.SelectBookActivity;

/**
 * Created by jng wong
 * on 2022/9/7 13:37
 */
public class AlarmReceiver extends BroadcastReceiver {
    Context mContext = null;
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i("SettingActivity", "scheduleAlarm: qweeeeeeeeeeeeeee" + context + "     " + MainActivity.getInstance());

        WindowUtils.showPopupWindow(context);
    }




}
