package com.readboy.simpleLauncher.rewords.setting;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.arch.persistence.room.Room;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.data.detail_word.DBInstance;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AppDatabase;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWordsDao;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.GetUserInfo;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;

import java.text.DecimalFormat;
import java.util.Random;

/**
 * Created by jng wong
 * on 2022/9/7 16:38
 */
public class RemindFragment extends DialogFragment {

    private AlertDialog dialog;
    TextView remind_learn_plan, remind_book, remind_sen_eng, remind_sen_chs;
    Button go_to_rewords;
    int uid, bookId;

    @SuppressLint("SetTextI18n")
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        final View view = LayoutInflater.from(requireActivity()).inflate(R.layout.dialog_remind, null);
        SettingSharePreference sharePreference = new SettingSharePreference(requireActivity());


        DetailWordsDao wordsDao = DBInstance.initDb(requireActivity()).detailWordsDao();
        if (GetUserInfo.getUserBaseInfo(getContext()) != null) {
            uid = GetUserInfo.getUserBaseInfo(getContext()).uid;
        }else
            uid = 111111;
        bookId =  sharePreference.getInt("bookId", 142167);
        int haveLearn = wordsDao.getHaveLearnWord(uid, bookId).size();
        int wordCount = sharePreference.getInt("wordCound", 100);
        double progress = ((double)haveLearn / wordCount) * 100;
        Log.w("TAG", "Fragment_Select_Unit: " + new DecimalFormat("0").format(progress));

        remind_learn_plan = view.findViewById(R.id.remind_learn_plan);
        remind_learn_plan.setText(new DecimalFormat("0").format(progress) + "%  " +
                "(" + "已学" +haveLearn + "/总共" + wordCount + ")");





        String bookName =  sharePreference.getString("bookName", "").equals("") ? "人教PEP三年级上册" : sharePreference.getString("bookName", "");
        remind_book = view.findViewById(R.id.remind_book);
        remind_book.setText(bookName);


        Random ra = new Random();
        int random = ra.nextInt(Config.remind_text_eng.length);
        remind_sen_eng = view.findViewById(R.id.remind_sen_eng);
        remind_sen_chs = view.findViewById(R.id.remind_sen_chs);
        remind_sen_eng.setText(Config.remind_text_eng[random]);
        remind_sen_chs.setText(Config.remind_text_eng[random]);

        go_to_rewords = view.findViewById(R.id.go_to_rewords);
        go_to_rewords.setOnClickListener(v -> {
            dismiss();
        });

        builder.setView(view);
        dialog = builder.create();
        return dialog;
    }


}
