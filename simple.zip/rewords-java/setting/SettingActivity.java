package com.readboy.simpleLauncher.rewords.setting;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.readboy.auth.Auth;
import com.readboy.practiselistening.view.LoadStatusView;
import com.readboy.simpleLauncher.Main_UI.Fragment.Tool.ToastUtil;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.data.ObjectChangeString;
import com.readboy.simpleLauncher.rewords.data.detail_word.DBInstance;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AllWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWordsDao;
import com.readboy.simpleLauncher.rewords.data.netRecords.CheckBookData;
import com.readboy.simpleLauncher.rewords.download.HttpDownloader;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.HttpUtil;
import com.readboy.simpleLauncher.rewords.tool.IsNetWorkConnected;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;

import java.io.File;
import java.io.FileInputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SettingActivity extends AppCompatActivity {
    static String TAG = "SettingActivity";
    private static int MINUTE_INCREASE = 2;


    TextView btn_text, hour, minute;
    RadioButton rbEn,rbUs;
    RadioGroup rgSound;
    CheckBox checkBox, cb_remind, cb_lock;
    RecyclerView rv_repeat;
    ConstraintLayout cl_choice_time, cl_set;

    SettingSharePreference sharePreference;
    LoadStatusView loadStatusView;
    private List<Boolean> repeatChooseList;
    int mHour, mMinute;

    static SettingActivity instance;

    public static SettingActivity getInstance(){
        return instance;
    }


    String host = "http://192.168.20.94:8210/api";
    long uid;
    int bid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        //全透明实现
        Config.FLAG_TRANSLUCENT_STATUS(getWindow());

        setContentView(R.layout.activity_rewords_setting);
        sharePreference = new SettingSharePreference(this);

        cl_set = findViewById(R.id.cl_set);
        loadStatusView = findViewById(R.id.load_status_view);

        btn_text = findViewById(R.id.setting_back_text);
//        time_period = findViewById(R.id.time_period);
        hour = findViewById(R.id.hour);
        minute = findViewById(R.id.minute);

        rbUs=findViewById(R.id.rb_us);
        rbEn=findViewById(R.id.rb_en);
        rgSound=findViewById(R.id.rg_sound);
        cl_choice_time = findViewById(R.id.cl_choice_time);

        btn_text.setOnClickListener(v -> finish());


        if (sharePreference.getBoolean("word_sound_is_en", true)){
            rbEn.setChecked(true);
        }else {
            rbUs.setChecked(true);
        }

        rgSound.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId==R.id.rb_en){
                sharePreference.putBoolean("word_sound_is_en", true);
            }else {
                sharePreference.putBoolean("word_sound_is_en", false);
            }
            sharePreference.commit();
        });

        checkBox = findViewById(R.id.cb_read);
        checkBox.setChecked(sharePreference.getBoolean("is_auto_read", true));
        checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            sharePreference.putBoolean("is_auto_read", isChecked);
            sharePreference.commit();
        });

        cbLockWord();

        cbRemind();

        rv_repeat = findViewById(R.id.rv_repeat);
        SettingRepeatAdapter adapter = new SettingRepeatAdapter(sharePreference);
        StaggeredGridLayoutManager manager = new StaggeredGridLayoutManager(7, LinearLayoutManager.VERTICAL);
        rv_repeat.setLayoutManager(manager);
        rv_repeat.setAdapter(adapter);

//        time_period.setText(sharePreference.getString("time_period", "下午"));
        mHour = sharePreference.getInt("mHour", 8);
        mMinute =  sharePreference.getInt("mMinute", 0);

        timedProcessing();
        uid = sharePreference.getLong("uid", 111111);
        bid = sharePreference.getInt("bookId", 9803167);
        Log.e(TAG, "requestBookRecords:uid:   " + uid + "    bid: " + bid);
        /*      检查更新        */
        findViewById(R.id.check_update).setOnClickListener(v -> {
            if (IsNetWorkConnected.isNetworkConnected(this)){
                setAuth(this, uid);
                String address = host + "/v1/packages?uid=" + uid + "&bookIds=" + bid + "&sn="+ sn;
                Log.e( TAG, "requestBookRecords:requestBookInfo  " + address);
                new BookDataAsyncTask().execute(address);
//                requestBookInfo(bid);
            } else
                ToastUtil.showToast(this, "请先检查网络连接状态");
        });


    }

    boolean hideOrShow;
    /**
     * 定时提醒
     */
    private void cbRemind() {
        cb_remind = findViewById(R.id.cb_remind);
        hideOrShow = sharePreference.getBoolean("cb_remind", false);
        cb_remind.setChecked(hideOrShow);
        hideOrShow();
        cb_remind.setOnCheckedChangeListener((buttonView, isChecked) -> {
            sharePreference.putBoolean("cb_remind", isChecked);
            hideOrShow = isChecked;
            hideOrShow();
            sharePreference.commit();

        });

    }

    private void hideOrShow(){
        Log.w(TAG, "hideOrShow: " + hideOrShow);
        if (!hideOrShow){
            cl_choice_time.setVisibility(View.GONE);
        } else
             cl_choice_time.setVisibility(View.VISIBLE);

    }

    /**
     * 锁屏单词处理
     */
    private void cbLockWord() {
        cb_lock = findViewById(R.id.cb_lock);
        cb_lock.setChecked(sharePreference.getBoolean("cb_lock", false));
        cb_lock.setOnCheckedChangeListener((buttonView, isChecked) -> {
            sharePreference.putBoolean("cb_lock", isChecked);
            sharePreference.commit();
        });

    }

    /**
     * 时间处理
     */
    @SuppressLint("SetTextI18n")
    private void timedProcessing(){
        String hourText = mHour < 10 ? "0" + mHour : String.valueOf(mHour);
        hour.setText(hourText);


        String minuteText = mMinute < 10 ? "0" + mMinute : String.valueOf(mMinute);
        minute.setText(minuteText);


//        findViewById(R.id.lauch_top_img).setOnClickListener(v -> {
//            time_period.setText("上午");
//            sharePreference.putString("time_period", "上午");
//            sharePreference.commit();
//
//        });
//
//        findViewById(R.id.lauch_bottom_img).setOnClickListener(v -> {
//            time_period.setText("下午");
//            sharePreference.putString("time_period", "下午");
//            sharePreference.commit();
//
//        });

        findViewById(R.id.hour_top_img).setOnClickListener(v -> {
            if (Config.isFastDoubleClick())
                return;
            if (mHour > 0){
                mHour = mHour - 1;
            } else if (mHour == 0)
                mHour = 23;

            String t = mHour < 10 ? "0" + mHour : String.valueOf(mHour);
            hour.setText(t);
            sharePreference.putInt("mHour", mHour);
            sharePreference.commit();
        });

        findViewById(R.id.hour_bottom_img).setOnClickListener(v -> {
            if (Config.isFastDoubleClick())
                return;
            if (mHour < 23){
                mHour = mHour + 1;
            } else if (mHour == 23)
                mHour = 0;

            String t = mHour < 10 ? "0" + mHour : String.valueOf(mHour);
            hour.setText(t);
            sharePreference.putInt("mHour", mHour);
            sharePreference.commit();
        });

        findViewById(R.id.minute_top_img).setOnClickListener(v -> {
            if (Config.isFastDoubleClick())
                return;
            if (mMinute > 0){
                mMinute = mMinute - SettingActivity.MINUTE_INCREASE;
            } else if (mMinute == 0)
                mMinute = 55;
            String t = mMinute < 10 ? "0" + mMinute : String.valueOf(mMinute);
            minute.setText(t);
            sharePreference.putInt("mMinute", mMinute);
            sharePreference.commit();
        });

        findViewById(R.id.minute_bottom_img).setOnClickListener(v -> {
            if (Config.isFastDoubleClick())
                return;
            if (mMinute + SettingActivity.MINUTE_INCREASE < 59){
                mMinute = mMinute + SettingActivity.MINUTE_INCREASE;
            } else if (mMinute == 55)
                mMinute = 0;
            String t = mMinute < 10 ? "0" + mMinute : String.valueOf(mMinute);
            minute.setText(t);
            sharePreference.putInt("mMinute", mMinute);
            sharePreference.commit();
        });
    }




    String sn, device_id, t;
    String appsec = "5c9fb24e1130826cb712faa40021f08a";
    //签名参数
    public void setAuth(Context context, long uid) {
        try {
            Properties properties = Auth.getInstance(context).getSignature();
            device_id = URLEncoder.encode(properties.getProperty("device_id"), "utf-8");
            t = properties.getProperty("t");
            sn = uid + t + HttpUtil.getMD5String(t + appsec +  HttpUtil.getMD5String(String.valueOf(uid)));
            Log.d(TAG, "setAuth: " + sn + "  " + device_id + "  " + t);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


//    /*          获取课本信息并解压到本地                 */
//    private void requestBookInfo(int BID){
//
//        long updateTime = sharePreference.getLong("updateTime", 0);
//        HttpUtil.sendHttpGETRequest(address, new HttpUtil.HttpCallbackListener() {
//            @Override
//            public void onFinish(String response) {
//                try{
//                    Gson gson = new Gson();
//                    CheckBookData bookData = gson.fromJson(response, CheckBookData.class);
//                    if (bookData != null && bookData.getData().size() != 0)
//                        for (int i = 0; i < bookData.getData().size(); i++)
////                            if (updateTime == bookData.getData().get(i).getWordPackage().getUpdateTime()){
////                                showUpdateDialog(false, null);
////                            } else
//                                showUpdateDialog(true, bookData.getData().get(i).getWordPackage().getPackageUri());
//                } catch(Exception e){
//                    Log.e(TAG, "requestWordRecords requestBookInfo onFinish:Exception  " + e);
//                }
//
//            }
//
//            @Override
//            public void onError(Exception e) {
//                Log.e(TAG, "requestBookInfo requestBookInfo onError:Exception  " + e);
//            }
//        });
//
//    }

    CheckBookData bookData;
    private class BookDataAsyncTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... address) {
            bookData = HttpUtil.requestCheckBookData(address[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            long updateTime = sharePreference.getLong("updateTime", 0);
            if (bookData != null && bookData.getData().size() != 0)
                for (int i = 0; i < bookData.getData().size(); i++)
                    if (updateTime != bookData.getData().get(i).getWordPackage().getUpdateTime()){
                        showUpdateDialog(true, bookData.getData().get(i).getWordPackage().getPackageUri());
                    } else
                        showUpdateDialog(false, null);
        }
    }




    /**
     *  单词更新提醒
     */
    private void showUpdateDialog(boolean isUpdate, String path){

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("单词更新提醒");
        dialog.setCancelable(true);
        if (!isUpdate){
            dialog.setMessage("当前课本单词无更新内容");
            dialog.setPositiveButton("确认", null);
        } else {
            dialog.setMessage("当前课本单词有更新内容，是否更新？");
            dialog.setPositiveButton("确认更新", (dialog1, which) -> {
                /*      目前不清楚删除新词库是否有影响，有影响再处理       */
                DBInstance.initDb(SettingActivity.this).newWordsDao().deleteAll();
                DBInstance.initDb(SettingActivity.this).allWordsDao().deleteAll();
                cl_set.setVisibility(View.GONE);
                loadStatusView.setLoading();
                startDownloadThread(Config.ADDRESS_RESOURCE + path, uid, bid);
            });
        }
        dialog.show();
    }




    /*      开启线程下载解压包，并解压到本地目录下             */
    private void startDownloadThread(String path, long threadUid, long threadBid){
        Thread thread = new Thread(){
            @Override
            public void run(){
                Looper.prepare();
                String result = null;
                try {
                    result = HttpDownloader.download(path, threadUid, threadBid);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (result != null){
                    String regEx="[^0-9]";
                    Pattern p = Pattern.compile(regEx);
                    Matcher m = p.matcher(result);
                    String bid =  m.replaceAll("").trim();
                    try {
                        FileInputStream mFileInStream = null;
                        File mFile = new File(result);
                        byte[] s = new byte[1024];
                        if (mFile.exists()) {
                            mFileInStream = new FileInputStream(mFile);
                            s = HttpDownloader.bookReadBuffer(mFileInStream, true);
                        }
                        HttpDownloader.bytesToFile(SettingActivity.this, s, threadUid , threadBid, true);
                        if (mFile.exists())
                            mFile.delete();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else
                    hideDownloading(true);
                Looper.loop();
            }
        };
        thread.start();
    }
    /**
     *      处理完成后给handler发送消息
     */
    public void hideDownloading(boolean isEnd){
        Message msg = new Message();
        if (isEnd){
            msg.what = 0;
            handler.sendMessage(msg);
        }

    }

    List<AllWords> allWordsList = new ArrayList<>();
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0) {
                loadStatusView.setHide();
                cl_set.setVisibility(View.VISIBLE);

                DetailWordsDao dao = DBInstance.initDb(SettingActivity.this).detailWordsDao();
                List<DetailWords> detailWordsList =  dao.getAll(uid);


                String fileString =  HttpDownloader.readFileData(Config.rewordsPath + uid + "/" + bid +"/"  + "words.json");
                allWordsList.addAll(ObjectChangeString.stringToAllWords(fileString));
                Log.w(TAG, "handleMessage: " + allWordsList.size());
                for (AllWords a : allWordsList){
                    for (DetailWords w : detailWordsList){
                        if (w.getWord().equals(a.getWord())){
                            Log.e(TAG, "handleMessage: " + w.getWord());

                             String word_parse = null;
                             String word_parse_explain= null;
                            String word_parse2= null;
                             String word_parse_explain2= null;

                            if (a.getCommon_phrases() != null && a.getCommon_phrases().size() != 0){
                                if (a.getCommon_phrases().get(0).getContent().size() == 1) {
                                    word_parse = a.getCommon_phrases().get(0).getContent().get(0).getText();
                                    word_parse_explain = a.getCommon_phrases().get(0).getContent().get(0).getParaphrase();
                                } else {
                                    word_parse = a.getCommon_phrases().get(0).getContent().get(0).getText();
                                    word_parse_explain = a.getCommon_phrases().get(0).getContent().get(0).getParaphrase();
                                    word_parse2 = a.getCommon_phrases().get(0).getContent().get(1).getText();
                                    word_parse_explain2 = a.getCommon_phrases().get(0).getContent().get(1).getParaphrase();
                                }
                            }

                            dao.updateCheckWord(a.getWord(), a.getSync_explain(), a.getExplain(), a.getUk_bs(), a.getUk_word_sound(),
                                    a.getUs_bs(), a.getUs_word_sound(), a.getSentence(), a.getSentence_explain(), word_parse,
                                    word_parse_explain, word_parse2, word_parse_explain2);
                        }
                    }
                }


            }
        }
    };


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.w(TAG, "onDestroy: " );
        AM = sharePreference.getString("time_period", "下午").equals("上午") ? 0 : 1;

        Gson gson = new Gson();
        List<Boolean> list = gson.fromJson(sharePreference.getString("repeatChooseList", ""), new TypeToken<List<Boolean>>(){}.getType());
        Log.w(TAG, "onDestroy: repeatChooseList  " + list );
        if (list != null){
            for (int i =0; i < list.size(); i++)
                if (list.get(i))
                    scheduleAlarm(dayOfWeek[i]);
        } else {
            if(hideOrShow){
                Calendar c = Calendar.getInstance();
                int hDay = c.get(Calendar.DAY_OF_WEEK);
                int hHour = c.get(Calendar.HOUR_OF_DAY);
                int hMinute = c.get(Calendar.MINUTE);
                if (hHour > mHour || (hHour == mHour && hMinute > mMinute)){
                    scheduleAlarm(hDay + 1);
                } else if (hHour == mHour && hMinute <= mMinute)
                    scheduleAlarm(hDay);
                Log.e(TAG, "onDestroy: " + hDay + "   nowTime: " + hHour + ":" + hMinute);
            }
        }

    }

    /**
     *  定时处理
     */
    int AM = 0;
    Integer[] dayOfWeek = {Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY};
    private void scheduleAlarm(int day) {
        Log.v(TAG, "onDestroy:dayOfWeek  " + day );

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_WEEK, day);

        if(calendar.getTimeInMillis() < System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 7);
        }
        // 这里时区需要设置一下，不然会有8个小时的时间差
        calendar.setTimeZone(TimeZone.getTimeZone("GMT+8"));

        Log.v(TAG, "onDestroy  settingTime: " + mHour + ":" + mMinute );
        calendar.set(Calendar.HOUR_OF_DAY, mHour);
        calendar.set(Calendar.MINUTE, mMinute);
        calendar.set(Calendar.SECOND, 0);

        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent yourIntent = PendingIntent.getBroadcast(this, 0, intent, 0);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
//        alarmManager.setWindow();
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,  calendar.getTimeInMillis(), AlarmManager.INTERVAL_DAY * 7, yourIntent);
        // 计算现在时间到设定时间的时间差
        long selectTime = calendar.getTimeInMillis();
        long systemTime = System.currentTimeMillis();
        long time = selectTime - systemTime;
        Log.i(TAG, "onDestroy   afterTimeReamind: " + time);

    }

}