package com.readboy.simpleLauncher.rewords;

import android.content.Context;

import com.readboy.auth.Auth;

public class AuthHelper {
	private static boolean mHasNew = false;
	public static void newAuth(Context context) {
		if (!mHasNew) {
			mHasNew = true;
			new Auth(context);
		}
	}
}
