package com.readboy.simpleLauncher.rewords.tool;

import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jng wong  分页处理工具
 * on 2022/8/30 19:52
 */

public class Pagination {
    private final boolean mIncludePad;
    private final int mWidth;
    private final int mHeight;
    private final float mSpacingMult;
    private final float mSpacingAdd;
    private final CharSequence mText;
    private final TextPaint mPaint;
    private final List<CharSequence> mPages;

    public Pagination(CharSequence text, int pageW, int pageH, TextPaint paint, float spacingMult, float spacingAdd, boolean inclidePad) {
        this.mText = text;
        this.mWidth = pageW;
        this.mHeight = pageH;
        this.mPaint = paint;
        this.mSpacingMult = spacingMult;
        this.mSpacingAdd = spacingAdd;
        this.mIncludePad = inclidePad;
        this.mPages = new ArrayList<>();
        layout();
    }

    private void layout() {
//        DynamicLayout layout = new DynamicLayout(mText, mPaint, mWidth, Layout.Alignment.ALIGN_NORMAL, mSpacingMult, mSpacingAdd, mIncludePad);
        final StaticLayout layout = new StaticLayout(mText, mPaint, mWidth, Layout.Alignment.ALIGN_NORMAL, mSpacingMult, mSpacingAdd, mIncludePad);
        final int lines = layout.getLineCount();
        final CharSequence text = layout.getText();
        int startOffset = 0;
        int height = mHeight - 35;

        for (int i = 0; i < lines; i++){
            if (height < layout.getLineBaseline(i)){
                addPage(text.subSequence(startOffset, layout.getLineStart(i)));
                startOffset = layout.getLineStart(i);
                height = layout.getLineTop(i) + mHeight + 300;
                Log.e("bbbbbbbb", "Pagination: layout.getLineTop(i)  " + layout.getLineTop(i) + "   " + mHeight);
            }

            if (i == lines -1) {
                Log.v("bbbbbbbb", startOffset + "         asdsadsd  " + layout.getLineEnd(i) + "  asdasd : " + i);

                addPage(text.subSequence(startOffset, layout.getLineEnd(i)));
                return;
            }

        }

        for (int i = 0; i < mPages.size(); i++)
            Log.v("bbbbbbbb", "asdsadsd  " + mPages.get(i) + "asdasd");

    }

    private void addPage(CharSequence text) {
        mPages.add(text);
    }

    public int size() {
        return mPages.size();
    }

    public CharSequence get(int index) {
        return (index >= 0 && index < mPages.size()) ? mPages.get(index) : null;
    }

    public static Spannable textProcess(String mText){
        int where = 0;
        if (mText.contains("例句"))
            where = mText.indexOf("例句");

        Log.v("例句", "textPageFlip: " + where );
        Spannable spanString = new SpannableString(mText);
        spanString.setSpan(new ForegroundColorSpan(Color.BLACK), 0, 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanString.setSpan(new RelativeSizeSpan(1.5f), 0, 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanString.setSpan(new StyleSpan(Typeface.BOLD), 0, 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        spanString.setSpan(new ForegroundColorSpan(Color.BLACK), 3, where,  Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanString.setSpan(new RelativeSizeSpan(1f), 3, where, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanString.setSpan(new StyleSpan(Typeface.MONOSPACE.getStyle()), 3, where, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        spanString.setSpan(new ForegroundColorSpan(Color.BLACK), where, where + 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanString.setSpan(new RelativeSizeSpan(1.5f),  where, where + 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanString.setSpan(new StyleSpan(Typeface.BOLD),  where, where + 3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);


        return spanString;
    }

}
