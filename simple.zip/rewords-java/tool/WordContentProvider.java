package com.readboy.simpleLauncher.rewords.tool;

import android.annotation.SuppressLint;
import android.arch.persistence.room.Room;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.readboy.auth.Auth;
import com.readboy.practiselistening.database.DownloadListeningDBHelper;
import com.readboy.simpleLauncher.rewords.data.detail_word.DBInstance;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AppDatabase;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWordsDao;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.NewWordsDao;

/**
 * Created by jng wong
 * on 2022/9/14 14:02
 */
public class WordContentProvider extends ContentProvider {

    /*          这里的AUTHORITY就是我们在AndroidManifest.xml中配置的authorities     */
    private static final String AUTHORITY = "com.readboy.wordProvider";

    /*      匹配成功后的匹配码                   */
    private static final int MATCH_CODE = 100;

    private static UriMatcher uriMatcher;

    private NewWordsDao newWordsDao;
    private DetailWordsDao detailWordsDao;

    /*      数据改变后指定通知的Uri               */
    public static final Uri NOTIFY_URI = Uri.parse("content://" + AUTHORITY + "/word");

    static {
        /*      匹配不成功返回NO_MATCH(-1)       */
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

        /*      添加我们需要匹配的uri             */
        uriMatcher.addURI(AUTHORITY, "word", MATCH_CODE);
    }

    SQLiteDatabase db = null;

    @Override
    public boolean onCreate() {
        AppDatabase db = DBInstance.initDb(getContext());


        newWordsDao = db.newWordsDao();
        detailWordsDao = db.detailWordsDao();
        return false;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        int match = uriMatcher.match(uri);
        if (match == MATCH_CODE){
            AppDatabase db = DBInstance.initDb(getContext());

            Cursor cursor = db.query("select id,word,explain from newWords", null);
            if (cursor.getCount() == 0)
                cursor = db.query("select id,word,explain from newRewords", null);
            return cursor;
        }

        return null;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
