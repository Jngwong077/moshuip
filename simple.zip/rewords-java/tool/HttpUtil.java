package com.readboy.simpleLauncher.rewords.tool;


import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.google.gson.Gson;
import com.readboy.simpleLauncher.MyApplication;
import com.readboy.simpleLauncher.rewords.data.book.BookData;
import com.readboy.simpleLauncher.rewords.data.book.BookPage;
import com.readboy.simpleLauncher.rewords.data.book.CatalogueData;
import com.readboy.simpleLauncher.rewords.data.netRecords.BookReacordsData;
import com.readboy.simpleLauncher.rewords.data.netRecords.CheckBookData;
import com.readboy.simpleLauncher.rewords.data.unit_words.UnitWordsData;
import com.readboy.simpleLauncher.rewords.data.user_words.DataUserWords;
import com.readboy.simpleLauncher.rewords.data.detail_word.DataWords;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;

import com.readboy.auth.Auth;


import org.json.JSONArray;

public class HttpUtil {
    private static final String TAG = "HttpUtil";
    private static String sn;
    private static String device_id;
    private static String t;
    private static final String host = "https://api-quanjie.readboy.com";

    public static Request request;
    public static OkHttpClient client;
    public static Response response;


    //获取教材列表
    private static BookData backData;

    public static BookData requestBookData(int grade) {
        client = new OkHttpClient();
//        http://192.168.20.123/quanjie/qj/booklist?sn=tikuutil&stage=1&grade=6&subject=3&number=100
        String address = host + "/qj/booklist?sn=" + sn + "&device_id=" + device_id + "&t=" + t +
                "&stage=1&grade=" + grade + "&subject=3" + "&number=100";
        Log.d(TAG, "requestBookData: address: " + address);
        request = new Request.Builder().url(address).build();
        try {
            response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                String data = response.body().string();
                Log.w(TAG, "requestBookData: " + data );
                Gson gson = new Gson();
                backData = gson.fromJson(data, BookData.class);
            } else {
                Log.i(TAG, "requestBookData is request error");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return backData;
    }

    private static BookReacordsData reacordsData;
    public static BookReacordsData requestBookReacordsData(String address) {
        client = new OkHttpClient();
        Log.d(TAG, "requestBookData: address: " + address);
        request = new Request.Builder().url(address).build();
        try {
            response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                String data = response.body().string();
                Log.w(TAG, "requestBookData: " + data );
                Gson gson = new Gson();
                reacordsData = gson.fromJson(data, BookReacordsData.class);
            } else {
                Log.i(TAG, "requestBookData is request error");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return reacordsData;
    }

    private static CheckBookData checkBookData;
    public static CheckBookData requestCheckBookData(String address) {
        client = new OkHttpClient();
        Log.d(TAG, "requestBookData: address: " + address);
        request = new Request.Builder().url(address).build();
        try {
            response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                String data = response.body().string();
                Log.w(TAG, "requestBookData: " + data );
                Gson gson = new Gson();
                checkBookData = gson.fromJson(data, CheckBookData.class);
            } else {
                Log.i(TAG, "requestBookData is request error");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return checkBookData;
    }




    //根据课本id获取目录资源
    //        http://192.168.20.123/quanjie/qj/book/dir?sn=tikuutil&book_id=11167
    private static CatalogueData catalogueData;

    public static CatalogueData requestCatalogueData(int bookId) {
        client = new OkHttpClient();
//        String address = host + "/qj/book/dir?sn=tikuutil&book_id=" + bookId;
        String address = host + "/qj/book/dir?sn=" + sn + "&device_id=" + device_id + "&t=" + t + "&book_id=" + bookId;
        Log.d(TAG, "requestCatalogueData: address: " + address);
        request = new Request.Builder().url(address).build();
        try {
            response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                String data = response.body().string();
                Gson gson = new Gson();
                catalogueData = gson.fromJson(data, CatalogueData.class);
            } else {
                Log.i(TAG, "requestCatalogueData is request error");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return catalogueData;
    }

    //根据bookId获取教材书本详情
    //http://api.quanjie.readboy.com/qj/book?sn=tikuutil&book_id=11167&page=1
    private static BookPage bookPage;

    public static BookPage requestBookPage(int bookId) {
        client = new OkHttpClient();
//        String address = host + "/qj/book?sn=tikuutil&book_id=" + bookId + "&page=1";
        String address = host + "/qj/book?sn=" + sn + "&device_id=" + device_id + "&t=" + t + "&book_id=" + bookId + "&page=1";
        Log.d(TAG, "requestBookPage: address: " + address);
        request = new Request.Builder().url(address).build();
        try {
            response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                String data = response.body().string();
                Gson gson = new Gson();
                bookPage = gson.fromJson(data, BookPage.class);
            } else {
                Log.i(TAG, "rightOkHttp is request error");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bookPage;
    }


    //获取单元单词
    private static UnitWordsData unitWordsData;

    public static UnitWordsData requestUnitData(int uid, int bookId, int unitId) {
        client = new OkHttpClient();
//        String address = host + "/qj/user/section/words?sn=tikuutil&userId=" + uid + "&bookId=" + bookId + "&sectionId="+ unitId;
        String address = host + "/qj/user/section/words?sn=" + sn + "&device_id=" + device_id + "&t=" + t + "&userId=" + uid + "&bookId=" + bookId + "&sectionId=" + unitId;
        Log.d(TAG, "requestUnitData: address: " + address);
        request = new Request.Builder().url(address).build();
        try {
            response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                String data = response.body().string();
                Gson gson = new Gson();
                unitWordsData = gson.fromJson(data, UnitWordsData.class);
            } else {
                Log.i(TAG, "rightOkHttp is request error");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return unitWordsData;
    }

    //获取用户单词
    private static DataUserWords dataUserWords;

    /**
     * 获取用户单词
     *
     * @param uid 用户id
     * @return
     */
    public static DataUserWords requestUserData(int uid) {
        client = new OkHttpClient();
//        String address = host + "/qj/user/words?sn=7b3919d494af250e5299824f19604118&userId=" + uid + "&device_id=Readboy_C18Max/020000000000/" +
//                "com.readboy.rewords/209dfe53/Auth-2.16/2919915/13531761123/515/440000/442000/1&t=1648622141";
        String address = host + "/qj/user/words?sn=" + sn + "&userId=" + uid + "&device_id=" + device_id + "&t=" + t;
        Log.d(TAG, "requestUserData: address:" + address);
        request = new Request.Builder().url(address).build();
        try {
            response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                String data = response.body().string();
                Gson gson = new Gson();
                dataUserWords = gson.fromJson(data, DataUserWords.class);
            } else {
                Log.i(TAG, "rightOkHttp is request error");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataUserWords;
    }


    /**
     * 获取单词数据
     *
     * @param word 单词
     * @return
     */
    private static DataWords dataWords;

    public static DataWords requestWordsData(String word) {
        client = new OkHttpClient();
//        String address = " http://tiku.readboy.com:8000/words?sn=tikuutil&words=" + word;

        String address = "http://192.168.20.123/ytk/words?sn=tikuutil&words=" + word;
//        String address = "http://192.168.20.123/ytk/words?sn=" + sn + "&device_id=" + device_id + "&t=" + t + "&words=" + word;
        Log.d(TAG, "requestWordsData: address:" + address);
        request = new Request.Builder().url(address).build();
        try {
            response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                String data = response.body().string();
                Gson gson = new Gson();
                dataWords = gson.fromJson(data, DataWords.class);

            } else
                Log.i(TAG, "rightOkHttp is request error");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataWords;
    }

    public static void setAuth(Context context) {
        try {
            Properties properties = Auth.getInstance(context).getSignature();
            sn = properties.getProperty("sn");
            device_id = URLEncoder.encode(properties.getProperty("device_id"), "utf-8");
            t = properties.getProperty("t");
            Log.d(TAG, "setAuth: " + sn + "  " + device_id + "  " + t);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getHost() {
        return host;
    }

    public static String getTestHost() {
        return host;
    }

    /**
     * 向服务器发送GET请求
     *
     * @param address
     * @param listener
     */
    public static void sendHttpGETRequest(final String address, final HttpCallbackListener listener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;

                try {
                    URL url = new URL(address);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
//                    connection.setDoInput(true);
//                    connection.setDoOutput(true);
                    Log.d(TAG, "connect=" + connection);
                    InputStream in = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    Log.d(TAG, "sendHttpGETRequest GET==response=" + response);
                    if (listener != null) {
                        listener.onFinish(response.toString());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    if (listener != null) {
                        listener.onError(e);
                    }
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        }).start();
    }

    /**
     * @param address
     * @param listener
     * @param data
     */
    public static void sendHttpPOSTRequest(final String address, final Object data, final HttpCallbackListener listener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(address);
                    connection = (HttpURLConnection) url.openConnection();

                    connection.setRequestMethod("POST"); //GET或POST
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    connection.setRequestProperty("Content-Type", "application/json");

                    connection.setDoInput(true);
                    connection.setDoOutput(true);
                    connection.setUseCaches(false);

                    connection.getOutputStream().write(String.valueOf(data).getBytes());

//                    DataOutputStream out = new DataOutputStream(connection.getOutputStream());
//                    out.writeBytes(data);
//                    out.flush();

                    Log.v(TAG, "data=" + data);
                    InputStream in = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    Log.d(TAG, "sendHttpPOSTRequest response=" + response);
                    if (listener != null) {
                        listener.onFinish(response.toString());
                    }


                } catch (Exception e) {
                    e.printStackTrace();
                    if (listener != null) {
                        listener.onError(e);
                    }
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        }).start();
    }


    public interface HttpCallbackListener {
        void onFinish(String response);

        void onError(Exception e);
    }


    /**************************************************************************************
     * 更新下载app列表
     **************************************************************************************/
    public static String requestAppListData() {
        String data = null;
        client = new OkHttpClient();
        String host = "http://g-apkstore.strongwind.cn/themes/moshuiapps?";
        String device = getModel();
        String firmwareversion = getProperty();
        int storeversion = getAppVersionCode(MyApplication.getInstance(), "cn.dream.android.appstore");
        int systemversion = getSdkVersion();
        String address = host + "firmware=" + device + "&firmwareversion=" + firmwareversion + "&storeversion="
                + storeversion + "&systemversion=" + systemversion + "&device=" + device
                + "&isParent=false";
        Log.v(TAG, "requestWordsData: address = " + address);
        request = new Request.Builder().url(address).build();
        try {
            response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                data = response.body().string();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    public static String getModel() {
        String model = "Readboy_G100A";
        try {
            model = Build.MODEL;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return model;
    }

    public static String getProperty() {
        String value = "readboy";
        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            java.lang.reflect.Method get = c.getMethod("get", String.class, String.class);
            value = (String) (get.invoke(c, "ro.readboy.version", "readboy"));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return value;
        }
    }

    public static int getAppVersionCode(Context context, String packageName) {
        int versionCode = 1;
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo packinfo = pm.getPackageInfo(packageName, 0);
            if (packinfo != null) {
                versionCode = packinfo.versionCode;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return versionCode;
    }

    public static int getSdkVersion() {
        return Build.VERSION.SDK_INT;
    }


    /**
     *      获取md5
     *
     */
    private static final char HEX_DIGITS[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            'a', 'b', 'c', 'd', 'e', 'f'};
    public static String getMD5String(String s){
        MessageDigest md5;
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e){
            return null;
        }
        md5.update(s.getBytes());
        return convertToHexString(md5.digest());
    }

    private static String convertToHexString(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte a : b) {
            sb.append(HEX_DIGITS[(a & 0xf0) >>> 4]);
            sb.append(HEX_DIGITS[a & 0x0f]);
        }
        return sb.toString();
    }

}
