package com.readboy.simpleLauncher.rewords.tool;

import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.ImageView;

import java.io.IOException;
import java.lang.ref.WeakReference;

/**
 * Created by hjy on 2022/3/31 15:17
 */
public class PlayWordSound {
    private static String s = "https://contres.readboy.com";
    private static  MediaPlayer mediaPlayer;
//    public static final String READBOY_PATH = Environment.getExternalStorageDirectory().getPath() + "/PractiseListening/music/12个跳舞的公主.mp3";     //存储路径
    public static void setMediaPlayer(String sound) {
        mediaPlayer = new MediaPlayer();
        Log.d("TAG", "setMediaPlayer: " + sound);
        if (sound != null)
            try {
                mediaPlayer.reset();
                mediaPlayer.setDataSource(sound);
                mRedrawHandler.sleep(650);

            } catch (IOException e) {
                e.printStackTrace();
            }

    }

    public static void start() {
        if (mediaPlayer != null){
            mediaPlayer.setOnPreparedListener(mediaPlayer -> {
                mediaPlayer.start();
            });

        }
    }

    public static void stop() {
        if (mediaPlayer != null){
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
                mediaPlayer.reset();
            }
        }

    }

    public static void finish(){
        if (mediaPlayer != null){
            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }


    private static RefreshHandler mRedrawHandler = new RefreshHandler();
    static class RefreshHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0){

                mediaPlayer.prepareAsync();
                start();
            }
        }

        public void sleep(long delayMillis) {
            this.removeMessages(0);
            sendMessageDelayed(obtainMessage(0), delayMillis);
        }
    }
}
