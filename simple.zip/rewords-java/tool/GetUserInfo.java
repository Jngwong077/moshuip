package com.readboy.simpleLauncher.rewords.tool;

import android.content.Context;
import android.util.Log;

import com.readboy.provider.UserDbSearch;
import com.readboy.provider.mhc.info.UserBaseInfo;

/**
 * Created by hjy on 2022/4/6 11:34
 */
public class GetUserInfo {
    /**
     * 获取平板用户信息
     *
     * @return 信息
     */
    static public UserBaseInfo getUserBaseInfo(Context context) {
        UserDbSearch userDbSearch = UserDbSearch.getInstance(context);
        /*      获取用户所绑定的英语教材信息      */
        Log.i("TAG", "getUserBaseInfo: " + userDbSearch.getUserInfo().uid);
        return null == userDbSearch ? null : userDbSearch.getUserInfo();
    }

    /**
     * 获取平板上用户名
     * created by 2022/01/13
     */
    static public String getURealName(Context context) {
        UserBaseInfo userBaseInfo = getUserBaseInfo(context);
        return null != userBaseInfo ? userBaseInfo.realName : "0";
    }

    /**
     * 获取平板上用户uid
     */
    static public int getUid(Context context) {
//        if (true) {
//            return 4058011;
//        }
        UserBaseInfo userBaseInfo = getUserBaseInfo(context);
        return userBaseInfo != null ? userBaseInfo.uid : 0;
    }

    /**
     * 获取平板上用户对应的英语教材
     * created by 2022/01/13
     * @return
     */
    static public int getEngBookId(Context context) {
        UserDbSearch userBaseInfo = UserDbSearch.getInstance(context);
        return null != userBaseInfo ? userBaseInfo.getBookClassInfo(3).bookId : 9803167;
    }
}
