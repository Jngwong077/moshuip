package com.readboy.simpleLauncher.rewords.tool;

import android.util.Log;

public class Logger {
    public static final String prefix = "Logger => ";
    public static boolean isEnableLog = false;

    /**
     * @param isEnableLog <code>ture-</code>开启内部打印，<code>false-</code>关闭内部打印
     */
    public static void setIsEnableLog(boolean isEnableLog) {
        Logger.isEnableLog = isEnableLog;
    }

    public static String generatePrefix() {
        return prefix + "[" + Thread.currentThread().getName() + "] ";
    }

    public static void v(String tag, String msg) {
        if (isEnableLog) Log.v(tag, generatePrefix() + msg);
    }

    public static void d(String tag, String msg) {
        if (isEnableLog) Log.d(tag, generatePrefix() + msg);
    }

    public static void i(String tag, String msg) {
        if (isEnableLog) Log.i(tag, generatePrefix() + msg);
    }

    public static void w(String tag, String msg) {
        if (isEnableLog) Log.w(tag, generatePrefix() + msg);
    }

    public static void w(String tag, String msg, Throwable throwable) {
        if (isEnableLog) Log.w(tag, generatePrefix() + msg, throwable);
    }

    public static void e(String tag, String msg) {
        if (isEnableLog) Log.e(tag, generatePrefix() + msg);
    }

    public static void e(String tag, String msg, Throwable throwable) {
        if (isEnableLog) Log.e(tag, generatePrefix() + msg, throwable);
    }
}
