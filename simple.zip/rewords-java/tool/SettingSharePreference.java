package com.readboy.simpleLauncher.rewords.tool;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.gson.Gson;

import java.util.List;

/**
 * Created by hjy on 2022/4/2 9:20
 */
public class SettingSharePreference {
    private static final String FILENAME = "Rewards_Setting";

    Context context;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


    public SettingSharePreference(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(FILENAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

    }

    public void putBoolean(String key, Boolean value){
        editor.putBoolean(key, value);
    }

    public boolean getBoolean(String key, Boolean value){
        return sharedPreferences.getBoolean(key, value);
    }

    public void putInt(String key, int value){
        editor.putInt(key, value);
    }

    public Integer getInt(String key, int value){
        return sharedPreferences.getInt(key, value);
    }

    public void putLong(String key, long value){
        editor.putLong(key, value);
    }

    public Long getLong(String key, long value){
        return sharedPreferences.getLong(key, value);
    }



    public void putString(String key, String value){
        editor.putString(key, value);
    }

    public String getString(String key, String value){
        return sharedPreferences.getString(key, value);
    }

    public void commit(){
        Log.i("TAG", "init:isSelectBook " +  editor.commit());
    }

    public void putIntList(String key, List<Integer> list){
        Gson gson = new Gson();
        //将list转成Json
        String jsonStr = gson.toJson(list);
        Log.e("TAG", "commit: " + jsonStr);
        editor.putString(key, jsonStr);
    }

    public void putStringList(String key, List<String> list){
        Gson gson = new Gson();
        //将list转成Json
        String jsonStr = gson.toJson(list);
        editor.putString(key, jsonStr);
//        Log.d("TAG", "putStringList: " + jsonStr);
    }


}
