package com.readboy.simpleLauncher.rewords.tool;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Environment;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;


import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;
import com.readboy.simpleLauncher.rewords.download.FileUtils;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by hjy on 2022/4/9 11:11
 */
public class Config {
    /**
     * 每轮学习单词最多数量
     */
    public static int WORD_NUMBER = 3;

    /**
     * 单词出现次数
     */
    public static int WORD_APPEAR_RAN_MIN = 3;
    public static int WORD_APPEAR_RAN_MAX = 10;
    public static int WORD_APPEAR_1 = 1;
    public static int WORD_APPEAR_2 = 2;
    public static int WORD_APPEAR_4 = 4;
    public static int WORD_APPEAR_7 = 7;
    public static int WORD_APPEAR_12 = 10;
    public static int WORD_APPEAR_21 = 13;
    public static int WORD_APPEAR_45 = 16;
    public static int WORD_APPEAR_50 = 50;

    public static int SELECT_UNIT_START = 0;
    public static int BACK_SELECT_UNIT_START = 1;
    public static int BACK_CONTINUE_START = 2;


    /*      单词学习轮数      */
    public static int ROUND = 0;

    public static final String SERVER_URL = "https://api-quanjie.readboy.com";  //外网正式服务器
    static FileUtils fileUtils = new FileUtils();
    public static final String rewordsPath = fileUtils.getSDPATH() + "Recite/";

//    public static final String READBOY_PATH = Environment.getExternalStorageDirectory().getPath();
    public static final String wordSoundPath = fileUtils.getSDPATH() + ".readboy/Recite/rewords/";

    public static final String ADDRESS_RESOURCE = "https://contres.readboy.com";


    public static String[] gradeList = new String[]{"一年级", "二年级", "三年级", "四年级", "五年级", "六年级"};

    public static int[] end_bg = {R.drawable.end_1, R.drawable.end_2, R.drawable.end_3, R.drawable.end_4, R.drawable.end_5,
            R.drawable.end_6, R.drawable.end_7, R.drawable.end_8};

    public static String[] learn_text = {
            "今日学完第一组单词。", "今日学完第两组单词。", "今日学完第三组单词。", "今日学完第四组单词。", "今日学完第五组单词。",
            "今日学完第六组单词。", "今日学完第七组单词。", "今日学完第八组单词。", "今日学完第九组单词。", "今日学完第十组单词。"
    };

    public static String[] encourage_text = {
            "据科学研究，每日学习三组有助于加深记忆，再来一组试试吧！", "离三组目标还差一组，再坚持一下吧，对抗遗忘最好的方式是继续复习！",
            "今日的目标已完成，为你的自律鼓掌，明天记得继续来学习哦！"};

    public static String[] remind_text_eng = {
            "If you find a path with no obstacles, it probably doesn’t lead anywhere.", "Great minds have purpose, others have wishes.",
            "The future is scary but you can’t just run to the past cause it’s familiar.", "Success is the ability to go from one failure to another with no loss of enthusiasm.",
            "Not everything that is faced can be changed, but nothing can be changed until it is faced.", "Failure is never quite so frightening as regret.",
            "If a thing is worth doing it is worth doing well.", "It’s what you do right now that makes a difference."
    };

    public static String[] remind_text_chs = {
            "太容易的路，可能根本就不能带你去任何地方。", "杰出的人有着目标，其他人只有愿望。",
            "未来会让人心生畏惧，但是我们却不能因为习惯了过去，就逃回过去。！", "成功是，你即使跨过一个又一个失敗，但也沒有失去热情。",
            "并不是你面对了，任何事情都能改变。但是，如果你不肯面对，那什么也变不了。", "比失败更令人恐惧的是懊悔" ,
            "如果事情值得做，就值得做好", "你现在所做的是改变现状的关键"
    };

    public static List<DetailWords> words = new ArrayList<>();

    public static List<Integer> unitIdList = new ArrayList<>();
    public static List<String> unitNameList  = new ArrayList<>();
    public static List<Integer> getMinId = new ArrayList<>();

    public static List<Integer> getGetMinId() {
        return getMinId;
    }

    public static List<Integer> getUnitIdList() {
        return unitIdList;
    }



    public static List<String> getUnitNameList() {
        return unitNameList;
    }

    public static boolean studyAll = false;

    public static boolean isStudyAll() {
        return studyAll;
    }

    public static void setStudyAll(boolean studyAll) {
        Config.studyAll = studyAll;
    }

    public static boolean isGoSelectUnit = false;

    public static boolean isNeedToRefresh = true;

    public static boolean isIsNeedToRefresh() {
        return isNeedToRefresh;
    }

    public static void setIsNeedToRefresh(boolean isNeedToRefresh) {
        Config.isNeedToRefresh = isNeedToRefresh;
    }

    /*     学习单词界面的临时掌握数        */
    public static int UN_CONTROL_NUMBER = 0;

    public static int getUnControlNumber() {
        return UN_CONTROL_NUMBER;
    }

    public static void setUnControlNumber(int unControlNumber) {
        UN_CONTROL_NUMBER = unControlNumber;
    }

    /*     记录临时单词      */
    public static List<DetailWords> TEMPORARY_WORD = new ArrayList<>();

    /*     是否来自选书界面     */
    public static boolean IsFromSelectBook;

    /*       判断是否是快速点击      */
    private static final int MIN_CLICK_DELAY_TIME = 1000;
    private static long lastClickTime;
    /**
     * 是否是快速点击
     * @param gaptime 单位：毫秒
     * @return
     */
    public static boolean isFastDoubleClick(int... gaptime) {
        long currentTime = System.currentTimeMillis();
        long timeGap = currentTime - lastClickTime;

        int minGapTime = MIN_CLICK_DELAY_TIME;
        if ( gaptime != null && gaptime.length > 0) {
            minGapTime = gaptime[0];
        }
        if ( 0 < timeGap && timeGap < minGapTime) {
            return true;
        }
        lastClickTime = currentTime;
        return false;
    }

    /**
     * 透明实现
     * @param window2
     */
    public static void FLAG_TRANSLUCENT_STATUS(Window window2){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            //5.0 全透明实现
            //getWindow.setStatusBarColor(Color.TRANSPARENT)
            Window window = window2;
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //4.4 全透明状态栏
            window2.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        window2.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

    }

    /**
     *  复制文件
     * @param sourceFile        文件路径
     * @param destFile          输出路径
     * @return
     */
    public static boolean copyFile(File sourceFile, File destFile)  {
        try {
            if (!destFile.getParentFile().exists())
                destFile.getParentFile().mkdirs();

            if (!destFile.exists()) {
                destFile.createNewFile();
            }

            FileChannel source = null;
            FileChannel destination = null;

            try {
                source = new FileInputStream(sourceFile).getChannel();
                destination = new FileOutputStream(destFile).getChannel();
                destination.transferFrom(source, 0, source.size());
            } finally {
                if (source != null) {
                    source.close();
                }
                if (destination != null) {
                    destination.close();
                }
            }
            return true;
        } catch (IOException e){
            return false;
        }

    }



}
