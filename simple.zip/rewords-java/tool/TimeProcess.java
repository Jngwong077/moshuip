package com.readboy.simpleLauncher.rewords.tool;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWords;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by hjy on 2022/5/30 16:27
 */
public class TimeProcess {

    /**
     * control time:
     * 2    4天后出现，变成复习单词
     * 3    12天后出现
     * 4    36天后出现
     *
     * @param rWords
     */
    public static void isTimeToRecover(List<DetailWords> rWords){
//        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//
//        try
//        {
//            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//            Date date = new Date(System.currentTimeMillis());
//            String nowTime = simpleDateFormat.format(date);
//            Date endTime = df.parse(nowTime);
//            Date startTime;
//            int i = 0;
//            for (DetailWords w : rWords){
//                startTime = df.parse(w.getLearnTime());
//                long diff = endTime.getTime() - startTime.getTime();
//                long days = diff / (1000 * 60 * 60 * 24);
//                if (days > 4 && w.getControlTime() == 1){
//                    w.setIsControl(1);
//                    i++;
//                } else if (days > 12 && w.getControlTime() == 2){
//                    w.setIsControl(1);
//                    i++;
//                }else if (days > 36 && w.getControlTime() == 3){
//                    w.setIsControl(1);
//                    i++;
//                }else if (days > 108 && w.getControlTime() == 4){
//                    w.setIsControl(1);
//                    i++;
//                }
//                if (i != 0 && i < 20)
//                    w.save();
//                Log.d("TAG", "isTimeToRecover: " + i);
//            }
//        }catch (Exception e) {
//        }

    }




    private static final String FILE_NAME = "LastLoginTime";
    private static final String KEY = "LoginTime";
    private static final String DEFAULT_TIME = "2021-11-9";

    /**
     * 判断每日是否首次学习
     * @param context
     * @return
     */
    public static boolean isTodayFirstLearn(Context context){
        SharedPreferences sharedPreferences = context.getSharedPreferences(FILE_NAME,Context.MODE_PRIVATE);
        String lastTime = sharedPreferences.getString(KEY, DEFAULT_TIME);
        @SuppressLint("CommitPrefEdits") SharedPreferences.Editor editor = sharedPreferences.edit();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String todayTime = dateFormat.format(new Date());

        //上次学习时间与今天相同，即为非首次学习
        assert lastTime != null;
        if (lastTime.equals(todayTime)){
            editor.putString(KEY, todayTime).apply();
            return true;
        } else
            return false;

    }




}
