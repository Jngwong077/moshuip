package com.readboy.simpleLauncher.rewords.selectBookAndUnit;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.readboy.simpleLauncher.Main_UI.Fragment.Tool.ToastUtil;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.data.ObjectChangeString;
import com.readboy.simpleLauncher.rewords.data.book.UnitData;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;

import org.litepal.LitePal;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by hjy on 2022/4/11 9:25
 */
public class SelectUnitActivity extends AppCompatActivity {
    TextView btn_select_unit_back;
    TextView unit_book_name;
    RelativeLayout rv_select_book;
    RecyclerView select_unit_recyclerview;
    int bookId;
    String bookName;
    static SelectUnitActivity instance;
    public static SelectUnitActivity getInstance(){
        return instance;
    }


    SettingSharePreference sharePreference;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        Config.FLAG_TRANSLUCENT_STATUS(getWindow());

        setContentView(R.layout.activity_select_unit);
        initView();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void initView(){
        rv_select_book = findViewById(R.id.rv_select_book);
        btn_select_unit_back = findViewById(R.id.select_unit_back_btn);
//        unit_book_name = findViewById(R.id.select_unit_book_name);
        select_unit_recyclerview = findViewById(R.id.select_unit_recyclerview);

        sharePreference = new SettingSharePreference(SelectUnitActivity.this);
        bookName = sharePreference.getString("bookName", "");
//        unit_book_name.setText(bookName);
        Log.d("bookName", "initView: " + bookName);

        btn_select_unit_back.setOnClickListener(v -> {
            finish();
        });

        findViewById(R.id.learn_seekbar).setOnTouchListener((v, event) -> true);


        bookId =  sharePreference.getInt("bookId", 142167);
        Log.d("bookName", "initView: " + bookId);
        String unitDataString = getIntent().getStringExtra("unitDataString");
        unit = ObjectChangeString.stringToUnitData(unitDataString);
        Log.d("bookName", "unit: " + unit);
        new unitAsyncTask().execute(bookId);
    }



    UnitData unit;
    List<UnitData> unitData = new ArrayList<>();
    private class unitAsyncTask extends AsyncTask<Integer, Void, Void>{
        @Override
        protected Void doInBackground(Integer... integers) {
            unitData.clear();
            unitData.addAll(LitePal.where("bid = ?", String.valueOf(integers[0])).find(UnitData.class));
            if (unitData.size() == 0){
                if (unit != null){
                    String c =  ObjectChangeString.listObjectToString(unit.getChildren());
                    UnitData data = new UnitData();
                    data.setBid(unit.getBid());
                    data.setData(c);
                    data.setName(unit.getEdition().getName() + bookName);
                    data.save();
                    Log.d("TAG", "bookName:  isSave: " + data.isSaved());
                    unitData.add(data);
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            if (unitData.size() != 0){
                SelectUnitAdapter unitAdapter = new SelectUnitAdapter(ObjectChangeString.stringToObject(unitData.get(0).getData()),
                        SelectUnitActivity.this, bookId, bookName);

                LinearLayoutManager manager = new LinearLayoutManager(SelectUnitActivity.this);
                select_unit_recyclerview.setLayoutManager(manager);
                select_unit_recyclerview.setAdapter(unitAdapter);
            } else
                ToastUtil.showToast(SelectUnitActivity.this, R.string.get_data_fail);



//            if (bookPage != null && catalogueData != null &&catalogueData.getData() != null & bookPage.getData() != null){
//                SelectUnitAdapter unitAdapter = new SelectUnitAdapter(catalogueData.getData().getBooks().getChildren(),
//                        bookPage.getData().getBook().getPage().getData(), SelectUnitActivity.this, bookId, bookName);
//
//                LinearLayoutManager manager = new LinearLayoutManager(SelectUnitActivity.this);
//                select_unit_recyclerview.setLayoutManager(manager);
//                select_unit_recyclerview.setAdapter(unitAdapter);
//            } else
//                ToastUtil.showToast(SelectUnitActivity.this, R.string.get_data_fail);

        }
    }

    @Override
    protected void onPause() {
        if (sharePreference.getBoolean("isSelectBook", false)) {
            sharePreference.putBoolean("isSelectBook", false);
            Log.d("TAG", "init: " +
                    "   getUnitIdList  " + Config.getUnitIdList() +
                    "  getUnitNameList  " + Config.getUnitNameList());

//            sharePreference.putInt("unitId", Collections.min(Config.getGetMinId()));
            Log.w("qwe", "33333: " );
            sharePreference.putString("bookName", bookName);
            sharePreference.putIntList("unitIdList", Config.getUnitIdList());
            sharePreference.putStringList("unitNameList", Config.getUnitNameList());
            sharePreference.commit();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {

        Config.getGetMinId().clear();
        Config.getUnitNameList().clear();
        Config.getUnitIdList().clear();
        super.onDestroy();
    }
}
