package com.readboy.simpleLauncher.rewords.selectBookAndUnit;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.arch.persistence.room.Room;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.Main_UI.Fragment.Tool.ToastUtil;
import com.readboy.simpleLauncher.rewords.AuthHelper;
import com.readboy.simpleLauncher.rewords.data.ObjectChangeString;
import com.readboy.simpleLauncher.rewords.data.book.BookData;
import com.readboy.simpleLauncher.rewords.data.book.BookDetails;
import com.readboy.simpleLauncher.rewords.data.book.UnitData;
import com.readboy.simpleLauncher.rewords.data.detail_word.DBInstance;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.AppDatabase;
import com.readboy.simpleLauncher.rewords.data.detail_word.DetailWordsRoom.DetailWordsDao;
import com.readboy.simpleLauncher.rewords.download.HttpDownloader;
import com.readboy.simpleLauncher.rewords.fragment.Dialog_Fragment_Choice;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.GetUserInfo;
import com.readboy.simpleLauncher.rewords.tool.HttpUtil;
import com.readboy.simpleLauncher.rewords.tool.IsNetWorkConnected;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;


import org.litepal.LitePal;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created by hjy on 2022/4/9 9:40
 */
public class SelectBookActivity extends AppCompatActivity {
    private String TAG = "SelectBookActivity";
    private int grade, uid, bookid;
    TextView btn_select_book_back;
    LinearLayout btn_switch_grade, book_downloading;
    RecyclerView rv_select_book, rv_select_grade;
    TextView grade_text;
    SettingSharePreference sharePreference;
    static SelectBookActivity instance;
    DetailWordsDao wordsDao;

    public static SelectBookActivity getInstance(){
        return instance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        Config.FLAG_TRANSLUCENT_STATUS(getWindow());

        wordsDao = DBInstance.initDb(this).detailWordsDao();

        setContentView(R.layout.activity_select_book);
        if (GetUserInfo.getUserBaseInfo(this) != null) {
            uid = GetUserInfo.getUserBaseInfo(this).uid;
        } else
            uid = 111111;

        initView();
        initGradeAdapter();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Dialog_Fragment_Choice.getInstance().isShowUnit(false);
    }

    private void initView(){

        book_downloading = findViewById(R.id.book_downloading);
        book_downloading.setVisibility(View.GONE);
        btn_select_book_back = findViewById(R.id.select_book_back_btn);
        btn_switch_grade = findViewById(R.id.switch_grade_btn);
        rv_select_book = findViewById(R.id.select_book_recyclerview);
        rv_select_grade = findViewById(R.id.select_grade_recyclerview);
        grade_text = findViewById(R.id.selected_grade);
        rv_select_grade.setVisibility(View.INVISIBLE);
        btn_select_book_back.setOnClickListener(v -> {
            Dialog_Fragment_Choice.getInstance().isShowUnit(false);
            finish();
        });

        btn_switch_grade.setOnClickListener(v -> {
            if (rv_select_grade.getVisibility() == View.INVISIBLE){
                rv_select_grade.setVisibility(View.VISIBLE);
            } else
                rv_select_grade.setVisibility(View.INVISIBLE);
        });
        initGrade();
        sharePreference = new SettingSharePreference(SelectBookActivity.this);
        new bookAsyncTask().execute(grade);
    }


    List<BookDetails> bookDetails = new ArrayList<>();
    BookData bookData;
    AlertDialog.Builder dialog = null;
    private class bookAsyncTask extends AsyncTask<Integer, Void, Void>{
        @Override
        protected Void doInBackground(Integer... i) {
            AuthHelper.newAuth(SelectBookActivity.this);
            HttpUtil.setAuth(SelectBookActivity.this);
            bookDetails.clear();
            bookDetails.addAll(LitePal.where("grade = ?", String.valueOf(i[0])).find(BookDetails.class));
            Log.d(TAG, "doInBackground: " + bookDetails.size());
            if (bookDetails.size() == 0){
                bookData = HttpUtil.requestBookData(i[0]);
                if (bookData != null && bookData.getData()  != null){
                    bookDetails = bookData.getData().getBooks();

                    for (int j = 0; j < bookDetails.size() ;j ++){
                        if (bookDetails.get(j).getWordPackage() != null){
                            String name = bookDetails.get(j).getName();
                            if (name.contains("英语")){
                                name = name.replaceAll("英语", "");
                            }
                            bookDetails.get(j).setGradeName(name);
                            bookDetails.get(j).setName(bookDetails.get(j).getEdition().getName());
                            bookDetails.get(j).setCover(bookDetails.get(j).getCover());
                            bookDetails.get(j).setGrade(bookDetails.get(j).getGrade());
                            bookDetails.get(j).setBid(bookDetails.get(j).getBid());
                            bookDetails.get(j).setPackageUri(bookDetails.get(j).getPackageUri());


                            bookDetails.get(j).setUpdateTime(bookDetails.get(j).getWordPackage().getUpdateTime());
                            bookDetails.get(j).setWordPackageUri(bookDetails.get(j).getWordPackage().getPackageUri());
                            bookDetails.get(j).save();
                        }else{
                            bookDetails.remove(j);
                            j--;
                        }
                    }

                }

            }
            return null;
        }

        @SuppressLint("ClickableViewAccessibility")
        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);

            if (bookDetails.size() != 0){
                SelectBookAdapter selectBookAdapter = new SelectBookAdapter(bookDetails, SelectBookActivity.this);
                StaggeredGridLayoutManager manager = new StaggeredGridLayoutManager(3, LinearLayoutManager.VERTICAL);
                rv_select_book.setLayoutManager(manager);
                rv_select_book.setAdapter(selectBookAdapter);
                rv_select_book.setOnTouchListener((v, event) -> {
                    rv_select_grade.setVisibility(View.INVISIBLE);
                    return false;
                });

                selectBookAdapter.setBookItemClick((path, bookId, updateTime) -> {
                    Log.d(TAG, "onPostExecute: " + grade);
                    if (dialog == null){
                        dialog = new AlertDialog.Builder(SelectBookActivity.this);
                        dialog.setTitle("温馨提示");
                        dialog.setMessage("当前学习课本内容变更，是否清除复习单词内容");
                        dialog.setCancelable(true);
                        dialog.setNegativeButton("清除", (dialog, which) -> {
                            wordsDao.delectALL(uid);
                            startThread(path, bookId);
                        });

                        dialog.setPositiveButton("保留", (dialog, which) -> {
                            startThread(path, bookId);
                        });

                    }
                    dialog.show();
                    sharePreference.putLong("updateTime", updateTime);
                    sharePreference.commit();


                });
            } else
                ToastUtil.showToast(SelectBookActivity.this, R.string.get_data_fail);

        }
    }

    private void startThread(String path, int bookId){
        bookid = bookId;
        sharePreference.putInt("grade", grade);
        sharePreference.commit();
        book_downloading.setVisibility(View.VISIBLE);
        Thread thread = new Thread(){
            @Override
            public void run(){
                String result = null;
                try {
                    result = HttpDownloader.download(Config.ADDRESS_RESOURCE + path, uid, bookId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Log.d(TAG, "run: result " + result);
                if (result != null) {
                    String regEx = "[^0-9]";
                    Pattern p = Pattern.compile(regEx);
                    Matcher m = p.matcher(result);
                    String bid = m.replaceAll("").trim();
                    try {
                        FileInputStream mFileInStream = null;
                        File mFile = new File(result);
                        byte[] s = new byte[1024];
                        if (mFile.exists()) {
                            mFileInStream = new FileInputStream(mFile);
                            s = HttpDownloader.bookReadBuffer(mFileInStream, true);
                        }
                        HttpDownloader.bytesToFile(SelectBookActivity.this, s, uid, bookId, true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

            }

        };
        thread.start();

    }


    //处理完成后给handler发送消息
    public void hideDownloading(){
        Message msg = new Message();
        msg.what = 1;
        handler.sendMessage(msg);
    }

    //年级选择初始化
    private void initGradeAdapter(){
        SelectGradeAdapter gradeAdapter = new SelectGradeAdapter();
        LinearLayoutManager manager = new LinearLayoutManager(this);
        rv_select_grade.setLayoutManager(manager);
        rv_select_grade.setAdapter(gradeAdapter);

        //接口回调实现选择年级
        gradeAdapter.setGrade(g -> {
            if (!IsNetWorkConnected.isNetworkConnected(SelectBookActivity.this)){
                ToastUtil.showToast(SelectBookActivity.this, R.string.btn_no_net_text);
                return;
            }
            grade = g + 1;
            grade_text.setText(Config.gradeList[g]);
            rv_select_grade.setVisibility(View.INVISIBLE);
            new bookAsyncTask().execute(grade);
        });
    }

    private void initGrade(){
        SettingSharePreference sharePreference = new SettingSharePreference(this);
        grade = sharePreference.getInt("grade", 3);
        grade_text.setText(Config.gradeList[grade - 1]);
    }

    UnitData unitData;
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
//                Intent intent = new Intent();
                book_downloading.setVisibility(View.GONE);
                String fileString =  HttpDownloader.readFileData(Config.rewordsPath + uid + "/" + bookid +"/" + "book.json");

                Gson gson = new Gson();
                unitData = gson.fromJson(fileString, UnitData.class);
                if (unitData.getChildren() != null){
                    String bName = unitData.getName();
                    if (bName.length() > 2)
                        bName = bName.substring(2);
                    String c =  ObjectChangeString.objectToString(unitData);
//                    intent.putExtra("unitDataString", c);
                    sharePreference.putString("bookName", unitData.getEdition().getName() + bName);
                    sharePreference.putInt("bookId", unitData.getBid());
                    sharePreference.putString("unitDataString", c);
                    sharePreference.commit();
                }
                Dialog_Fragment_Choice.getInstance().isShowUnit(true);
//                intent.setClass(SelectBookActivity.this, SelectUnitActivity.class);
//                startActivity(intent);
                finish();
            }
        }
    };


}
