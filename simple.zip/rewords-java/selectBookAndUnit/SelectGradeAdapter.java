package com.readboy.simpleLauncher.rewords.selectBookAndUnit;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.tool.Config;

/**
 * Created by hjy on 2022/4/11 9:38
 */
public class SelectGradeAdapter extends RecyclerView.Adapter<SelectGradeAdapter.ViewHolder>{


    @NonNull
    @Override
    public SelectGradeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_grade, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SelectGradeAdapter.ViewHolder viewHolder, int i) {
        viewHolder.select_grade.setText(Config.gradeList[i]);
        viewHolder.select_grade.setOnClickListener(v -> {
            gradeChangerListener.onChange(i);
        });
    }

    @Override
    public int getItemCount() {
        return Config.gradeList.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView select_grade;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            select_grade = itemView.findViewById(R.id.select_grade);

        }
    }

    //接口回调
    public interface GradeChangerListener {
        void onChange(int g);
    }

    public GradeChangerListener gradeChangerListener;

    public void setGrade(GradeChangerListener gradeChangerListener) {
        this.gradeChangerListener = gradeChangerListener;
    }

}
