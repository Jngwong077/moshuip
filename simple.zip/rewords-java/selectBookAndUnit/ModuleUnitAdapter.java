package com.readboy.simpleLauncher.rewords.selectBookAndUnit;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.Main_UI.Fragment.Tool.ToastUtil;
import com.readboy.simpleLauncher.rewords.data.book.Children;
import com.readboy.simpleLauncher.rewords.data.book.Children2;
import com.readboy.simpleLauncher.rewords.data.book.PageData;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by hjy on 2022/4/11 15:40
 */
public class ModuleUnitAdapter extends RecyclerView.Adapter<ModuleUnitAdapter.ViewHolder>{
    ArrayList<Children2> children;
//    ArrayList<PageData.Pages> pages;

    Context context;
    SettingSharePreference sharePreference;
    int bookId;
    String bookName;
    List<Integer> idList;
    List<Integer> nofindIdList = new ArrayList<>();

    public ModuleUnitAdapter(ArrayList<Children2> children, Context context, int bookId, String bookName,List<Integer> idList){
        this.children = children;
        this.context = context;
//        this.pages = pages;
        this.bookId = bookId;
        this.bookName = bookName;
        this.idList = idList;
        sharePreference = new SettingSharePreference(context);


    }

    @NonNull
    @Override
    public ModuleUnitAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_module_unit, viewGroup, false);
        return  new ModuleUnitAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ModuleUnitAdapter.ViewHolder viewHolder, int i) {
        viewHolder.init(i);
    }

    @Override
    public int getItemCount() {
        return children == null ? 0 : children.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView select_module_text, module_unit_page;
        CheckBox checkBox;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            select_module_text = itemView.findViewById(R.id.select_module_text);
            module_unit_page =itemView.findViewById(R.id.module_unit_page);
            checkBox = itemView.findViewById(R.id.module_checkbook);
        }

        private void init(int i){
            /*      将章节id和章节名保存         */
            if (children.get(i).getWord() != null){
                Config.getUnitIdList().add(children.get(i).getId());
                Config.getUnitNameList().add(children.get(i).getName());

                if (idList != null && idList.size() != 0){
                    checkBox.setChecked(idList.contains(children.get(i).getId()));
                    if (!idList.contains(children.get(i).getId()))
                        nofindIdList.add(children.get(i).getId());
                }

                if (Config.IsFromSelectBook)
                    checkBox.setChecked(true);
            } else
                checkBox.setVisibility(View.GONE);

            Log.w("TAG", "bbbbbb   getUnitIdList  " + Config.getUnitIdList());

//            if (i == children.size() - 1 && sharePreference.getBoolean("isSelectBook", false)) {
//                Config.getGetMinId().add(children.get(0).getId());
//            }

            /*          移除不存在于sp里的id             */
            if (i == children.size() - 1 && !Config.IsFromSelectBook)
                for (int id : nofindIdList)
                    for(int k = 0; k <  Config.getUnitIdList().size(); k++)
                        if ( Config.getUnitIdList().get(k).equals(id)){
                            Config.getUnitIdList().remove(k);
                            break;
                        }


            select_module_text.setText(children.get(i).getName());
            select_module_text.setOnClickListener(v -> {
                if (Config.isFastDoubleClick()) return;//防止快速点击
                Log.e("bbbbbb", "initAdapter: end  " + Config.getUnitIdList().size() );
                if (children.get(i).getWord() != null ) {

                    /*          list里面有的则删除，没有则添加             */
                    boolean isExit = false;
                    for (int k = 0; k <  Config.getUnitIdList().size(); k++){
                        if ( Config.getUnitIdList().get(k).equals(children.get(i).getId())){
                            Config.getUnitIdList().remove(k);
                            isExit = true;
                            break;
                        }
                    }

                    if (!isExit)
                        Config.getUnitIdList().add(children.get(i).getId());

                    if (Config.getUnitIdList().size() < 1){
                        if (!Config.getUnitIdList().contains(children.get(i).getId()))
                            Config.getUnitIdList().add(children.get(i).getId());
//                        ToastUtil.showToast(context, "最少要选择一个单元！");
                        return;
                    }


                    checkBox.setChecked(!checkBox.isChecked());

                    Collections.sort( Config.getUnitIdList());       /*      排序      */
                    Log.d("bbbbbb", "initAdapter: end" +  Config.getUnitIdList() );
                    sharePreference.putIntList("unitIdList",  Config.getUnitIdList());
                    sharePreference.commit();

//                    sharePreference.putInt("bookId", bookId);
////                    sharePreference.putString("bookName", bookName);
//                    sharePreference.putInt("unitId", children.get(i).getId());
//                    Log.w("qwe", "666666: " );
////                    sharePreference.putString("unitName", children.get(i).getName());
//                    sharePreference.putIntList("unitIdList", Config.getUnitIdList());
//                    sharePreference.putStringList("unitNameList", Config.getUnitNameList());
//                    sharePreference.putBoolean("sectionIdHaveChange", true);
//                    sharePreference.putBoolean("isNeedToGet", true);
//                    sharePreference.commit();
//                    SelectUnitActivity.getInstance().finish();
                }  else
                    ToastUtil.showToast(context, "本单元无单词内容，请选择其他单元");
            });
        }

//        @SuppressLint("SetTextI18n")
//        private void setPage(int i){
//            //由于接口中有些单元的页码是没有数据的，故讲没有页码的单元设为上个单元的最后一页
//            ArrayList<Integer> p =new ArrayList<>();
//            module_unit_page.setVisibility(View.VISIBLE);
//            for (PageData.Pages pages : pages){
//                if (pages.getSid() == children.get(i).getId())
//                    p.add(Integer.valueOf(pages.getPagenum()));
//            }
//
//            if (p.size() != 0){
//                int max = Collections.max(p);
//                sharePreference.putInt("maxPage", max);
//                sharePreference.commit();
//            }
//
//            for (PageData.Pages pages : pages){
//                if (pages.getSid() == children.get(i).getId()){
//                    module_unit_page.setText("第" + pages.getPagenum() + "页");
//                    break;
//                } else
//                    module_unit_page.setText("第" + sharePreference.getInt("maxPage", 1) + "页");
//            }
//
//        }

    }
}
