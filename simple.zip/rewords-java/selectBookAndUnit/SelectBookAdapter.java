package com.readboy.simpleLauncher.rewords.selectBookAndUnit;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.Main_UI.Fragment.Tool.ToastUtil;
import com.readboy.simpleLauncher.rewords.data.book.BookDetails;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.IsNetWorkConnected;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;

import java.util.List;

/**
 * Created by hjy on 2022/4/9 10:32
 */
public class SelectBookAdapter extends RecyclerView.Adapter<SelectBookAdapter.ViewHolder>{

    List<BookDetails> books;
    Context context;
    SettingSharePreference sharePreference;

    public SelectBookAdapter(List<BookDetails> books, Context context){
        this.books = books;
        this.context = context;
        sharePreference = new SettingSharePreference(context);
    }
    @NonNull
    @Override
    public SelectBookAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_book_version, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SelectBookAdapter.ViewHolder viewHolder, int i) {
        viewHolder.initView(i);
    }

    @Override
    public int getItemCount() {
        return books == null ? 0 : books.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView book_cover;
        TextView book_name, grade_name;
        FrameLayout img_select;

        public ViewHolder(@NonNull View v) {
            super(v);
            book_cover = v.findViewById(R.id.cover);
            book_name = v.findViewById(R.id.name);
            grade_name = v.findViewById(R.id.grade_name);
            img_select = v.findViewById(R.id.img_select);
            img_select.setVisibility(View.GONE);
        }

        @SuppressLint("SetTextI18n")
        private void initView(int i){
            Glide.with(context).load(Config.ADDRESS_RESOURCE + books.get(i).getCover()).into(book_cover);
            String bookName;
            book_name.setText(books.get(i).getName());
            grade_name.setText(books.get(i).getGradeName());

            Log.e("TAG", "initView: books.get(i).getBid()  "+ sharePreference.getInt("bookId", 0) );
            if (sharePreference.getInt("bookId", 0) == books.get(i).getBid()){
                img_select.setVisibility(View.VISIBLE);
            } else
                img_select.setVisibility(View.GONE);

            itemView.setOnClickListener(v -> {
                if (!IsNetWorkConnected.isNetworkConnected(context)){
                    ToastUtil.showToast(context, R.string.btn_no_net_text);
                    return;
                }

                String path = books.get(i).getWordPackageUri();
                bookItemClick.onBookItemClick(path, books.get(i).getBid(), books.get(i).getUpdateTime());
                Log.d("TAG", "initView: books.get(i).getBid()  " +books.get(i).getBid() );
                sharePreference.putInt("bookId", books.get(i).getBid());
                sharePreference.putBoolean("isSelectBook", true);
                sharePreference.commit();
            });

        }

    }

    public interface bookItemClick {
        void onBookItemClick(String path, int bid, long updateTime);
    }

    private bookItemClick bookItemClick;

    public void setBookItemClick(bookItemClick bookItemClick) {
        this.bookItemClick = bookItemClick;
    }
}
