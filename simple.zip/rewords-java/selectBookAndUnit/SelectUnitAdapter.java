package com.readboy.simpleLauncher.rewords.selectBookAndUnit;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.readboy.simpleLauncher.Main_UI.Fragment.Tool.ToastUtil;
import com.readboy.simpleLauncher.R;
import com.readboy.simpleLauncher.rewords.data.book.Children;
import com.readboy.simpleLauncher.rewords.data.book.PageData;
import com.readboy.simpleLauncher.rewords.tool.Config;
import com.readboy.simpleLauncher.rewords.tool.IsNetWorkConnected;
import com.readboy.simpleLauncher.rewords.tool.SettingSharePreference;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * Created by hjy on 2022/4/11 11:01
 */
public class SelectUnitAdapter extends RecyclerView.Adapter<SelectUnitAdapter.ViewHolder>{
    ArrayList<Children> children;
//    ArrayList<PageData.Pages> pages;
    Context context;
    SettingSharePreference sharePreference;
    List<Integer> unitIdList = new ArrayList<>();
    List<String> unitNameList = new ArrayList<>();
//    List<Boolean> unitSelectList;
    Gson gson = new Gson();

    boolean twoDirectory;
    int bookId;
    String bookName;
    List<Integer> idList;
    List<Integer> nofindIdList = new ArrayList<>();

    public SelectUnitAdapter(ArrayList<Children> children, Context context, int bookId, String bookName){
        twoDirectory = false;
        this.children = children;
        this.context = context;
//        this.pages = pages;
        this.bookId = bookId;
        this.bookName = bookName;
        sharePreference = new SettingSharePreference(context);

        String idl = sharePreference.getString("unitIdList", "");
        if (!idl.equals("")) {
            Gson g = new Gson();
            /*      将json数据转成List集合     */
            idList = g.fromJson(idl, new TypeToken<List<Integer>>() {}.getType());
            Log.v("bbbbbb", "44444: unitIdList" + idList);
        }
    }

    @NonNull
    @Override
    public SelectUnitAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_select_unit, viewGroup, false);
        return  new SelectUnitAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SelectUnitAdapter.ViewHolder viewHolder, int i) {
        viewHolder.initAdapter(i);
    }

    @Override
    public int getItemCount() {
        return children == null ? 0 : children.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView select_unit_text;
        RecyclerView rv_module_unit;
        CheckBox checkBox;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            select_unit_text = itemView.findViewById(R.id.select_unit_text);
            rv_module_unit = itemView.findViewById(R.id.rv_module_unit);
            checkBox = itemView.findViewById(R.id.unit_checkbook);
        }

        private void initAdapter(int i){
            select_unit_text.setText(children.get(i).getName());
            if (children.get(i).getChildren() != null && children.get(i).getChildren().size() != 0){
                select_unit_text.getPaint().setTypeface(Typeface.DEFAULT_BOLD);
                checkBox.setVisibility(View.GONE);
                twoDirectory = true;
                //有二级目录的，在这里跳转到二级目录的处理
                ModuleUnitAdapter moduleAdapter = new ModuleUnitAdapter(children.get(i).getChildren(), context, bookId, bookName, idList);
                LinearLayoutManager manager = new LinearLayoutManager(context);
                rv_module_unit.setLayoutManager(manager);
                rv_module_unit.setAdapter(moduleAdapter);
            } else {
//                setPage(i);
                //只有一级目录的处理
                //将章节id和章节名保存
                if (children.get(i).getWord() != null){
                    unitIdList.add(children.get(i).getId());
                    unitNameList.add(children.get(i).getName());
                    if (idList != null && idList.size() != 0){
                        checkBox.setChecked(idList.contains(children.get(i).getId()));
                        if (!idList.contains(children.get(i).getId()))
                            nofindIdList.add(children.get(i).getId());
                    }

                    if (Config.IsFromSelectBook)
                        checkBox.setChecked(true);

                    checkBox.setVisibility(View.VISIBLE);
                } else
                    checkBox.setVisibility(View.GONE);

                rv_module_unit.setVisibility(View.INVISIBLE);

                /*          移除不存在于sp里的id             */
                if (i == children.size() - 1 && !Config.IsFromSelectBook)
                    for (int id : nofindIdList)
                        for(int k = 0; k < unitIdList.size(); k++)
                            if (unitIdList.get(k).equals(id)) {
                                unitIdList.remove(k);
                                break;
                            }

                /*          item的点击事件            */
                itemView.setOnClickListener(v -> {

                    if (Config.isFastDoubleClick()) return;//防止快速点击
                    Log.e("bbbbbb", "initAdapter: end  " + unitIdList.size() );

                    if (children.get(i).getWord() != null ) {

                        /*          list里面有的则删除，没有则添加             */
                        boolean isExit = false;
                        for (int k = 0; k < unitIdList.size(); k++){
                            if (unitIdList.get(k).equals(children.get(i).getId())){
                                unitIdList.remove(k);
                                isExit = true;
                                break;
                            }
                        }

                        if (!isExit)
                            unitIdList.add(children.get(i).getId());

//                        if (unitIdList.contains(children.get(i).getId())){
//                            unitIdList.remove(i);
//                        } else

                        if (unitIdList.size() < 1){
                            if (!unitIdList.contains(children.get(i).getId()))
                                unitIdList.add(children.get(i).getId());
//                            ToastUtil.showToast(context, "最少要选择一个单元！");
                            return;
                        }

                        checkBox.setChecked(!checkBox.isChecked());

                        /*          排序          */
                        Collections.sort(unitIdList);
                        Log.d("bbbbbb", "initAdapter: end" + unitIdList );
                        sharePreference.putIntList("unitIdList", unitIdList);
                        sharePreference.commit();

                    } else
                        ToastUtil.showToast(context, R.string.unit_no_word);

                });


                /*          当重新选书时才执行此方法            */
                Log.d("TAG", "init: isSelectBook  " + sharePreference.getBoolean("isSelectBook", false) + "  " + i + "  children.size(" + children.size());
                if (i == children.size() - 1 && sharePreference.getBoolean("isSelectBook", false) && !twoDirectory) {
                    sharePreference.putBoolean("isSelectBook", false);
                    sharePreference.putInt("unitId", children.get(0).getId());
                    Log.v("bbbbbb", "555555: unitIdList" + unitIdList);

                    sharePreference.putIntList("unitIdList", unitIdList);
                    sharePreference.putStringList("unitNameList", unitNameList);
                    sharePreference.commit();
                }


            }
        }

//        @SuppressLint("SetTextI18n")
//        private void setPage(int i){
//            //页码显示处理,由于接口中有些单元的页码是没有数据的，故讲没有页码的单元设为上个单元的最后一页
//            ArrayList<Integer> p =new ArrayList<>();
//            unit_page.setVisibility(View.VISIBLE);
//            for (PageData.Pages pages : pages){
//                if (pages.getSid() == children.get(i).getId() && !pages.getPagenum().equals("")){
//                    p.add(Integer.valueOf(pages.getPagenum()));
//                }
//            }
//
//            if (p.size() != 0){
//                int max = Collections.max(p);
//                sharePreference.putInt("maxPage", max);
//                sharePreference.commit();
//            }
//
//            for (PageData.Pages pages : pages){
//                if (pages.getSid() == children.get(i).getId()){
//                    unit_page.setText("第" + pages.getPagenum() + "页");
//                    break;
//                } else
//                    unit_page.setText("第" + sharePreference.getInt("maxPage", 1) + "页");
//            }
//
//        }

    }

}
